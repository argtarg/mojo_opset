"""Same-card calibration using the preserved original int32 Triton copy kernel."""
from pathlib import Path
import os,sys,json,statistics,importlib.util,time
import torch,torch_npu,triton
import triton.runtime.driver as driver

O=Path(os.environ['O']);tag=sys.argv[1] if len(sys.argv)>1 else 'pre'
s=importlib.util.spec_from_file_location('original_calibration',O/'calibration_original.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
torch.npu.set_device(0);cores=int(driver.active.utils.get_device_properties(0)['num_vectorcore'])
flush=driver.active.get_empty_cache_for_benchmark().float();flush_bytes=flush.numel()*flush.element_size()
records=[]
for cold in [False,True]:
    for n in [32*1024*1024,64*1024*1024,128*1024*1024]:
        src=torch.ones(n,device='npu:0',dtype=torch.int32);dst=torch.empty_like(src);grid=(min(triton.cdiv(n,8192),cores),)
        def call():m._copy_kernel[grid](src,dst,n,grid[0],BLOCK=8192)
        def clear():
            if cold:flush.sum();torch.npu.synchronize()
        for _ in range(5):clear();call()
        torch.npu.synchronize();times=[]
        for _ in range(20):
            clear();a=torch.npu.Event(enable_timing=True);b=torch.npu.Event(enable_timing=True)
            a.record();call();b.record();torch.npu.synchronize();times.append(float(a.elapsed_time(b))*1000)
        assert torch.equal(src,dst)
        med=statistics.median(times);r={'n_elements':n,'bytes_read':4*n,'bytes_write':4*n,'cold_l2':cold,'samples_us':times,'median_us':med,'median_gbps':8*n/med/1000,'correct':True};records.append(r)
        print('COPY_CALIBRATION',cold,n,med,r['median_gbps'],flush=True)
        del src,dst;torch.npu.empty_cache()
r={'physical_card':int(os.environ['ASCEND_RT_VISIBLE_DEVICES']),'logical_device':0,'host':os.uname().nodename,'num_vectorcore':cores,'method':'original int32 Triton copy BLOCK8192; max of medians across 32/64/128M elements; Event kernel region; oracle/input creation/flush outside timer','warmup':5,'repeats':20,'frequency_lock':False,'flush_buffer_bytes':flush_bytes,'flush_method':'same runtime empty-cache buffer float().sum()+synchronize as benchmark.py','measurements':records,'fresh_cold_copy_peak_gbps':max(x['median_gbps'] for x in records if x['cold_l2']),'fresh_original_method_warm_peak_gbps':max(x['median_gbps'] for x in records if not x['cold_l2']),'historical_fixed_peak_gbps':1212.5003577875182}
(O/('calibration_'+tag+'.json')).write_text(json.dumps(r,indent=2))
if tag=='pre':(O/'calibration.json').write_text(json.dumps(r,indent=2))
print('CALIBRATION_COMPLETE',tag,r['fresh_cold_copy_peak_gbps'],r['fresh_original_method_warm_peak_gbps'],flush=True)
