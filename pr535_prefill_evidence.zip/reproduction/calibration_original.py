"""Calibrate achievable HBM bandwidth on the current NPU with a Triton copy kernel."""
import json
import statistics
import sys

import torch
import triton
import triton.language as tl


@triton.jit
def _copy_kernel(src_ptr, dst_ptr, n, num_programs, BLOCK: tl.constexpr):
    pid = tl.program_id(0).to(tl.int32)
    cols = tl.arange(0, BLOCK)
    step = num_programs * BLOCK
    for start in range(pid * BLOCK, n, step):
        off = start + cols
        m = off < n
        tl.store(dst_ptr + off, tl.load(src_ptr + off, mask=m), mask=m)


def _measure(n_elements, cores, warmup=5, reps=20):
    src = torch.empty(n_elements, dtype=torch.int32, device="npu")
    dst = torch.empty(n_elements, dtype=torch.int32, device="npu")
    src.fill_(1)
    dst.zero_()
    block = 8192
    grid = (min(triton.cdiv(n_elements, block), cores),)
    for _ in range(warmup):
        _copy_kernel[grid](src, dst, n_elements, grid[0], BLOCK=block)
    torch.npu.synchronize()
    times = []
    for _ in range(reps):
        t0 = torch.npu.Event(enable_timing=True)
        t1 = torch.npu.Event(enable_timing=True)
        t0.record()
        _copy_kernel[grid](src, dst, n_elements, grid[0], BLOCK=block)
        t1.record()
        torch.npu.synchronize()
        times.append(t0.elapsed_time(t1))
    ms = statistics.median(times)
    bytes_moved = 2 * 4 * n_elements
    gbps = bytes_moved / (ms * 1e-3) / 1e9
    ok = bool(torch.equal(src, dst))
    del src, dst
    torch.npu.empty_cache()
    return {"n_elements": n_elements, "median_ms": ms, "gbps": gbps, "correct": ok}


def main():
    out_path = sys.argv[1] if len(sys.argv) > 1 else "mbu_peak.json"
    import torch_npu  # noqa: F401
    import triton.runtime.driver as driver

    dev = torch_npu.npu.current_device()
    cores = int(driver.active.utils.get_device_properties(dev)["num_vectorcore"])
    results = []
    for n in (32 * 1024 * 1024, 64 * 1024 * 1024, 128 * 1024 * 1024):
        r = _measure(n, cores)
        results.append(r)
        print(json.dumps(r))
    peak = max(r["gbps"] for r in results) / 1000.0  # TB/s
    payload = {
        "num_vectorcore": cores,
        "peak_nominal_tb_s": 1.8,
        "peak_achievable_tb_s": peak,
        "measurements": results,
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
