import torch
from mojo_opset import functions as F
class ModelNew(torch.nn.Module):
 def forward(self,*args):return F.triton_convert_req_index_to_global_index(*args,implementation="triton")
