import torch,torch_npu,triton
import triton.runtime.driver as driver
def build_operator_api(operator_module):return operator_module
def build_bench_cases():return [dict(id='copy'+str(m),n=m*1024*1024,warmup=20,repeats=40) for m in [32,64,128]]
def build_bench_case_fn(api,case):
 n=case['n'];src=torch.ones(n,device='npu',dtype=torch.int32);dst=torch.empty_like(src);cores=int(driver.active.utils.get_device_properties(0)['num_vectorcore']);grid=(min(triton.cdiv(n,8192),cores),)
 def run():api._copy_kernel[grid](src,dst,n,grid[0],BLOCK=8192);return dst
 run();torch.npu.synchronize();assert torch.equal(src,dst)
 return run
