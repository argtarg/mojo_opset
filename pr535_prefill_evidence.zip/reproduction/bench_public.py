# api-name: ModelNew
# api-kind: torch-module
# kernels: _convert_req_index_kernel
from tests.functions.test_triton_convert_req_index_to_global_index import PERFORMANCE_CASES, build_balanced_inputs

def build_operator_api(operator_module):
    return operator_module.ModelNew().npu().eval()

def build_bench_cases():
    return [dict(c, id=c["name"], warmup=100, repeats=40) for c in PERFORMANCE_CASES]

def build_bench_case_fn(operator_api, case):
    inputs = build_balanced_inputs(case, "npu:0")
    def run():
        return operator_api(*inputs)
    return run
