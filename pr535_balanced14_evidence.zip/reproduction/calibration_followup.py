from pathlib import Path
import json,os,subprocess,sys
r=Path.cwd();arch=sys.argv[1];card=sys.argv[2]
env=os.environ.copy();env.update(ASCEND_RT_VISIBLE_DEVICES=card,PYTHONPATH=str(r/'repo')+':'+str(r),TRITON_CACHE_DIR=str(r/'cache'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',HELIX_BENCH_OUTPUT_DIR=str(r/'profile'),GLM_CLEAR_L2='1')
assert 'FOLLOWUP_COMPLETE' in (r/'followup.log').read_text()
cli=r/'.agents/skills/triton-npu-run-eval/scripts/cli.py'
def run(tag,bench,op):
 with (r/'logs'/(tag+'.log')).open('w') as f:p=subprocess.run([sys.executable,str(cli),'run-bench','--bench-file',str(r/bench),'--operator-file',str(r/op),'--output',str(r/'results'/(tag+'_perf.txt')),'--metric-source','kernel','--verbose'],env=env,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,tag
for i in [1,2]:run('copy_kernel_round'+str(i),'bench_copy.py','calibration_original.py')
if arch=='a2':
 env['GEN_CASE_IDS']='gb08'
 for i in [3,4]:run('cold_round'+str(i),'bench_public.py','public_operator.py')
print('CALIBRATION_COMPLETE',flush=True)
