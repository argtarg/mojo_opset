from typing import Tuple

import torch
import triton
import triton.language as tl

from mojo_opset.kernels._npu_triton_utils import VEC_ALIGN_BYTES, get_num_cores
from mojo_opset.kernels._triton_utils import align, ceil_div

from mojo_opset.kernels._npu_triton_utils import libentry

COL_BLOCKING_THRESHOLD = 2048

_CASTING_MODE_NONE: tl.constexpr = tl.constexpr(-1)
_CASTING_MODE_LLAMA: tl.constexpr = tl.constexpr(0)
_CASTING_MODE_GEMMA: tl.constexpr = tl.constexpr(1)

TOKEN_BLOCK_SIZE_TABLE = {
    2048: 4,
    1024: 6,
    512: 8,
    256: 16,
    128: 20,
}


def rms_norm_fwd_heuristics(args):
    hidden_dim = args["n_cols"]
    n_rows = args["n_rows"] if "n_rows" in args else 0

    if hidden_dim >= 8192:
        return 1
    if hidden_dim >= 4096:
        return 2
    if hidden_dim >= 2048:
        return 4
    if hidden_dim >= 1024:
        return 8
    if hidden_dim >= 512:
        return 16

    if hidden_dim <= 128:
        if n_rows > 0 and n_rows <= 32:
            return 4
        return 32

    if hidden_dim <= COL_BLOCKING_THRESHOLD:
        if hidden_dim in TOKEN_BLOCK_SIZE_TABLE:
            return TOKEN_BLOCK_SIZE_TABLE[hidden_dim]

        for dim_thresh, block_size in sorted(TOKEN_BLOCK_SIZE_TABLE.items()):
            if hidden_dim <= dim_thresh:
                return block_size
        return 1
    return 4


def _num_vectorcores():
    return get_num_cores("vector")


@libentry()
@triton.heuristics({"BLOCK_SIZE_M": rms_norm_fwd_heuristics})
@triton.jit
def _fused_add_rmsnorm_fwd_kernel(
    Y_ptr,
    Y_row_stride,
    S_ptr,
    S_row_stride,
    X_ptr,
    X_row_stride,
    R_ptr,
    R_row_stride,
    W_ptr,
    RSTD_ptr,
    RSTD_row_stride,
    n_rows,
    n_cols,
    eps,
    offset,
    casting_mode: tl.constexpr,
    STORE_S: tl.constexpr,
    STORE_RSTD: tl.constexpr,
    DROP_COLS_MASK: tl.constexpr,
    DROP_ROWS_MASK: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    grid_size = tl.num_programs(axis=0)
    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M

    for row_task_id in range(pid, num_row_tasks, grid_size):
        block_start_row = row_task_id * BLOCK_SIZE_M
        rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)

        X_ptr_row_block = X_ptr + rows_off[:, None] * X_row_stride
        R_ptr_row_block = R_ptr + rows_off[:, None] * R_row_stride
        S_ptr_row_block = S_ptr + rows_off[:, None] * S_row_stride
        Y_ptr_row_block = Y_ptr + rows_off[:, None] * Y_row_stride

        if not DROP_ROWS_MASK:
            rows_mask = rows_off < n_rows

        var_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)
        for col_offset in range(0, n_cols, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)

            if DROP_ROWS_MASK:
                if DROP_COLS_MASK:
                    X_chunk = tl.load(X_ptr_row_block + cols_off[None, :])
                    R_chunk = tl.load(R_ptr_row_block + cols_off[None, :])
                else:
                    cols_mask = cols_off < n_cols
                    X_chunk = tl.load(
                        X_ptr_row_block + cols_off[None, :],
                        mask=cols_mask[None, :],
                        other=0.0,
                    )
                    R_chunk = tl.load(
                        R_ptr_row_block + cols_off[None, :],
                        mask=cols_mask[None, :],
                        other=0.0,
                    )
            else:
                if DROP_COLS_MASK:
                    block_mask = rows_mask[:, None]
                else:
                    block_mask = rows_mask[:, None] & (cols_off[None, :] < n_cols)
                X_chunk = tl.load(
                    X_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
                )
                R_chunk = tl.load(
                    R_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
                )

            S_chunk = X_chunk + R_chunk
            if STORE_S:
                if DROP_ROWS_MASK:
                    if DROP_COLS_MASK:
                        tl.store(S_ptr_row_block + cols_off[None, :], S_chunk)
                    else:
                        tl.store(
                            S_ptr_row_block + cols_off[None, :],
                            S_chunk,
                            mask=cols_mask[None, :],
                        )
                else:
                    tl.store(
                        S_ptr_row_block + cols_off[None, :], S_chunk, mask=block_mask
                    )

            S_chunk_f32 = S_chunk.to(tl.float32)
            var_acc += tl.sum(S_chunk_f32 * S_chunk_f32, axis=1)

        var = var_acc / n_cols
        rstd_vec = tl.rsqrt(var + eps)
        if STORE_RSTD:
            if DROP_ROWS_MASK:
                tl.store(RSTD_ptr + rows_off * RSTD_row_stride, rstd_vec)
            else:
                tl.store(
                    RSTD_ptr + rows_off * RSTD_row_stride, rstd_vec, mask=rows_mask
                )

        for col_offset in range(0, n_cols, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)

            if DROP_ROWS_MASK:
                if DROP_COLS_MASK:
                    W_chunk = tl.load(W_ptr + cols_off)
                    if STORE_S:
                        S_chunk = tl.load(S_ptr_row_block + cols_off[None, :])
                    else:
                        X_chunk = tl.load(X_ptr_row_block + cols_off[None, :])
                        R_chunk = tl.load(R_ptr_row_block + cols_off[None, :])
                        S_chunk = X_chunk + R_chunk
                else:
                    cols_mask = cols_off < n_cols
                    W_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0)
                    if STORE_S:
                        S_chunk = tl.load(
                            S_ptr_row_block + cols_off[None, :],
                            mask=cols_mask[None, :],
                            other=0.0,
                        )
                    else:
                        X_chunk = tl.load(
                            X_ptr_row_block + cols_off[None, :],
                            mask=cols_mask[None, :],
                            other=0.0,
                        )
                        R_chunk = tl.load(
                            R_ptr_row_block + cols_off[None, :],
                            mask=cols_mask[None, :],
                            other=0.0,
                        )
                        S_chunk = X_chunk + R_chunk
            else:
                if DROP_COLS_MASK:
                    block_mask = rows_mask[:, None]
                    W_chunk = tl.load(W_ptr + cols_off)
                else:
                    cols_mask = cols_off < n_cols
                    block_mask = rows_mask[:, None] & cols_mask[None, :]
                    W_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0)

                if STORE_S:
                    S_chunk = tl.load(
                        S_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
                    )
                else:
                    X_chunk = tl.load(
                        X_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
                    )
                    R_chunk = tl.load(
                        R_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
                    )
                    S_chunk = X_chunk + R_chunk

            if casting_mode == _CASTING_MODE_GEMMA:
                S_chunk = S_chunk.to(tl.float32)
                W_chunk = W_chunk.to(tl.float32)
            elif casting_mode == _CASTING_MODE_LLAMA:
                S_chunk = S_chunk.to(tl.float32)

            if casting_mode == _CASTING_MODE_LLAMA:
                if STORE_S:
                    normed_S_chunk = (S_chunk * rstd_vec[:, None]).to(
                        S_ptr.dtype.element_ty
                    )
                else:
                    normed_S_chunk = (S_chunk * rstd_vec[:, None]).to(
                        Y_ptr.dtype.element_ty
                    )
            else:
                normed_S_chunk = S_chunk * rstd_vec[:, None]

            Y_chunk = normed_S_chunk * (W_chunk[None, :] + offset)

            if casting_mode == _CASTING_MODE_GEMMA:
                if STORE_S:
                    Y_chunk = Y_chunk.to(S_ptr.dtype.element_ty)
                else:
                    Y_chunk = Y_chunk.to(Y_ptr.dtype.element_ty)

            if DROP_ROWS_MASK:
                if DROP_COLS_MASK:
                    tl.store(Y_ptr_row_block + cols_off[None, :], Y_chunk)
                else:
                    tl.store(
                        Y_ptr_row_block + cols_off[None, :],
                        Y_chunk,
                        mask=cols_mask[None, :],
                    )
            else:
                tl.store(Y_ptr_row_block + cols_off[None, :], Y_chunk, mask=block_mask)


@libentry()
@triton.heuristics({"BLOCK_SIZE_M": rms_norm_fwd_heuristics})
@triton.jit
def _fused_add_rmsnorm_fwd_single_pass_kernel(
    Y_ptr,
    Y_row_stride,
    S_ptr,
    S_row_stride,
    X_ptr,
    X_row_stride,
    R_ptr,
    R_row_stride,
    W_ptr,
    RSTD_ptr,
    RSTD_row_stride,
    n_rows,
    n_cols,
    eps,
    offset,
    casting_mode: tl.constexpr,
    STORE_S: tl.constexpr,
    STORE_RSTD: tl.constexpr,
    DROP_COLS_MASK: tl.constexpr,
    DROP_ROWS_MASK: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    grid_size = tl.num_programs(axis=0)
    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M

    for row_task_id in range(pid, num_row_tasks, grid_size):
        block_start_row = row_task_id * BLOCK_SIZE_M
        rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)

        X_ptr_row_block = X_ptr + rows_off[:, None] * X_row_stride
        R_ptr_row_block = R_ptr + rows_off[:, None] * R_row_stride
        S_ptr_row_block = S_ptr + rows_off[:, None] * S_row_stride
        Y_ptr_row_block = Y_ptr + rows_off[:, None] * Y_row_stride

        cols_off = tl.arange(0, BLOCK_SIZE_N)

        if DROP_ROWS_MASK:
            if DROP_COLS_MASK:
                X_chunk = tl.load(X_ptr_row_block + cols_off[None, :])
                R_chunk = tl.load(R_ptr_row_block + cols_off[None, :])
            else:
                cols_mask = cols_off < n_cols
                X_chunk = tl.load(
                    X_ptr_row_block + cols_off[None, :],
                    mask=cols_mask[None, :],
                    other=0.0,
                )
                R_chunk = tl.load(
                    R_ptr_row_block + cols_off[None, :],
                    mask=cols_mask[None, :],
                    other=0.0,
                )
        else:
            rows_mask = rows_off < n_rows
            if DROP_COLS_MASK:
                block_mask = rows_mask[:, None]
            else:
                cols_mask = cols_off < n_cols
                block_mask = rows_mask[:, None] & cols_mask[None, :]
            X_chunk = tl.load(
                X_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
            )
            R_chunk = tl.load(
                R_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
            )

        S_chunk = X_chunk + R_chunk

        if STORE_S:
            if DROP_ROWS_MASK:
                if DROP_COLS_MASK:
                    tl.store(S_ptr_row_block + cols_off[None, :], S_chunk)
                else:
                    tl.store(
                        S_ptr_row_block + cols_off[None, :],
                        S_chunk,
                        mask=cols_mask[None, :],
                    )
            else:
                tl.store(S_ptr_row_block + cols_off[None, :], S_chunk, mask=block_mask)

        S_chunk_f32 = S_chunk.to(tl.float32)
        var_acc = tl.sum(S_chunk_f32 * S_chunk_f32, axis=1)
        var = var_acc / n_cols
        rstd_vec = tl.rsqrt(var + eps)

        if STORE_RSTD:
            if DROP_ROWS_MASK:
                tl.store(RSTD_ptr + rows_off * RSTD_row_stride, rstd_vec)
            else:
                tl.store(
                    RSTD_ptr + rows_off * RSTD_row_stride, rstd_vec, mask=rows_mask
                )

        if DROP_COLS_MASK:
            W_chunk = tl.load(W_ptr + cols_off)
        else:
            W_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0)

        if casting_mode == _CASTING_MODE_GEMMA:
            S_chunk = S_chunk.to(tl.float32)
            W_chunk = W_chunk.to(tl.float32)
        elif casting_mode == _CASTING_MODE_LLAMA:
            S_chunk = S_chunk.to(tl.float32)

        if casting_mode == _CASTING_MODE_LLAMA:
            if STORE_S:
                normed_S_chunk = (S_chunk * rstd_vec[:, None]).to(
                    S_ptr.dtype.element_ty
                )
            else:
                normed_S_chunk = (S_chunk * rstd_vec[:, None]).to(
                    Y_ptr.dtype.element_ty
                )
        else:
            normed_S_chunk = S_chunk * rstd_vec[:, None]

        Y_chunk = normed_S_chunk * (W_chunk[None, :] + offset)

        if casting_mode == _CASTING_MODE_GEMMA:
            if STORE_S:
                Y_chunk = Y_chunk.to(S_ptr.dtype.element_ty)
            else:
                Y_chunk = Y_chunk.to(Y_ptr.dtype.element_ty)

        if DROP_ROWS_MASK:
            if DROP_COLS_MASK:
                tl.store(Y_ptr_row_block + cols_off[None, :], Y_chunk)
            else:
                tl.store(
                    Y_ptr_row_block + cols_off[None, :],
                    Y_chunk,
                    mask=cols_mask[None, :],
                )
        else:
            tl.store(Y_ptr_row_block + cols_off[None, :], Y_chunk, mask=block_mask)


@libentry()
@triton.heuristics({"BLOCK_SIZE_M": lambda args: ceil_div(4096, args["n_cols"])})
@triton.jit
def _fused_add_rmsnorm_bwd_kernel(
    dY_ptr,
    dY_row_stride,
    dS_out_ptr,
    dS_out_row_stride,
    dX_ptr,
    dX_row_stride,
    S_ptr,
    S_row_stride,
    W_ptr,
    RSTD_ptr,
    RSTD_row_stride,
    dW_ptr,
    dW_row_stride,
    n_rows,
    n_cols,
    offset,
    casting_mode: tl.constexpr,
    S_dtype: tl.constexpr,
    has_dS_out: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    grid_size = tl.num_programs(axis=0)
    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M

    dW_acc = tl.zeros((BLOCK_SIZE_N,), dtype=tl.float32)

    cols_off = tl.arange(0, BLOCK_SIZE_N)
    cols_mask = cols_off < n_cols
    W_row = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0)
    W_row_offset = W_row + offset

    for row_task_id in range(pid, num_row_tasks, grid_size):
        block_start_row = row_task_id * BLOCK_SIZE_M
        rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)
        rows_mask = rows_off < n_rows
        block_mask = rows_mask[:, None] & cols_mask[None, :]

        dY_block = tl.load(
            dY_ptr + rows_off[:, None] * dY_row_stride + cols_off[None, :],
            mask=block_mask,
            other=0.0,
        )
        S_block = tl.load(
            S_ptr + rows_off[:, None] * S_row_stride + cols_off[None, :],
            mask=block_mask,
            other=0.0,
        )
        rstd_vec = tl.load(
            RSTD_ptr + rows_off * RSTD_row_stride, mask=rows_mask, other=0.0
        )

        S_block_f32 = S_block.to(tl.float32)
        normed_S_block = S_block_f32 * rstd_vec[:, None]

        if casting_mode == _CASTING_MODE_LLAMA:
            m_block = (dY_block * W_row_offset[None, :]).to(tl.float32)
            dW_acc += tl.sum(dY_block * normed_S_block.to(S_dtype), axis=0)
        elif casting_mode == _CASTING_MODE_GEMMA:
            dY_block_f32 = dY_block.to(tl.float32)
            W_row_offset_f32 = W_row_offset.to(tl.float32)
            m_block = dY_block_f32 * W_row_offset_f32[None, :]
            dW_acc += tl.sum(dY_block_f32 * normed_S_block, axis=0)
        else:
            m_block = dY_block * W_row_offset[None, :]
            dW_acc += tl.sum(dY_block * normed_S_block, axis=0)

        dot_product_vec = tl.sum(m_block * S_block_f32, axis=1)
        rstd_vec_sq = rstd_vec * rstd_vec

        term1 = rstd_vec[:, None] * m_block
        term2 = (
            -(1 / n_cols)
            * rstd_vec_sq[:, None]
            * rstd_vec[:, None]
            * dot_product_vec[:, None]
            * S_block_f32
        )

        grad_after_norm = term1 + term2

        dS_block = grad_after_norm
        if has_dS_out:
            dS_out_block = tl.load(
                dS_out_ptr + rows_off[:, None] * dS_out_row_stride + cols_off[None, :],
                mask=block_mask,
                other=0.0,
            )
            dS_block += dS_out_block.to(dS_block.dtype)

        tl.store(
            dX_ptr + rows_off[:, None] * dX_row_stride + cols_off[None, :],
            dS_block.to(S_dtype),
            mask=block_mask,
        )

    dW_ptr_prog = dW_ptr + pid * dW_row_stride + cols_off
    tl.store(dW_ptr_prog, dW_acc, mask=cols_mask)


def fused_add_rmsnorm_infer_impl(
    hidden_states: torch.Tensor,
    residual: torch.Tensor,
    weight: torch.Tensor,
    add_mode: str = "pre",
    eps: float = 1e-6,
    offset: float = 0.0,
    casting_mode: str = "llama",
) -> Tuple[torch.Tensor, torch.Tensor]:
    shape = hidden_states.shape
    dim = shape[-1]
    hidden_states_2d = hidden_states.reshape(-1, dim)
    residual_2d = residual.reshape(-1, dim)
    n_rows, n_cols = hidden_states_2d.shape

    if COL_BLOCKING_THRESHOLD < n_cols < 8192:
        BLOCK_SIZE_N = 2048
    else:
        BLOCK_SIZE_N = align(hidden_states, n_cols, VEC_ALIGN_BYTES)

    str_to_casting_mode = {"llama": 0, "gemma": 1, "none": -1}
    _casting_mode = str_to_casting_mode[casting_mode]

    rstd_dtype = torch.float32 if _casting_mode in (0, 1) else hidden_states.dtype
    RSTD = torch.empty(n_rows, dtype=rstd_dtype, device=hidden_states.device)

    BLOCK_SIZE_M = rms_norm_fwd_heuristics({"n_rows": n_rows, "n_cols": n_cols})
    num_row_tasks = ceil_div(n_rows, BLOCK_SIZE_M)
    grid = (max(1, min(_num_vectorcores(), num_row_tasks)),)

    Y = torch.empty_like(hidden_states_2d)
    use_single_pass = n_cols <= BLOCK_SIZE_N
    drop_cols_mask = n_cols % BLOCK_SIZE_N == 0
    drop_rows_mask = n_rows % BLOCK_SIZE_M == 0

    if use_single_pass:
        S = Y if add_mode == "post" else torch.empty_like(hidden_states_2d)
        _fused_add_rmsnorm_fwd_single_pass_kernel[grid](
            Y,
            Y.stride(0),
            S,
            S.stride(0),
            hidden_states_2d,
            hidden_states_2d.stride(0),
            residual_2d,
            residual_2d.stride(0),
            weight,
            RSTD,
            RSTD.stride(0),
            n_rows,
            n_cols,
            eps,
            offset,
            casting_mode=_casting_mode,
            STORE_S=add_mode == "pre",
            STORE_RSTD=True,
            DROP_COLS_MASK=drop_cols_mask,
            DROP_ROWS_MASK=drop_rows_mask,
            BLOCK_SIZE_N=BLOCK_SIZE_N,
            sync_solver=True,
        )
        if add_mode == "pre":
            return Y.reshape(*shape), S.reshape(*shape)
        if add_mode == "post":
            return Y.reshape(*shape), Y.reshape(*shape)
        raise ValueError(f"Invalid add_mode: {add_mode}. Must be 'pre' or 'post'.")

    S = Y if add_mode == "post" else torch.empty_like(hidden_states_2d)
    _fused_add_rmsnorm_fwd_kernel[grid](
        Y,
        Y.stride(0),
        S,
        S.stride(0),
        hidden_states_2d,
        hidden_states_2d.stride(0),
        residual_2d,
        residual_2d.stride(0),
        weight,
        RSTD,
        RSTD.stride(0),
        n_rows,
        n_cols,
        eps,
        offset,
        casting_mode=_casting_mode,
        STORE_S=add_mode == "pre",
        STORE_RSTD=True,
        DROP_COLS_MASK=drop_cols_mask,
        DROP_ROWS_MASK=drop_rows_mask,
        BLOCK_SIZE_N=BLOCK_SIZE_N,
        sync_solver=True,
    )

    if add_mode == "pre":
        return Y.reshape(*shape), S.reshape(*shape)
    elif add_mode == "post":
        return Y.reshape(*shape), Y.reshape(*shape)
    else:
        raise ValueError(f"Invalid add_mode: {add_mode}. Must be 'pre' or 'post'.")


@torch.library.custom_op("mojo_npu_triton_a5::residual_add_rms_norm_infer", mutates_args=())
def residual_add_rms_norm_infer_fwd(
    x: torch.Tensor, residual: torch.Tensor, weight: torch.Tensor, eps: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    return fused_add_rmsnorm_infer_impl(x.contiguous(), residual.contiguous(), weight.contiguous(), "pre", eps)


@residual_add_rms_norm_infer_fwd.register_fake
def _residual_add_rms_norm_infer_fake(x, residual, weight, eps):
    return (torch.empty_like(x, memory_format=torch.contiguous_format),
            torch.empty_like(x, memory_format=torch.contiguous_format))
