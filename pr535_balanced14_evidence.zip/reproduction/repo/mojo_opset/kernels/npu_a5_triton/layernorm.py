from typing import Optional

import torch
import triton
import triton.language as tl
from triton.language.math import rsqrt
from mojo_opset.kernels._npu_triton_utils import get_num_cores, libentry

from mojo_opset.kernels._npu_triton_utils import VEC_ALIGN_BYTES
from mojo_opset.kernels._triton_utils import align, ceil_div, torch_to_triton_dtype

COL_BLOCKING_THRESHOLD = 2048
SINGLE_PASS_THRESHOLD = 2048
TWO_PASS_BLOCK_SIZE_N = 4096
TOKEN_BLOCK_SIZE_TABLE = {
    2048: 4,
    1024: 8,
    512: 10,
    256: 18,
    128: 24,
}


def layer_norm_fwd_heuristics(args):
    hidden_dim = args["n_cols"]
    n_rows = args["n_rows"] if "n_rows" in args else 0
    x_dtype = args["x_dtype"] if "x_dtype" in args else args["X_ptr"].dtype

    if hidden_dim > 8192:
        if x_dtype != torch.float32:
            return 4
        return 8

    if hidden_dim >= 8192:
        if n_rows <= 16:
            return 1
        if x_dtype != torch.float32:
            return 4
        return 8

    if hidden_dim >= 4096:
        if n_rows <= 16:
            return 1
        return 4

    if hidden_dim >= 2048:
        return 4

    if hidden_dim >= 1024:
        return 8

    if hidden_dim >= 512:
        return 12

    if hidden_dim <= 128:
        if n_rows >= 256:
            return 32
        return 16

    if hidden_dim <= COL_BLOCKING_THRESHOLD:
        if hidden_dim in TOKEN_BLOCK_SIZE_TABLE:
            return TOKEN_BLOCK_SIZE_TABLE[hidden_dim]

        for dim_thresh, block_size in sorted(TOKEN_BLOCK_SIZE_TABLE.items()):
            if hidden_dim <= dim_thresh:
                return block_size
        return 1
    return 4


def layer_norm_fwd_two_pass_heuristics(args):
    hidden_dim = args["n_cols"]
    if hidden_dim <= COL_BLOCKING_THRESHOLD:
        if hidden_dim in TOKEN_BLOCK_SIZE_TABLE:
            return TOKEN_BLOCK_SIZE_TABLE[hidden_dim]
        for dim_thresh, block_size in sorted(TOKEN_BLOCK_SIZE_TABLE.items()):
            if hidden_dim <= dim_thresh:
                return block_size
        return 1
    else:
        return 2


@libentry()
@triton.jit
def _layernorm_fwd_kernel(
    X_ptr,
    Y_ptr,
    W_ptr,
    B_ptr,
    Mean_ptr,
    RSTD_ptr,
    stride_x_row,
    stride_y_row,
    n_rows,
    n_cols,
    eps: tl.constexpr,
    DROP_COLS_MASK: tl.constexpr,
    DROP_ROWS_MASK: tl.constexpr,
    STORE_STATS: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_N_PASS1: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(0)
    num_programs = tl.num_programs(0)

    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M

    for row_task_id in range(pid, num_row_tasks, num_programs):
        block_start_row = row_task_id * BLOCK_SIZE_M
        rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)

        if not DROP_ROWS_MASK:
            rows_mask = rows_off < n_rows

        mean_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)
        var_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)

        X_ptr_row_block = X_ptr + rows_off[:, None] * stride_x_row
        Y_ptr_row_block = Y_ptr + rows_off[:, None] * stride_y_row

        for col_offset in range(0, n_cols, BLOCK_SIZE_N_PASS1):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N_PASS1)

            if DROP_ROWS_MASK:
                if DROP_COLS_MASK:
                    x_chunk = tl.load(X_ptr_row_block + cols_off[None, :])
                else:
                    cols_mask = cols_off < n_cols
                    x_chunk = tl.load(
                        X_ptr_row_block + cols_off[None, :],
                        mask=cols_mask[None, :],
                        other=0.0,
                    )
            else:
                if DROP_COLS_MASK:
                    block_mask = rows_mask[:, None]
                else:
                    cols_mask = cols_off < n_cols
                    block_mask = rows_mask[:, None] & cols_mask[None, :]
                x_chunk = tl.load(
                    X_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
                )

            x_chunk = x_chunk.to(tl.float32)
            mean_acc += tl.sum(x_chunk, axis=1)
            var_acc += tl.sum(x_chunk * x_chunk, axis=1)

        mean = mean_acc / n_cols
        var = var_acc / n_cols - mean * mean
        var = tl.maximum(var, 0.0)
        rstd = rsqrt(var + eps)

        if STORE_STATS:
            if DROP_ROWS_MASK:
                tl.store(Mean_ptr + rows_off, mean)
                tl.store(RSTD_ptr + rows_off, rstd)
            else:
                tl.store(Mean_ptr + rows_off, mean, mask=rows_mask)
                tl.store(RSTD_ptr + rows_off, rstd, mask=rows_mask)

        for col_offset in range(0, n_cols, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)

            if DROP_COLS_MASK:
                w_chunk = tl.load(W_ptr + cols_off)
                b_chunk = tl.load(B_ptr + cols_off)
            else:
                cols_mask = cols_off < n_cols
                w_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0)
                b_chunk = tl.load(B_ptr + cols_off, mask=cols_mask, other=0.0)

            if DROP_ROWS_MASK:
                if DROP_COLS_MASK:
                    x_chunk = tl.load(X_ptr_row_block + cols_off[None, :])
                else:
                    x_chunk = tl.load(
                        X_ptr_row_block + cols_off[None, :],
                        mask=cols_mask[None, :],
                        other=0.0,
                    )
            else:
                if DROP_COLS_MASK:
                    block_mask = rows_mask[:, None]
                else:
                    block_mask = rows_mask[:, None] & cols_mask[None, :]
                x_chunk = tl.load(
                    X_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
                )

            x_chunk = x_chunk.to(tl.float32)
            w_chunk = w_chunk.to(tl.float32)
            b_chunk = b_chunk.to(tl.float32)
            y_chunk = (x_chunk - mean[:, None]) * rstd[:, None] * w_chunk[
                None, :
            ] + b_chunk[None, :]

            if DROP_ROWS_MASK:
                if DROP_COLS_MASK:
                    tl.store(
                        Y_ptr_row_block + cols_off[None, :],
                        y_chunk.to(Y_ptr.dtype.element_ty),
                    )
                else:
                    tl.store(
                        Y_ptr_row_block + cols_off[None, :],
                        y_chunk.to(Y_ptr.dtype.element_ty),
                        mask=cols_mask[None, :],
                    )
            else:
                tl.store(
                    Y_ptr_row_block + cols_off[None, :],
                    y_chunk.to(Y_ptr.dtype.element_ty),
                    mask=block_mask,
                )


@libentry()
@triton.heuristics({"BLOCK_SIZE_M": layer_norm_fwd_heuristics})
@triton.jit
def _layernorm_fwd_single_pass_kernel(
    X_ptr,
    Y_ptr,
    W_ptr,
    B_ptr,
    Mean_ptr,
    RSTD_ptr,
    stride_x_row,
    stride_y_row,
    n_rows,
    n_cols,
    eps: tl.constexpr,
    DROP_COLS_MASK: tl.constexpr,
    DROP_ROWS_MASK: tl.constexpr,
    STORE_STATS: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(0)
    num_programs = tl.num_programs(0)

    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M
    cols_off = tl.arange(0, BLOCK_SIZE_N)

    for row_task_id in range(pid, num_row_tasks, num_programs):
        block_start_row = row_task_id * BLOCK_SIZE_M
        rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)

        X_ptr_row_block = X_ptr + rows_off[:, None] * stride_x_row
        Y_ptr_row_block = Y_ptr + rows_off[:, None] * stride_y_row

        if DROP_ROWS_MASK:
            if DROP_COLS_MASK:
                x_chunk = tl.load(X_ptr_row_block + cols_off[None, :])
            else:
                cols_mask = cols_off < n_cols
                x_chunk = tl.load(
                    X_ptr_row_block + cols_off[None, :],
                    mask=cols_mask[None, :],
                    other=0.0,
                )
        else:
            rows_mask = rows_off < n_rows
            if DROP_COLS_MASK:
                block_mask = rows_mask[:, None]
                x_chunk = tl.load(
                    X_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
                )
            else:
                cols_mask = cols_off < n_cols
                block_mask = rows_mask[:, None] & cols_mask[None, :]
                x_chunk = tl.load(
                    X_ptr_row_block + cols_off[None, :], mask=block_mask, other=0.0
                )

        x_chunk = x_chunk.to(tl.float32)
        mean = tl.sum(x_chunk, axis=1) / n_cols
        x_centered = x_chunk - mean[:, None]
        if DROP_COLS_MASK:
            var = tl.sum(x_centered * x_centered, axis=1) / n_cols
        else:
            x_centered_for_var = tl.where(cols_mask[None, :], x_centered, 0.0)
            var = tl.sum(x_centered_for_var * x_centered_for_var, axis=1) / n_cols
        rstd = rsqrt(var + eps)

        if STORE_STATS:
            if DROP_ROWS_MASK:
                tl.store(Mean_ptr + rows_off, mean)
                tl.store(RSTD_ptr + rows_off, rstd)
            else:
                tl.store(Mean_ptr + rows_off, mean, mask=rows_mask)
                tl.store(RSTD_ptr + rows_off, rstd, mask=rows_mask)

        if DROP_COLS_MASK:
            w_chunk = tl.load(W_ptr + cols_off).to(tl.float32)
            b_chunk = tl.load(B_ptr + cols_off).to(tl.float32)
        else:
            w_chunk = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(
                tl.float32
            )
            b_chunk = tl.load(B_ptr + cols_off, mask=cols_mask, other=0.0).to(
                tl.float32
            )

        y_chunk = x_centered * rstd[:, None] * w_chunk[None, :] + b_chunk[None, :]

        if DROP_ROWS_MASK:
            if DROP_COLS_MASK:
                tl.store(
                    Y_ptr_row_block + cols_off[None, :],
                    y_chunk.to(Y_ptr.dtype.element_ty),
                )
            else:
                tl.store(
                    Y_ptr_row_block + cols_off[None, :],
                    y_chunk.to(Y_ptr.dtype.element_ty),
                    mask=cols_mask[None, :],
                )
        else:
            tl.store(
                Y_ptr_row_block + cols_off[None, :],
                y_chunk.to(Y_ptr.dtype.element_ty),
                mask=block_mask,
            )


@libentry()
@triton.heuristics({"BLOCK_SIZE_M": lambda args: ceil_div(4096, args["n_cols"])})
@triton.jit
def _layernorm_bwd_kernel(
    DY_ptr,
    DX_ptr,
    DW_ptr,
    DB_ptr,
    X_ptr,
    W_ptr,
    Mean_ptr,
    RSTD_ptr,
    stride_dy_row,
    stride_dx_row,
    stride_x_row,
    n_rows,
    n_cols,
    X_dtype: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(0)
    num_programs = tl.num_programs(0)

    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M

    cols_off = tl.arange(0, BLOCK_SIZE_N)
    cols_mask = cols_off < n_cols

    dW_acc = tl.zeros((BLOCK_SIZE_N,), dtype=tl.float32)
    dB_acc = tl.zeros((BLOCK_SIZE_N,), dtype=tl.float32)

    w = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

    for row_task_id in range(pid, num_row_tasks, num_programs):
        block_start_row = row_task_id * BLOCK_SIZE_M
        rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)
        rows_mask = rows_off < n_rows
        block_mask = rows_mask[:, None] & cols_mask[None, :]

        mean = tl.load(Mean_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)
        rstd = tl.load(RSTD_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)

        dy = tl.load(
            DY_ptr + rows_off[:, None] * stride_dy_row + cols_off[None, :],
            mask=block_mask,
            other=0.0,
        ).to(tl.float32)

        x = tl.load(
            X_ptr + rows_off[:, None] * stride_x_row + cols_off[None, :],
            mask=block_mask,
            other=0.0,
        ).to(tl.float32)

        x_hat = (x - mean[:, None]) * rstd[:, None]

        dW_acc += tl.sum(dy * x_hat, axis=0)
        dB_acc += tl.sum(dy, axis=0)

        wdy = w[None, :] * dy
        c1 = tl.sum(x_hat * wdy, axis=1) / n_cols
        c2 = tl.sum(wdy, axis=1) / n_cols
        dx = (wdy - (x_hat * c1[:, None] + c2[:, None])) * rstd[:, None]

        tl.store(
            DX_ptr + rows_off[:, None] * stride_dx_row + cols_off[None, :],
            dx.to(X_dtype),
            mask=block_mask,
        )

    tl.atomic_add(DW_ptr + cols_off, dW_acc, mask=cols_mask)
    tl.atomic_add(DB_ptr + cols_off, dB_acc, mask=cols_mask)


@libentry()
@triton.jit
def _layernorm_bwd_large_cols_kernel(
    DY_ptr,
    DX_ptr,
    DW_ptr,
    DB_ptr,
    X_ptr,
    W_ptr,
    Mean_ptr,
    RSTD_ptr,
    stride_dy_row,
    stride_dx_row,
    stride_x_row,
    n_rows,
    n_cols,
    X_dtype: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(0)
    num_programs = tl.num_programs(0)

    num_row_tasks = (n_rows + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M

    for row_task_id in range(pid, num_row_tasks, num_programs):
        block_start_row = row_task_id * BLOCK_SIZE_M
        rows_off = block_start_row + tl.arange(0, BLOCK_SIZE_M)
        rows_mask = rows_off < n_rows

        mean = tl.load(Mean_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)
        rstd = tl.load(RSTD_ptr + rows_off, mask=rows_mask, other=0.0).to(tl.float32)

        c1_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)
        c2_acc = tl.zeros((BLOCK_SIZE_M,), dtype=tl.float32)

        for col_offset in range(0, n_cols, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
            cols_mask = cols_off < n_cols
            block_mask = rows_mask[:, None] & cols_mask[None, :]

            dy = tl.load(
                DY_ptr + rows_off[:, None] * stride_dy_row + cols_off[None, :],
                mask=block_mask,
                other=0.0,
            ).to(tl.float32)

            x = tl.load(
                X_ptr + rows_off[:, None] * stride_x_row + cols_off[None, :],
                mask=block_mask,
                other=0.0,
            ).to(tl.float32)

            w = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

            x_hat = (x - mean[:, None]) * rstd[:, None]
            wdy = w[None, :] * dy

            c1_acc += tl.sum(x_hat * wdy, axis=1)
            c2_acc += tl.sum(wdy, axis=1)

        c1 = c1_acc / n_cols
        c2 = c2_acc / n_cols

        for col_offset in range(0, n_cols, BLOCK_SIZE_N):
            cols_off = col_offset + tl.arange(0, BLOCK_SIZE_N)
            cols_mask = cols_off < n_cols
            block_mask = rows_mask[:, None] & cols_mask[None, :]

            dy = tl.load(
                DY_ptr + rows_off[:, None] * stride_dy_row + cols_off[None, :],
                mask=block_mask,
                other=0.0,
            ).to(tl.float32)

            x = tl.load(
                X_ptr + rows_off[:, None] * stride_x_row + cols_off[None, :],
                mask=block_mask,
                other=0.0,
            ).to(tl.float32)

            w = tl.load(W_ptr + cols_off, mask=cols_mask, other=0.0).to(tl.float32)

            x_hat = (x - mean[:, None]) * rstd[:, None]
            wdy = w[None, :] * dy

            dW_chunk = tl.sum(dy * x_hat, axis=0)
            dB_chunk = tl.sum(dy, axis=0)

            dx = (wdy - (x_hat * c1[:, None] + c2[:, None])) * rstd[:, None]

            tl.store(
                DX_ptr + rows_off[:, None] * stride_dx_row + cols_off[None, :],
                dx.to(X_dtype),
                mask=block_mask,
            )

            tl.atomic_add(DW_ptr + cols_off, dW_chunk, mask=cols_mask)
            tl.atomic_add(DB_ptr + cols_off, dB_chunk, mask=cols_mask)


def _layernorm_fwd_grid(n_rows: int, n_cols: int, x_dtype: torch.dtype) -> tuple[int]:
    block_m = layer_norm_fwd_heuristics(
        {"n_rows": n_rows, "n_cols": n_cols, "x_dtype": x_dtype}
    )
    num_row_tasks = ceil_div(n_rows, block_m)
    num_vectorcores = get_num_cores("vector")
    return (max(1, min(num_vectorcores, num_row_tasks)),)


def _launch_layernorm_fwd_kernel(
    x_2d,
    y,
    weight,
    bias,
    mean,
    rstd,
    n_rows,
    n_cols,
    eps,
    block_size_n,
    store_stats: bool,
):
    use_single_pass = n_cols <= SINGLE_PASS_THRESHOLD
    num_programs = get_num_cores()
    grid = (num_programs,)

    if use_single_pass:
        block_size_n = triton.next_power_of_2(n_cols)
        drop_cols_mask = n_cols % block_size_n == 0
        _layernorm_fwd_single_pass_kernel[grid](
            x_2d,
            y,
            weight,
            bias,
            mean,
            rstd,
            x_2d.stride(0),
            y.stride(0),
            n_rows,
            n_cols,
            eps,
            DROP_COLS_MASK=drop_cols_mask,
            DROP_ROWS_MASK=False,
            STORE_STATS=store_stats,
            BLOCK_SIZE_N=block_size_n,
        )
        return

    if n_cols > 8192:
        block_size_m = 2
        block_size_n = 4096
        block_size_n_pass1 = 8192
    else:
        block_size_m = 2
        block_size_n = 2048
        block_size_n_pass1 = 8192

    drop_cols_mask = n_cols % block_size_n == 0
    drop_rows_mask = n_rows % block_size_m == 0

    _layernorm_fwd_kernel[grid](
        x_2d,
        y,
        weight,
        bias,
        mean,
        rstd,
        x_2d.stride(0),
        y.stride(0),
        n_rows,
        n_cols,
        eps,
        DROP_COLS_MASK=drop_cols_mask,
        DROP_ROWS_MASK=drop_rows_mask,
        STORE_STATS=store_stats,
        BLOCK_SIZE_N=block_size_n,
        BLOCK_SIZE_N_PASS1=block_size_n_pass1,
        BLOCK_SIZE_M=block_size_m,
    )


def layernorm_infer_impl(
    hidden_states: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor,
    eps: float,
) -> torch.Tensor:
    shape = hidden_states.shape
    dim = shape[-1]
    x_2d = hidden_states.reshape(-1, dim)
    n_rows, n_cols = x_2d.shape

    if n_cols <= SINGLE_PASS_THRESHOLD:
        BLOCK_SIZE_N = triton.next_power_of_2(n_cols)
    else:
        BLOCK_SIZE_N = TWO_PASS_BLOCK_SIZE_N

    y = torch.empty_like(x_2d)

    _launch_layernorm_fwd_kernel(
        x_2d,
        y,
        weight,
        bias,
        y,
        y,
        n_rows,
        n_cols,
        eps,
        BLOCK_SIZE_N,
        store_stats=False,
    )

    return y.reshape(*shape)


def layernorm_fwd_impl(x, w, b, eps):
    shape = x.shape
    dim = shape[-1]
    x_2d = x.reshape(-1, dim)
    n_rows, n_cols = x_2d.shape

    if n_cols  <= SINGLE_PASS_THRESHOLD:
        BLOCK_SIZE_N = triton.next_power_of_2(n_cols)
    else:
        BLOCK_SIZE_N = TWO_PASS_BLOCK_SIZE_N

    y = torch.empty_like(x_2d)
    mean = torch.empty(n_rows, dtype=torch.float32, device=x.device)
    rstd = torch.empty(n_rows, dtype=torch.float32, device=x.device)

    _launch_layernorm_fwd_kernel(
        x_2d, y, w, b, mean, rstd, n_rows, n_cols, eps, BLOCK_SIZE_N, store_stats=True
    )

    return y.reshape(*shape), x_2d, mean, rstd


def layernorm_bwd_impl(dy, x_2d, w, b, mean, rstd):
    shape = dy.shape
    dim = shape[-1]
    dy_2d = dy.reshape(-1, dim)
    n_rows, n_cols = dy_2d.shape

    if n_cols > COL_BLOCKING_THRESHOLD:
        BLOCK_SIZE_N = TWO_PASS_BLOCK_SIZE_N
    else:
        BLOCK_SIZE_N = align(x_2d, n_cols, VEC_ALIGN_BYTES)

    num_programs = get_num_cores("vector")
    grid = (num_programs,)

    dx = torch.empty_like(dy_2d)

    if n_cols <= COL_BLOCKING_THRESHOLD:
        dw = torch.zeros(n_cols, dtype=torch.float32, device=w.device)
        db = torch.zeros(n_cols, dtype=torch.float32, device=b.device)

        _layernorm_bwd_kernel[grid](
            dy_2d,
            dx,
            dw,
            db,
            x_2d,
            w,
            mean,
            rstd,
            dy_2d.stride(0),
            dx.stride(0),
            x_2d.stride(0),
            n_rows,
            n_cols,
            torch_to_triton_dtype[x_2d.dtype],
            BLOCK_SIZE_N=BLOCK_SIZE_N,
        )
    else:
        dw = torch.zeros(n_cols, dtype=torch.float32, device=w.device)
        db = torch.zeros(n_cols, dtype=torch.float32, device=b.device)

        _layernorm_bwd_large_cols_kernel[grid](
            dy_2d,
            dx,
            dw,
            db,
            x_2d,
            w,
            mean,
            rstd,
            dy_2d.stride(0),
            dx.stride(0),
            x_2d.stride(0),
            n_rows,
            n_cols,
            torch_to_triton_dtype[x_2d.dtype],
            BLOCK_SIZE_N=BLOCK_SIZE_N,
            BLOCK_SIZE_M=2,
        )

    dw = dw.to(w.dtype)
    db = db.to(b.dtype)

    return dx.reshape(*shape), dw, db


@torch.library.custom_op("mojo_npu_triton_a5::layer_norm_infer", mutates_args=())
def layer_norm_infer_fwd(
    x: torch.Tensor, weight: Optional[torch.Tensor], bias: Optional[torch.Tensor], eps: float,
) -> torch.Tensor:
    weight = x.new_ones(x.shape[-1]) if weight is None else weight.contiguous()
    bias = x.new_zeros(x.shape[-1]) if bias is None else bias.contiguous()
    return layernorm_infer_impl(x.contiguous(), weight, bias, eps)


@layer_norm_infer_fwd.register_fake
def _layer_norm_infer_fake(x, weight, bias, eps):
    return torch.empty_like(x, memory_format=torch.contiguous_format)
