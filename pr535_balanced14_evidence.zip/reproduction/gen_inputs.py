from tests._convert_req_index_balanced import CASES, build_inputs as _build
import os
def selected():
 ids=os.environ.get("GEN_CASE_IDS");return [c for c in CASES if not ids or c["id"] in ids.split(",")]
def build_inputs(c):return _build(c,"npu:0")
