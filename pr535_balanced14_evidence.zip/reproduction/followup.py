from pathlib import Path
import json,os,subprocess,sys,hashlib
r=Path.cwd();arch=sys.argv[1];card=sys.argv[2]
os.environ.update(ASCEND_RT_VISIBLE_DEVICES=card,PYTHONPATH=str(r/'repo'),TRITON_CACHE_DIR=str(r/'cache'),OMP_NUM_THREADS='2',MKL_NUM_THREADS='2')
with (r/'logs/pytest_performance.log').open('w') as f:
 p=subprocess.run([sys.executable,'-m','pytest','tests/performance/functions/test_triton_convert_req_index_to_global_index.py','--mojo-target=npu.'+arch,'--mojo-implementation=triton','--perf-timers=profiler','--perf-warmup=10','--perf-repeats=20','--perf-output='+str(r/'results/repository_performance.json'),'--junitxml='+str(r/'results/pytest_performance.xml'),'-q'],cwd=r/'repo',stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
sys.path.insert(0,str(r/'repo'))
from tests._convert_req_index_balanced import CASES,small_inputs,token_chunk
out=[]
for c in CASES:
 req,table,pos=small_inputs(c);h=hashlib.sha256()
 for i in range(0,c['num_tokens'],1024):h.update(token_chunk(c,req,pos,i,min(i+1024,c['num_tokens'])).tobytes())
 out.append(dict(id=c['id'],req_sha256=hashlib.sha256(req.tobytes()).hexdigest(),table_sha256=hashlib.sha256(table.tobytes()).hexdigest(),tokens_sha256=h.hexdigest()))
(r/'results/fingerprints.json').write_text(json.dumps(out,indent=2));print('FOLLOWUP_COMPLETE',flush=True)
