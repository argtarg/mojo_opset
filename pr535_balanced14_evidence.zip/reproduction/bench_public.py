# api-name: ModelNew
# api-kind: torch-module
# kernels: _convert_req_index_kernel,_convert_small_req_index_kernel
import os
from gen_inputs import selected,build_inputs

def build_operator_api(operator_module):return operator_module.ModelNew().npu().eval()
def build_bench_cases():return [dict(c,warmup=100,repeats=40) for c in selected()]
def build_bench_case_fn(operator_api,case):
    c={k:v for k,v in case.items() if k not in ['warmup','repeats']};xs=build_inputs(c)
    def run():return operator_api(*xs)
    return run
