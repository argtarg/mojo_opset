from pathlib import Path
import json,os,subprocess,sys,time,traceback
r=Path(__file__).resolve().parent;os.chdir(r);arch=sys.argv[1];card=sys.argv[2]
env=os.environ.copy();env.update(ASCEND_RT_VISIBLE_DEVICES=card,OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',PYTHONPATH=str(r/'repo')+':'+str(r),TRITON_CACHE_DIR=str(r/'cache'),HELIX_BENCH_OUTPUT_DIR=str(r/'profile'),PYTHONUNBUFFERED='1',HELIX_EVAL_TIMEOUT_SECONDS='1800',O=str(r))
(r/'logs').mkdir(exist_ok=True);(r/'results').mkdir(exist_ok=True);state={'status':'running','steps':[]}
def run(tag,cmd,timeout=10800):
 state['current']=tag;(r/'progress.json').write_text(json.dumps(state,indent=2));start=time.time()
 with (r/'logs'/(tag+'.log')).open('w') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,cwd=r/'repo')
 state['steps'].append({'tag':tag,'rc':p.returncode,'seconds':time.time()-start});assert p.returncode==0,(tag,(r/'logs'/(tag+'.log')).read_text()[-4000:])
try:
 run('npu_smi_before',['npu-smi','info'],30)
 os.environ.update(env)
 import torch,torch_npu,triton
 torch.npu.set_device(0);free,total=torch.npu.mem_get_info(0);assert free//1048576>=49152
 (r/'environment.json').write_text(json.dumps(dict(torch=torch.__version__,torch_npu=torch_npu.__version__,triton=triton.__version__,python=sys.version,soc=torch.npu.get_device_name(0),physical_card=card,logical_device=0,free_mb=free//1048576,cann=os.environ.get('ASCEND_HOME_PATH'),frequency_lock=False),indent=2))
 if arch=='a5':assert torch.__version__.startswith('2.7.1')
 run('pytest',[sys.executable,'-m','pytest','tests/functions/test_triton_convert_req_index_to_global_index.py','--mojo-target=npu.'+arch,'--mojo-implementation=triton','-q','--junitxml='+str(r/'results/pytest.xml')])
 run('copy_pre',[sys.executable,str(r/'calibrate.py'),'pre'])
 cli=r/'.agents/skills/triton-npu-run-eval/scripts/cli.py'
 for mode in (['hot','cold'] if arch=='a5' else ['cold']):
  env['GLM_CLEAR_L2']='1' if mode=='cold' else '0'
  for i in [1,2]:
   tag=mode+'_round'+str(i);run(tag,[sys.executable,str(cli),'run-bench','--bench-file',str(r/'bench_public.py'),'--operator-file',str(r/'public_operator.py'),'--output',str(r/'results'/(tag+'_perf.txt')),'--metric-source','kernel','--verbose'])
 run('copy_post',[sys.executable,str(r/'calibrate.py'),'post'])
 run('npu_smi_after',['npu-smi','info'],30)
 state['status']='complete'
except BaseException:state.update(status='failed',error=traceback.format_exc())
(r/'progress.json').write_text(json.dumps(state,indent=2));print(json.dumps(state),flush=True)
