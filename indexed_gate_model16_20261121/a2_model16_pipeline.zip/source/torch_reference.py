# SPDX-License-Identifier: Apache-2.0
# Derived standalone adapter; original upstream files are preserved in upstream/.
"""Torch oracle derived from upstream tests, preserving GPU BF16 boundaries.

The kernel explicitly casts residual + gate * branch to BF16 before RMSNorm.
This adapter covers the upstream BF16 cases and rejects other residual dtypes.
It is a numerical reference, not a bitwise Triton reduction/FMA emulator.
"""
import torch


def indexed_gate_rms_norm_scale_shift(residual, gate, branch, weight,
                                     shift, scale, indices, eps):
    if residual.dtype != torch.bfloat16:
        raise ValueError('This reference covers the upstream BF16 contract only')
    selected_gate = gate.index_select(0, indices).float()
    residual_out = (residual.float() + selected_gate * branch.float()).to(torch.bfloat16)
    updated = residual_out.float()
    variance = (updated * updated).mean(dim=-1, keepdim=True)
    normalized = updated * torch.rsqrt(variance + eps) * weight.float()
    selected_shift = shift.index_select(0, indices).float()
    selected_scale = scale.index_select(0, indices).float()
    output = (normalized * (1.0 + selected_scale) + selected_shift).to(residual.dtype)
    return residual_out, output
