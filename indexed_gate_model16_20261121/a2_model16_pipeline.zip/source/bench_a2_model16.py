# api-name: ModelNew
# api-kind: torch-module
# kernels: _indexed_gate_rms_shift_kernel
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from model_inputs import CASES,build_inputs
import torch,triton,triton.language as tl
@triton.jit
def _a2_harness_flush(P,N:tl.constexpr,C:tl.constexpr):
 off=tl.arange(0,8192)
 for base in range(tl.program_id(0)*8192,N,C*8192):
  v=tl.load(P+base+off);tl.store(P+base+off,v+1.)
def build_operator_api(operator_module):return operator_module.ModelNew().npu().eval()
def build_bench_cases():return [dict(c,warmup=5,repeats=10) for c in CASES]
def build_bench_case_fn(operator_api,case):
 import triton.runtime.driver as driver
 cores=int(driver.active.utils.get_device_properties(0)['num_vectorcore'])
 data=[build_inputs(case,i) for i in range(2)];index=0
 buffer=torch.zeros((1024**3//4,),device='npu',dtype=torch.float32)
 def call():
  nonlocal index
  _a2_harness_flush[(cores,)](buffer,N=buffer.numel(),C=cores);torch.npu.synchronize()
  args=data[index%2];index+=1
  return operator_api(*args)
 return call

