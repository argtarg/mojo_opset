from pathlib import Path
import csv,hashlib,json,statistics,zipfile
R=Path('/home/tangbiao/igrss_a2_model16_20261118');S=R/'suite';D=R/'a2_bound_20261121'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
state=load(D/'activity.json');assert state['complete']
assert (D/'exit.txt').read_text().strip()=='0'
assert sha(S/'opt_indexed_gate.py')==state['source_sha256']=='bfbf04aef961984bc0050be36e9bd0e58fdef703a2bbbd276c76eaa811434c20'
specs=load(S/'model_cases.json')['cases'];valid={c['case_id']:c for c in state['cases'] if c['usable']}
assert set(valid)=={c['id'] for c in specs} and len(valid)==16
prior=load(S/'cold_device_card7/results.json');assert prior['complete'] and prior['operator_sha256']==state['source_sha256']
prior_cases={c['case_id']:c for c in prior['cases']}
pipes=('Vector','MTE2','MTE3','Scalar');rows=[];audit=[]
for case in specs:
 c=valid[case['id']];p=D/c['raw_csv'];assert sha(p)==c['raw_csv_sha256']
 assert not c['foreign_pids_seen_after'] and c['flush_pairs_verified']==c['profile_calls']==10
 for key in ('fused','table_copies','full_forward'):assert c[key]['valid']
 q=dict(case_id=case['id'],rows=case['rows'],hidden_size=case['hidden_size'],conditions=case['conditions'],active_conditions=case['active_conditions'],eps=case['eps'],no_pmu_fused_us=prior_cases[case['id']]['summary']['fused_kernel_us'],no_pmu_copy_us=prior_cases[case['id']]['summary']['table_copy_us'],no_pmu_full_us=prior_cases[case['id']]['summary']['device_total_us'],pmu_fused_us=c['pmu_fused_us']['avg'],pmu_fused_min_us=c['pmu_fused_us']['min'],pmu_fused_max_us=c['pmu_fused_us']['max'],pmu_copy_us=c['pmu_copy_us_avg'],pmu_full_us=c['pmu_full_forward_us_avg'])
 for key in ('fused','table_copies','full_forward'):
  q[key+'_dominant_activity']=c[key]['dominant_activity']
  for pipe in pipes:q[key+'_'+pipe+'_pct']=c[key]['activity_pct'][pipe]
 rows.append(q)
 audit.append(dict(case_id=case['id'],csv=c['raw_csv'],sha256=sha(p),calls=10,flush_pairs=10,ratio_units=c['fused']['ratio_units'],selected_attempt=c['attempt']))
with (D/'a2_model16_bound_with_time.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=dict(success=True,total_cases=16,valid_cases=16,source_sha256=state['source_sha256'],host=state['host'],physical_device=7,clear_l2=True,flush_mib=1024,frequency_locked=False,pmu=state['pmu'],calls_verified=160,table_copy_kernel_records=480,flush_pairs_verified=160,activity_formula=state['activity_formula'],interpretation='Overlapping AIV engine activity; not MBU or a proof of the critical path',pmu_duration_policy='diagnostic only; retained no-PMU cold timing and MBU unchanged',cases=rows)
(D/'summary.json').write_text(json.dumps(summary,indent=2));(D/'csv_audit.json').write_text(json.dumps(audit,indent=2))
text=['# A2 新16例：清L2板端bound', '',
      '采集日期：2026-11-21（Asia/Shanghai）。原A2最优版源码不变，物理卡7、逻辑0。原有16/16精度通过及输入冻结哈希已核对。', '',
      '使用triton-npu-run-eval的profile-bench逐case调用torch_npu.profiler，PipeUtilization/Level1；每次调用前用1GiB缓冲区读写驱逐并同步。每例10次正式调用，两个输入交替；160次调用均已核验驱逐配对。三次表连续化仍在public forward内部，未移出采集。', '',
      '按对应pipe_time/aiv_time验证_ratio单位后，使用100*sum(pipe_time)/sum(aiv_time)汇总。下面是融合kernel的活动率百分数，可重叠，不表示互斥时间份额、MBU或已证明的关键路径。完整device与表搬运的活动率单独保留在CSV。', '',
      '本轮PMU时长仅作诊断；11月19日独立no-PMU清L2时间与69.82%总量MBU不被替换。观察到其他同卡进程的尝试保留且不采用；选取每例首个可用尝试。', '',
      '| Case | Rows | C/活跃 | Vector% | MTE2% | MTE3% | Scalar% |', '|---|---:|---:|---:|---:|---:|---:|']
for q in rows:text.append(f"| {q['case_id']} | {q['rows']} | {q['conditions']}/{q['active_conditions']} | {q['fused_Vector_pct']:.2f} | {q['fused_MTE2_pct']:.2f} | {q['fused_MTE3_pct']:.2f} | {q['fused_Scalar_pct']:.2f} |")
text+=['', '输入按固定模型源码重建，非模型checkpoint实跑trace；H=5376、eps=1e-5、条件表stride=(32256,1)，详情见model_cases.json。', '',f"源码SHA256：`{summary['source_sha256']}`。全部保留及未采用尝试的原始kernel_details.csv、profile日志、统计CSV及快照随包归档；完整profiler目录留在远端。"]
(D/'report.md').write_text('\n'.join(text)+'\n')
files={}
for p in D.rglob('*'):
 if p.is_file() and (p.name in ('kernel_details.csv','result.json','profile.log') or p.parent==D):files[p.relative_to(D).as_posix()]=p.read_bytes()
for name in ('opt_indexed_gate.py','model_cases.json','frozen_inputs.json','bench_a2_model16.py','correctness_receipt.json','torch_reference.py'):
 files['source/'+name]=(S/name).read_bytes()
files['scripts/collect_a2_model16_bound.py']=(R/'collect_a2_model16_bound.py').read_bytes()
files['scripts/package_a2_model16_bound.py']=Path(__file__).read_bytes()
manifest={name:hashlib.sha256(data).hexdigest() for name,data in files.items()};files['manifest.json']=json.dumps(manifest,indent=2).encode()
archive=R/'a2_model16_cold_bound_20261121.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in files.items():z.writestr(name,data)
print(json.dumps(dict(archive=str(archive),archive_sha256=sha(archive),size=archive.stat().st_size,valid_cases=16,verified_calls=160,manifest_entries=len(manifest)),indent=2))

