"""Cold-L2 PipeUtilization capture through the bundled profile-bench helper."""
from pathlib import Path
import csv,datetime,hashlib,json,math,os,re,shutil,statistics,subprocess,sys,time,zipfile
R=Path('/home/tangbiao/igrss_a2_model16_20261118')
S=R/'suite';D=R/'a2_bound_20261121';D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
expected='bfbf04aef961984bc0050be36e9bd0e58fdef703a2bbbd276c76eaa811434c20'
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']=='7'
assert sha(S/'opt_indexed_gate.py')==expected
quality=read(S/'correctness_receipt.json');assert quality['passed'] and quality['passed_cases']==quality['total_cases']==16 and quality['operator_sha256']==expected
for name,h in read(S/'frozen_inputs.json').items():assert sha(S/name)==h,name
cases=read(S/'model_cases.json')['cases'];assert len(cases)==16
cli=R/'.agents/skills/triton-npu-run-eval/scripts/cli.py'
state=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256=expected,collector_sha256=sha(Path(__file__)),host='179.184.3.2',physical_device=7,logical_device=0,clear_l2=True,flush_mib=1024,frequency_locked=False,pmu='PipeUtilization Level1 via profile-bench',pipeline_scope='fused,3 internal contiguous copies,and full public forward; eviction excluded',activity_formula='100*sum(pipe_time_us)/sum(aiv_time_us)',timing_is_pmu_diagnostic_only=True,snapshots=[],cases=[])
if (D/'activity.json').exists():
 state=read(D/'activity.json');assert state['source_sha256']==expected
 state['resumed_collector_sha256']=sha(Path(__file__))
def save():(D/'activity.json').write_text(json.dumps(state,indent=2))
def snapshot(label,wait=True):
 for attempt in range(1800):
  cp=subprocess.run(['npu-smi','info','-t','proc-mem','-i','7'],capture_output=True,text=True,timeout=5,check=True)
  pids=list(map(int,re.findall(r'Process id:\s*(\d+)',cp.stdout)))
  state['snapshots'].append(dict(label=label,pids=pids,raw=cp.stdout));save()
  if not pids:return False
  if not wait:return True
  if attempt%60==0:print('WAIT_OTHER_TASK',label,pids,flush=True)
  time.sleep(1)
 raise RuntimeError('No isolated profiling window on card7')
PIPES=dict(Vector='aiv_vec',MTE2='aiv_mte2',MTE3='aiv_mte3',Scalar='aiv_scalar')
def activity(rows):
 avsum=0.;times={k:0. for k in PIPES};units=set();issues=[]
 for row in rows:
  try:
   av=float(row['aiv_time(us)']);assert math.isfinite(av) and av>0
   for label,key in PIPES.items():
    value=float(row[key+'_time(us)']);ratio=float(row[key+'_ratio']);assert math.isfinite(value) and 0<=value<=av*1.02
    frac=value/av
    if frac>.001:
     if abs(ratio-frac)<=.003:units.add('fraction')
     elif abs(ratio/100-frac)<=.003:units.add('percent')
     else:issues.append(key+':ratio/time mismatch')
    times[label]+=value
   avsum+=av
  except (AssertionError,ValueError,KeyError) as e:issues.append('invalid AIV counters:'+str(e))
 valid=bool(rows) and avsum>0 and len(units)==1 and not issues
 pct={k:100*t/avsum for k,t in times.items()} if valid else None
 return dict(valid=valid,records=len(rows),ratio_units=sorted(units),issues=issues,aiv_time_sum_us=avsum,pipe_time_sum_us=times,activity_pct=pct,dominant_activity=max(pct,key=pct.get) if pct else None)

for case in cases:
 cid=case['id']
 if any(c['case_id']==cid and c['usable'] for c in state['cases']):continue
 for attempt in range(1,5):
  dest=D/cid/f'attempt{attempt}'
  if dest.exists():continue
  snapshot(cid+'_before');assert sha(S/'opt_indexed_gate.py')==expected
  dest.mkdir(parents=True);log=dest/'profile.log'
  with log.open('w') as f:
   cp=subprocess.run([sys.executable,str(cli),'profile-bench','--bench-file','bench_a2_model16.py','--operator-file','opt_indexed_gate.py','--case-id',cid,'--target-op','_indexed_gate_rms_shift_kernel'],cwd=S,stdout=f,stderr=subprocess.STDOUT)
  contaminated=snapshot(cid+'_after',wait=False)
  profile=None
  for line in log.read_text().splitlines():
   if not line.startswith('{'):continue
   try:event=json.loads(line)
   except json.JSONDecodeError:continue
   if event.get('kind')=='final' and event.get('phase')=='profile':profile=event['data'].get('profile_dir')
  item=dict(case_id=cid,rows=case['rows'],hidden_size=case['hidden_size'],conditions=case['conditions'],active_conditions=case['active_conditions'],attempt=attempt,return_code=cp.returncode,foreign_pids_seen_after=contaminated,usable=False)
  if cp.returncode==0 and profile:
   profile=Path(profile).resolve()
   outer=next(p for p in profile.parents if p.parent==S)
   assert outer.name.startswith('PROF_'+cid+'_') and outer.is_relative_to(S)
   preserved=dest/'profile';shutil.move(str(outer),str(preserved))
   paths=list(preserved.rglob('kernel_details.csv'));assert len(paths)==1,paths
   with paths[0].open() as f:rows=[q for q in csv.DictReader(f) if float(q['Duration(us)'])>0]
   rows.sort(key=lambda q:float(q['Start Time(us)']))
   groups=[];pending=[];evicted=False;flushes=0
   for q in rows:
    assert int(q['Device_id'])==7
    if '_a2_harness_flush' in q['Name']:
     assert not pending and not evicted
     assert list(map(int,re.findall(r'\d+',q['Input Shapes'])))==[2**28]
     evicted=True;flushes+=1;continue
    pending.append(q)
    if '_indexed_gate_rms_shift_kernel' in q['Name']:
     assert evicted and len(pending)==4 and all('InplaceCopy' in t['Name'] for t in pending[:-1])
     groups.append(pending);pending=[];evicted=False
   assert not pending and not evicted and len(groups)==flushes==10,(cid,len(groups),flushes)
   fused=[g[-1] for g in groups];copies=[q for g in groups for q in g[:-1]];whole=[q for g in groups for q in g]
   item.update(raw_csv=str(paths[0].relative_to(D)),raw_csv_sha256=sha(paths[0]),profile_calls=10,flush_pairs_verified=10,fused=activity(fused),table_copies=activity(copies),full_forward=activity(whole))
   item['usable']=not contaminated and item['fused']['valid'] and item['table_copies']['valid'] and item['full_forward']['valid']
   durations=[float(q['Duration(us)']) for q in fused]
   item['pmu_fused_us']=dict(total=sum(durations),avg=statistics.mean(durations),min=min(durations),max=max(durations))
   item['pmu_copy_us_avg']=sum(float(q['Duration(us)']) for q in copies)/10
   item['pmu_full_forward_us_avg']=sum(float(q['Duration(us)']) for q in whole)/10
  (dest/'result.json').write_text(json.dumps(item,indent=2));state['cases'].append(item);save()
  print('A2_BOUND',cid,attempt,item['usable'],item.get('fused',{}).get('activity_pct'),flush=True)
  if item['usable']:break
 else:raise RuntimeError('Cannot obtain usable PMU: '+cid)
valid={c['case_id']:c for c in state['cases'] if c['usable']};assert set(valid)=={c['id'] for c in cases}
state['complete']=True;save()
rows=[]
for case in cases:
 c=valid[case['id']];q=dict(case_id=c['case_id'],rows=c['rows'],hidden_size=c['hidden_size'],conditions=c['conditions'],active_conditions=c['active_conditions'],pmu_fused_us_avg=c['pmu_fused_us']['avg'],pmu_copy_us_avg=c['pmu_copy_us_avg'],pmu_full_forward_us_avg=c['pmu_full_forward_us_avg'])
 for component in ('fused','table_copies','full_forward'):
  for pipe in PIPES:q[component+'_'+pipe+'_pct']=c[component]['activity_pct'][pipe]
 rows.append(q)
with (D/'a2_model16_bound.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('A2_MODEL16_BOUND_COMPLETE',flush=True)

