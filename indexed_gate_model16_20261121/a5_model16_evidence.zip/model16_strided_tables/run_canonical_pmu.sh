#!/bin/bash
source /home/t00985010/indexed_gate_strided_tables_20261121_110935_9e77/environment.sh
cli=/home/t00985010/indexed_gate_optimizer_20261117_2125_3908/.agents/skills/triton-npu-run-eval/scripts/cli.py
python "$cli" run-bench --bench-file bench_indexed_gate.py --operator-file opt-round-1/opt_indexed_gate.py --baseline-operator-file baseline/indexed_gate.py --output opt-round-1/opt_indexed_gate_perf.txt --metric-source total-op > canonical_totalop.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > canonical_pmu_exit.txt; exit "$rc"; fi
python "$cli" compare-perf --baseline baseline/indexed_gate_perf.txt --compare opt-round-1/opt_indexed_gate_perf.txt --metric-source kernel > canonical_kernel_view.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > canonical_pmu_exit.txt; exit "$rc"; fi
python "$cli" compare-perf --baseline baseline/indexed_gate_perf.txt --compare opt-round-1/opt_indexed_gate_perf.txt --metric-source total-op > canonical_totalop_view.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > canonical_pmu_exit.txt; exit "$rc"; fi
python paired_stride.py --phase pmu --cases all --pmu > pmu_driver.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > canonical_pmu_exit.txt; exit "$rc"; fi
python calibrate_copy.py after > calibration_after.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > canonical_pmu_exit.txt; exit "$rc"; fi
python finalize_stride.py > finalize_stride.log 2>&1
rc=$?;echo "$rc" > canonical_pmu_exit.txt
exit "$rc"
