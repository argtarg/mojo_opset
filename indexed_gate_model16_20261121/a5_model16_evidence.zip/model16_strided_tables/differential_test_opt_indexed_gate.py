# test-mode: differential
# compute-kind: compute
# api-name: ModelNew
# api-kind: torch-module
# kernels: _indexed_gate_rms_shift_kernel, _indexed_gate_rms_shift_cached_kernel, _indexed_gate_rms_shift_row_kernel, _indexed_gate_rms_shift_two_tile_kernel, _indexed_gate_rms_shift_native_wide_kernel, _indexed_gate_rms_shift_table_kernel
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from model_inputs import CASES,build_inputs,check_frozen
def build_operator_api(operator_module):return operator_module.ModelNew().npu().eval()
def build_differential_test_cases(operator_api):
 check_frozen()
 for case in CASES:
  inputs=build_inputs(case)
  yield dict(id=case['id'],inputs=inputs,fn=lambda inputs=inputs:operator_api(*inputs))
