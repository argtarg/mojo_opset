# test-mode: standalone
# compute-kind: compute
# api-name: ModelNew
# api-kind: torch-module
# kernels: _indexed_gate_rms_shift_kernel, _indexed_gate_rms_shift_cached_kernel, _indexed_gate_rms_shift_row_kernel, _indexed_gate_rms_shift_two_tile_kernel, _indexed_gate_rms_shift_native_wide_kernel, _indexed_gate_rms_shift_table_kernel
"""Stream frozen BF16 model cases through independent oracle and official comparator."""
from pathlib import Path
import gc,hashlib,json,sys
import torch,torch_npu
from npu_compare import compare_case_result
from model_inputs import CASES,build_inputs,check_frozen
from oracle_model import ModelNew as Oracle

SELECTED_IDS=None

def main(operator_api):
    check_frozen();torch.set_grad_enabled(False)
    source=Path(operator_api.forward.__func__.__code__.co_filename).resolve()
    selected=CASES if SELECTED_IDS is None else [c for c in CASES if c['id'] in SELECTED_IDS]
    assert selected and (SELECTED_IDS is None or len(selected)==len(SELECTED_IDS))
    oracle=Oracle().npu().eval();records=[]
    for case in selected:
        inputs=build_inputs(case)
        # The independent oracle returns new storage; freeze before DUT execution.
        expected=tuple(x.detach().clone() for x in oracle(*inputs))
        actual=operator_api(*inputs)
        result=compare_case_result(case_id=case['id'],actual=actual,golden=expected,inputs=inputs,compute=True)
        if not result.passed:raise AssertionError(result.message)
        records.append(dict(case_id=case['id'],passed=True,message=result.message))
        print('MEMORY_CASE_PASS',case['id'])
        del actual,expected,inputs;gc.collect();torch.npu.synchronize();torch.npu.empty_cache()
    tag='full' if SELECTED_IDS is None else 'typical'
    out=Path(__file__).resolve().parent/'precision_receipts';out.mkdir(exist_ok=True)
    receipt=dict(passed=True,passed_cases=len(records),total_cases=len(selected),candidate_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source=str(source),cases=records,scope=tag,comparison='official npu_compare.compare_case_result, independent existing Torch oracle; streaming case-by-case without PT archives',dtype_contract='BF16 model cases only; no dtype extension')
    (out/(receipt['candidate_sha256']+'_'+tag+'.json')).write_text(json.dumps(receipt,indent=2))
    print('All tests passed!')
