# SPDX-License-Identifier: Apache-2.0
import torch
import torch_reference
class ModelNew(torch.nn.Module):
 def forward(self,residual,gate,branch,weight,shift,scale,indices,eps):
  return torch_reference.indexed_gate_rms_norm_scale_shift(residual,gate,branch,weight,shift,scale,indices,eps)
