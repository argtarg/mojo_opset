"""Re-derive16 cases and inspect actual NPU views before DUT validation."""
from pathlib import Path
import hashlib,json
import torch,torch_npu
from model_inputs import CASES,build_inputs,check_frozen,input_layout
check_frozen();r=Path(__file__).resolve().parent;records=[]
for c in CASES:
 args=build_inputs(c);records.append(dict(case_id=c['id'],inputs=input_layout(args),indices_sha256=c['indices_sha256'],active_conditions=c['active_conditions'],condition_row_counts=c['condition_row_counts'],passed=True))
 print('MODEL_LAYOUT_PASS',c['id'],c['rows'],c['conditions'],c['active_conditions'],flush=True)
 del args;torch.npu.synchronize()
result=dict(passed_cases=len(records),total_cases=len(CASES),model_checkpoint_loaded=False,runtime_trace_collected=False,operator_sha256=hashlib.sha256((r/'opt_indexed_gate.py').read_bytes()).hexdigest(),cases=records)
(r/'layout_validation.json').write_text(json.dumps(result,indent=2))
