from pathlib import Path
import hashlib,json,shutil
R=Path(__file__).resolve().parent;S=Path('/home/t00985010/indexed_gate_model16_mbu_20261121_105300_963d')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
q=json.loads((S/'correctness_receipt.json').read_text())
assert q['passed'] and q['passed_cases']==q['total_cases']==16
assert sha(R/'baseline/indexed_gate.py')==sha(R/'opt_indexed_gate.py')==q['operator_sha256']
for name,expected in json.loads((R/'frozen_inputs.json').read_text()).items():
    assert sha(R/name)==sha(S/name)==expected,name
assert sha(R/'differential_test_opt_indexed_gate.py')==sha(S/'differential_test_opt_indexed_gate.py')
for name in ['correctness_official.log','correctness_exit.txt']:
    p=R/name
    if p.exists():p.rename(R/('interrupted_'+name))
for name in ['correctness_receipt.json','correctness_official.log','correctness_exit.txt']:shutil.copyfile(S/name,R/name)
(R/'baseline/correctness_reuse.json').write_text(json.dumps(dict(source=str(S),source_receipt_sha256=sha(S/'correctness_receipt.json'),same_operator=True,same_frozen_inputs=True,same_correctness_harness=True,passed_cases=16,total_cases=16,reuse_reason='Existing fresh official16/16 same-source run; duplicate new archive-based run terminated without a final result. Candidate checks use official per-case mode to avoid bulk tensor archives.'),indent=2))
print('REUSED_VERIFIED_BASELINE_CORRECTNESS_16_OF16')
