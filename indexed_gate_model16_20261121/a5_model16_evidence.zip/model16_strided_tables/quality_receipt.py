from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
log=(r/'correctness_official.log').read_text();expected={c['id'] for c in json.loads((r/'model_cases.json').read_text())['cases']}
assert (r/'correctness_exit.txt').read_text().strip()=='0'
match=re.search(r'PASS: all (\d+) case\(s\) matched the NPU accuracy contract\.',log);assert match and int(match[1])==len(expected)==16
events=[]
for line in log.splitlines():
 if line.startswith('{'):
  try:events.append(json.loads(line))
  except json.JSONDecodeError:pass
cases=[x['data'] for x in events if x.get('kind')=='case'];assert cases and all(c['ok'] for c in cases)
assert {c['case_id'] for c in cases}==expected
layout=json.loads((r/'layout_validation.json').read_text());assert layout['passed_cases']==layout['total_cases']==16
receipt=dict(passed=True,passed_cases=16,total_cases=16,accuracy_contract='official npu-contract, run-test-baseline, full16 differential vs independent Torch oracle',operator_sha256=sha(r/'opt_indexed_gate.py'),oracle_sha256=sha(r/'oracle_model.py'),torch_reference_sha256=sha(r/'torch_reference.py'),log_sha256=sha(r/'correctness_official.log'),layout_validation_sha256=sha(r/'layout_validation.json'),case_execution_records=cases,model_checkpoint_loaded=False,runtime_trace_collected=False,group='new model16; original13 unchanged')
(r/'correctness_receipt.json').write_text(json.dumps(receipt,indent=2))
print('MODEL16_CORRECTNESS_VERIFIED',receipt['operator_sha256'],flush=True)
