# SPDX-License-Identifier: Apache-2.0
# Derived task file; upstream sources preserved read-only in the project.
"""Operator task: _indexed_gate_rms_norm_scale_shift_kernel (Ascend A5).

`Model` is the numerical oracle. It follows the upstream GPU kernel semantics:

- gated residual `residual + gate[indices] * branch` is rounded to BF16 before RMSNorm;
- the RMSNorm -> indexed affine path stays FP32 and only rounds at the very end.

Reference source: vllm-omni @ d613fdb62c432a342681e88b307d36b54f6ed5f0
(vllm_omni/diffusion/layers/indexed_modulation.py L129-L173).
`get_input_groups()` rebuilds the 3 upstream configurations plus 10 generalized
cases (rows 1..131072, hidden 16..7168, conditions 1..8, random/cycle indices).
"""
import json
import torch

CASES = json.loads(r'''[
 {
  "id": "cuda_affine_boundary",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 2,
  "hidden_size": 5376,
  "conditions": 1,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 0,
  "input_pattern": "fp32_affine_rounding_boundary",
  "indices_pattern": "cycle",
  "source_platform": "cuda",
  "origin": "direct_cuda_call",
  "source_url": "https://github.com/vllm-project/vllm-omni/blob/d613fdb62c432a342681e88b307d36b54f6ed5f0/tests/diffusion/models/minimax_h3/test_minimax_h3_modulation.py#L195",
  "block_n": 8192,
  "expected_constant_output": 1.2265625
 },
 {
  "id": "cuda_residual_boundary",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 11,
  "hidden_size": 3072,
  "conditions": 4,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 17,
  "input_pattern": "bf16_residual_boundary",
  "indices_pattern": "cycle",
  "source_platform": "cuda",
  "origin": "direct_cuda_call",
  "source_url": "https://github.com/vllm-project/vllm-omni/blob/d613fdb62c432a342681e88b307d36b54f6ed5f0/tests/diffusion/models/minimax_h3/test_minimax_h3_modulation.py#L155",
  "block_n": 4096,
  "expected_constant_output": null
 },
 {
  "id": "npu_grid_limit",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 69888,
  "hidden_size": 16,
  "conditions": 7,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 0,
  "input_pattern": "random_normal",
  "indices_pattern": "cycle",
  "source_platform": "npu_A3",
  "origin": "direct_npu_call",
  "source_url": "https://github.com/vllm-project/vllm-omni/blob/d613fdb62c432a342681e88b307d36b54f6ed5f0/tests/diffusion/models/minimax_h3/test_minimax_h3_modulation.py#L68",
  "block_n": 16,
  "expected_constant_output": null
 },
 {
  "id": "gen_single_row",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 1,
  "hidden_size": 5376,
  "conditions": 1,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 1,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 8192,
  "expected_constant_output": null,
  "generalization_axis": "rows_min"
 },
 {
  "id": "gen_odd_rows",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 513,
  "hidden_size": 3072,
  "conditions": 5,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 3,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 4096,
  "expected_constant_output": null,
  "generalization_axis": "rows_tail_conditions_odd"
 },
 {
  "id": "gen_mid_rows",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 2048,
  "hidden_size": 3072,
  "conditions": 4,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 4,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 4096,
  "expected_constant_output": null,
  "generalization_axis": "rows_mid"
 },
 {
  "id": "gen_mid_wide",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 4096,
  "hidden_size": 5376,
  "conditions": 7,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 5,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 8192,
  "expected_constant_output": null,
  "generalization_axis": "rows_mid_wide_hidden"
 },
 {
  "id": "gen_wide_hidden",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 8192,
  "hidden_size": 7168,
  "conditions": 4,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 6,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 8192,
  "expected_constant_output": null,
  "generalization_axis": "hidden_larger"
 },
 {
  "id": "gen_narrow_hidden",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 16384,
  "hidden_size": 2048,
  "conditions": 8,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 7,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 2048,
  "expected_constant_output": null,
  "generalization_axis": "hidden_smaller_rows_larger"
 },
 {
  "id": "gen_odd_hidden",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 8192,
  "hidden_size": 5375,
  "conditions": 4,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 8,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 8192,
  "expected_constant_output": null,
  "generalization_axis": "hidden_tail_mask"
 },
 {
  "id": "gen_grid_exact",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 65535,
  "hidden_size": 3072,
  "conditions": 4,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 9,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 4096,
  "expected_constant_output": null,
  "generalization_axis": "grid_limit_exact"
 },
 {
  "id": "gen_grid_two_chunks",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 131072,
  "hidden_size": 3072,
  "conditions": 8,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 10,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 4096,
  "expected_constant_output": null,
  "generalization_axis": "grid_two_chunks"
 },
 {
  "id": "gen_large_prod",
  "operator": "_indexed_gate_rms_norm_scale_shift_kernel",
  "rows": 69888,
  "hidden_size": 5376,
  "conditions": 7,
  "dtype": "bfloat16",
  "indices_dtype": "int64",
  "eps": 1e-06,
  "seed": 11,
  "input_pattern": "random_normal",
  "indices_pattern": "random",
  "source_platform": "generalized",
  "origin": "generalization",
  "source_url": null,
  "block_n": 8192,
  "expected_constant_output": null,
  "generalization_axis": "production_largest"
 }
]''')

def _build_device():
    """Build inputs on NPU when available.

    CPU BF16 RNG costs ~580 s for the 13 groups (dominated by the two 1e8-element
    cases), which would add a fixed ~10 min to every verify/benchmark process.
    The distribution, dtype, eps and seed per case are unchanged.
    """
    try:
        import torch_npu  # noqa: F401

        if torch.npu.is_available():
            return "npu"
    except Exception:
        pass
    return "cpu"


def _build_indices(case, generator, rows, conditions, device):
    if case.get("indices_pattern") == "random":
        return torch.randint(0, conditions, (rows,), dtype=torch.int64,
                             generator=generator, device=device)
    return torch.arange(rows, dtype=torch.int64, device=device) % conditions


def _build_case(case):
    """Mirror case_inputs.py: same RNG order and same parameter construction."""
    rows, hidden, conditions = case["rows"], case["hidden_size"], case["conditions"]
    device = _build_device()
    generator = torch.Generator(device=device).manual_seed(case["seed"])

    def rand(*shape):
        return torch.randn(*shape, dtype=torch.bfloat16, generator=generator, device=device)

    if case["input_pattern"] == "fp32_affine_rounding_boundary":
        x = torch.ones(rows, hidden, dtype=torch.bfloat16, device=device)
        weight = torch.full((hidden,), 1.125, dtype=torch.bfloat16, device=device)
        shift = torch.zeros(conditions, hidden, dtype=torch.bfloat16, device=device)
        scale = torch.full_like(shift, 0.09375)
        gate = torch.zeros_like(shift)
        branch = x.clone()
        residual = x
    elif case["input_pattern"] == "bf16_residual_boundary":
        residual, gate, branch, weight, shift, scale = (
            rand(rows, hidden), rand(conditions, hidden), rand(rows, hidden),
            rand(hidden), rand(conditions, hidden), rand(conditions, hidden))
        index_cpu = torch.arange(rows, device=device) % conditions
        # The RMS path is exercised on the gated residual in this upstream test.
        _ = (residual.float() + gate[index_cpu].float() * branch.float()).to(torch.bfloat16)
    else:
        _, residual, branch = rand(rows, hidden), rand(rows, hidden), rand(rows, hidden)
        weight, shift, scale, gate = (
            rand(hidden), rand(conditions, hidden), rand(conditions, hidden),
            rand(conditions, hidden))

    indices = _build_indices(case, generator, rows, conditions, device)
    return [residual, gate, branch, weight, shift, scale, indices, case["eps"]]


def get_input_groups():
    return [_build_case(case) for case in CASES]


def get_inputs():
    return get_input_groups()[0]


def get_init_inputs():
    return []


class Model(torch.nn.Module):
    """Fused gated residual + RMSNorm + indexed scale/shift oracle."""

    def forward(self, residual, gate, branch, weight, shift, scale, indices, eps):
        if residual.dtype != torch.bfloat16:
            raise ValueError("This task covers the upstream BF16 contract only")
        selected_gate = gate.index_select(0, indices).float()
        residual_out = (residual.float() + selected_gate * branch.float()).to(torch.bfloat16)
        updated = residual_out.float()
        variance = (updated * updated).mean(dim=-1, keepdim=True)
        normalized = updated * torch.rsqrt(variance + eps) * weight.float()
        selected_shift = shift.index_select(0, indices).float()
        selected_scale = scale.index_select(0, indices).float()
        output = (normalized * (1.0 + selected_scale) + selected_shift).to(residual.dtype)
        return residual_out, output
