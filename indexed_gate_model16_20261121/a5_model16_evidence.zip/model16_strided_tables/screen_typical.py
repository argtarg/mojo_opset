"""Decide full16 expansion from two independent matched typical runs and A/A noise."""
from pathlib import Path
import json,math,statistics
R=Path(__file__).resolve().parent
noise=json.loads((R/'noise/results.json').read_text());runs=[json.loads((R/p/'results.json').read_text()) for p in ('typical','confirm')]
assert noise['complete'] and noise['parent_sha256']==noise['candidate_sha256']
assert all(s['complete'] and len(s['cases'])==4 for s in runs)
assert all(s['candidate_sha256']==runs[0]['candidate_sha256'] and s['parent_sha256']==noise['parent_sha256'] and s['expected_work_kernels']==dict(parent=4,candidate=1) for s in runs)
result=dict(candidate_sha256=runs[0]['candidate_sha256'],parent_sha256=noise['parent_sha256'],cache_modes={},expand_to_full16=True,source='matched whole-call device Duration,2 independent typical runs; A/A controls; not based on historical cross-window timing')
for mode in ('warm','cold'):
    floor=max(.005,max(abs(c['speedups'][mode]['full_parent_over_candidate']-1) for c in noise['cases']))
    gms=[s['geomean_parent_over_candidate'][mode] for s in runs]
    ratios=[c['speedups'][mode]['full_parent_over_candidate'] for s in runs for c in s['cases']]
    # No significant per-case regression, and aggregate gain repeats above A/A floor.
    mode_pass=all(g>1+floor for g in gms) and min(ratios)>=1-max(.03,2*floor)
    result['cache_modes'][mode]=dict(aa_noise_floor_fraction=floor,independent_run_geomeans=gms,min_case_ratio=min(ratios),pass_for_full16=mode_pass,cases=[dict(case_id=c['case_id'],run=i,ratio=c['speedups'][mode]['full_parent_over_candidate'],round_ratios=c['speedups'][mode]['round_ratios']) for i,s in enumerate(runs,1) for c in s['cases']])
    result['expand_to_full16'] &= mode_pass
(R/'typical_screen.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
