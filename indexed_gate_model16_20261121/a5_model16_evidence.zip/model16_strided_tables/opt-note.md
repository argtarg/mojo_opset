# Optimization Notes


## Round1
Parent: baseline (accepted original round9).
Theme: direct table row-stride addressing eliminates3 copies.
Result:16/16 precision; full16 matched warm/cold geomean1.06821196x/1.04635767x; canonical typical4 total-op1.16x.
Best status: current validated model16 branch; original13 unchanged.
Summary: [opt-round-1/summary.md](opt-round-1/summary.md)
Attempts: [opt-round-1/attempts.md](opt-round-1/attempts.md)

## Overall Summary
Final best round: opt-round-1 (model16 scope)
Avg improvement: see canonical total-op comparison; use geometric speedup as primary.
Geomean speedup:1.16x canonical typical4 total-op; full16 matched device warm/cold1.06821196x/1.04635767x.
Validated branches: opt-round-1
Outcome: eliminated3 table copies with preserved BF16 math and repeated typical gains; largest shape close to parity.
Key optimization points:
  1. Direct row strides:4 to1 work kernels/call; full16 warm/cold improvements above (round1).
