#!/bin/bash
source /home/t00985010/indexed_gate_strided_tables_20261121_110935_9e77/environment.sh
python diagnose_standard_steps.py > step_diagnosis.log 2>&1
rc=$?;echo "$rc" > step_diagnosis_exit.txt
exit "$rc"
