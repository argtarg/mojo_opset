#!/bin/bash
source /home/t00985010/indexed_gate_strided_tables_20261121_110935_9e77/environment.sh
python /home/t00985010/indexed_gate_optimizer_20261117_2125_3908/.agents/skills/triton-npu-run-eval/scripts/cli.py run-test-baseline --test-file test_indexed_gate.py --operator-file baseline/indexed_gate.py --test-mode standalone --verbose > baseline_memory_test.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > stream_baseline_exit.txt; exit "$rc"; fi
python -c 'import pathlib,json; p=pathlib.Path("baseline/state.json"); s=json.loads(p.read_text()); s.update(test_file="../test_indexed_gate.py",test_mode="standalone",correctness_status="passed"); p.write_text(json.dumps(s,indent=2))'
python /home/t00985010/indexed_gate_optimizer_20261117_2125_3908/.agents/skills/triton-npu-optimize-state/scripts/cli.py submit-baseline --baseline-dir baseline > baseline_gate.json 2>&1
rc=$?;echo "$rc" > stream_baseline_exit.txt
exit "$rc"
