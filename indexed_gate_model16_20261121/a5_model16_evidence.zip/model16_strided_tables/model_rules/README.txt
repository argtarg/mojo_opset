MiniMax H3 model-rule-derived RMSNorm indexed scale/shift cases

Scope
  This is a NEW set of 16 cases. The existing 19 cases and operator sources
  are unchanged. No performance baseline or optimization target is replaced.
  Request layouts and timestep/index generation follow pinned upstream code.
  Synthetic activation/weight/AdaLN values are explicitly NOT a model trace.

Fixed operator contract
  x: BF16 [local_rows,5376], contiguous; weight: BF16 [5376].
  shift/scale: BF16 views of one [C,6*5376] AdaLN parent; strides [32256,1].
  shift offset=0, scale offset=5376. Move parent to device BEFORE chunking.
  indices: int64 [local_rows], model-derived clustered condition indices.
  eps=1e-5. C=3*number_of_global_unique_timesteps, not the number used by a rank.
  active_conditions and condition_row_counts record local use separately.

Selections and limitations
  Requests use upstream e2e/recipe/documented canvas-frame anchors, plus an
  explicitly selected 15-second admission-boundary case and reference layout.
  Text token counts and encoder text/vision role spans are selected inputs:
  no tokenizer or image/audio encoder has been run. Values are not empirical
  prompt-length percentiles. Each request records these values explicitly.
  Schedule: base 50-step Euler-style positions, video shift=12, audio shift=3;
  step_index is zero based. No edit masks, distilled schedules or locked audio.
  Deployment: TP=1, pure strict Ulysses with SP=1/4/8 and selected rank.
  AllGather/Ring, reference-KV compaction, continuation and control branches
  are excluded from this initial suite. This is not exhaustive model coverage.
  A 15-second request boundary is not a demonstrated memory/capacity limit.

Files
  requests.json: selected request parameters and reasons; no hardcoded R/C.
  model_shape_cases.json: derived R/H/C, layouts, local indices runs/counts,
      per-request used/padded rows, timestamps and provenance.
  model_shapes.csv: compact comparison table.
  model_case_inputs.py: list_cases(), load_case(id,device), metadata builder.
  validation_result.json: CPU metadata/input/serialization validation evidence.
  source_manifest.json and upstream/: pinned originals and SHA256 values.

Use
  python model_case_inputs.py       # derive metadata, no activations allocated
  python validate_suite.py          # validate all16, allocates one case at a time
  python validate_suite.py --metadata-only
  from model_case_inputs import list_cases, load_case
  case = load_case(list_cases()[0]['id'], device='npu')  # or cuda/cpu
  output = ModelNew()(*case['args'])

No full model weights are required to construct these operator fixtures.
CPU-only validation on an Ascend Python environment may need
TORCH_DEVICE_BACKEND_AUTOLOAD=0 to avoid loading torch_npu runtime libraries.
Before benchmarking, use normal device environment activation and validate
the DUT separately. Neither device timings nor DUT correctness are claimed.

Upstream code adapter
  Executes pinned packer function bodies, time planner functions, and the
  original MiniMaxH3DenoiseBranch.fill_timesteps body. Replaces only the
  import of OmniClientError with ValueError and supplies a minimal branch
  context; no upstream numerical/layout body is rewritten. SHA256 checked
  before executing. Activation/AdaLN tensors are locally seeded synthetic.
