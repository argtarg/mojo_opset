# SPDX-License-Identifier: Apache-2.0
"""MiniMax H3 operator fixtures derived from pinned model layout code.

Shapes/indices/layout follow model rules. Activations, weights and AdaLN values
are seeded synthetic tensors, not outputs recorded from a model checkpoint.
No NPU/CUDA context is initialized when generating the metadata manifest.
"""
from __future__ import annotations

import ast
from collections import Counter
from functools import lru_cache
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import torch

ROOT = Path(__file__).resolve().parent


@lru_cache(None)
def _sources():
    manifest = json.loads((ROOT / 'source_manifest.json').read_text(encoding='utf-8'))
    for item in manifest['files']:
        if 'error' in item:
            continue
        p = ROOT / 'upstream' / Path(item['path']).name
        assert hashlib.sha256(p.read_bytes()).hexdigest() == item['sha256'], str(p)
    return manifest


def _tree(name):
    _sources()
    return ast.parse((ROOT / 'upstream' / name).read_text(encoding='utf-8'))


def _execute(nodes, namespace):
    # Preserve upstream function bodies. Only imports/context are adapted.
    future = ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0)
    module = ast.fix_missing_locations(ast.Module(body=[future, *nodes], type_ignores=[]))
    exec(compile(module, '<pinned-upstream-adapter>', 'exec'), namespace)
    return namespace


@lru_cache(None)
def _helpers():
    tree = _tree('packed_sequence.py')
    nodes = [n for n in tree.body if not (
        isinstance(n, ast.ImportFrom) and n.module in ('__future__', 'vllm_omni.errors'))]
    pack = _execute(nodes, {'OmniClientError': ValueError})
    names = {'_align_frame_count', '_video_latent_t', '_audio_latent_t', '_time_shift_sigmas'}
    timing = _execute([n for n in _tree('time_request.py').body
                       if isinstance(n, ast.FunctionDef) and n.name in names], {})
    cls = next(n for n in _tree('denoise_loop.py').body
               if isinstance(n, ast.ClassDef) and n.name == 'MiniMaxH3DenoiseBranch')
    fill = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'fill_timesteps')
    fill_fn = _execute([fill], {'torch': torch})['fill_timesteps']
    arch = next(n for n in _tree('minimax_h3_blocks.py').body
                if isinstance(n, ast.ClassDef) and n.name == 'MiniMaxH3DiTArchConfig')
    fields = {n.target.id: ast.literal_eval(n.value) for n in arch.body
              if isinstance(n, ast.AnnAssign) and n.target.id in ('hidden_size', 'norm_eps')}
    assert fields == {'hidden_size': 5376, 'norm_eps': 1e-5}
    return pack, timing, fill_fn, fields


def _request_layout(request):
    pack, timing, fill_fn, _ = _helpers()
    height, width = request['height'], request['width']
    assert height % 32 == width % 32 == 0 and max(height, width) <= 4 * min(height, width)
    frames = timing['_align_frame_count'](request['requested_frames'])
    assert 96 <= request['requested_frames'] <= timing['_align_frame_count'](15 * 24)
    latent_t = timing['_video_latent_t'](frames)
    # The encoder resolver uses aligned frames / fps, not the pre-alignment duration.
    audio_t = timing['_audio_latent_t'](frames / 24)
    spec = dict(text_len=request['text_len'], latent_t=latent_t,
                latent_h=height // 16, latent_w=width // 16, audio_t=audio_t)
    if request['task'] == 'ref2va':
        layout = pack['minimax_h3_packed_sequence_ref2va_blocks'](
            **spec, ref_blocks=request['ref_blocks'])
    else:
        keyframes = request.get('keyframe_frame_indices', [])
        layout = pack['minimax_h3_packed_sequence'](
            **spec, include_keyframe_cond=bool(keyframes),
            keyframe_frame_indices=keyframes or None, frame_count=frames)
    # Encoder text role labels can be 0 (vision) or 1 (text). Exact tokenizer
    # output is unavailable; selected vision spans are declared fixture inputs.
    tags = layout['token_tags'].clone()
    vision = request.get('text_vision_tokens', 0)
    assert 0 <= vision < request['text_len']
    if vision:
        start = request['text_len'] - vision
        tags[layout['text_pos'][start:]] = 0
    steps, step = request.get('num_steps', 50), request['step_index']
    assert 0 <= step < steps
    sv = timing['_time_shift_sigmas'](num_steps=steps, shift_scale=12.0)[step]
    sa = timing['_time_shift_sigmas'](num_steps=steps, shift_scale=3.0)[step]
    tv, ta = 1.0 - sv, 1.0 - sa
    seq = int(layout['seq_len'])
    branch = SimpleNamespace(seq_len=seq, device=torch.device('cpu'),
        img_pos_dev=layout['img_pos'], audio_pos_dev=layout['audio_pos'],
        update_mask_dev=layout['update_mask'],
        audio_update_mask_dev=layout.get('audio_update_mask', torch.ones_like(layout['audio_pos'], dtype=torch.bool)),
        locked_audio_rows=None)
    times = torch.empty(seq, dtype=torch.float32)
    fill_fn(branch, times, t_video=tv, t_audio=ta,
            imgvid_cond_timestep=max(tv, .999), audio_ref_cond_timestep=max(ta, 1.0))
    metadata = {**request, 'aligned_frames': frames, 'latent_t': latent_t,
                'audio_latent_t': audio_t, 'global_rows': seq,
                'used_rows': int(layout['cu_seqlens'][1]), 'padding_rows': seq-int(layout['cu_seqlens'][1]),
                't_video': tv, 't_audio': ta,
                'video_rows': latent_t * (height // 32) * (width // 32),
                'all_visual_rows': int(layout['img_pos'].numel()),
                'all_audio_rows': int(layout['audio_pos'].numel())}
    return metadata, times, tags


def requests():
    return json.loads((ROOT / 'requests.json').read_text(encoding='utf-8'))['cases']


def build_case_metadata(case):
    """Execute upstream packer/timestep bodies; return metadata and local indices."""
    _, _, _, arch = _helpers()
    built = [_request_layout(r) for r in case['requests']]
    times = torch.cat([b[1] for b in built])
    tags = torch.cat([b[2] for b in built])
    unique, inverse = torch.unique(times, sorted=True, return_inverse=True)
    combined = inverse * 3 + tags.clamp(min=0)
    sp, rank = case['sp_size'], case['sp_rank']
    assert sp in (1, 2, 4, 8) and 0 <= rank < sp
    # TP=1, pure strict Ulysses; 56 heads must be divisible by SP.
    assert 56 % sp == 0 and combined.numel() % sp == 0
    r = combined.numel() // sp
    indices = combined.narrow(0, rank*r, r).clone()
    h, c = arch['hidden_size'], unique.numel()*3
    counts = torch.bincount(indices, minlength=c).tolist()
    runs = int((indices[1:] != indices[:-1]).sum())+1
    segments = []
    boundaries = [0, *(torch.nonzero(indices[1:] != indices[:-1]).flatten()+1).tolist(), r]
    for a,b in zip(boundaries[:-1], boundaries[1:]):
        segments.append({'start':a, 'rows':b-a, 'condition':int(indices[a])})
    metadata = {'id':case['id'], 'case_idx':case['case_idx'], 'provenance':case['provenance'],
        'rows':r, 'hidden_size':h, 'conditions':c, 'eps':arch['norm_eps'],
        'dtype':'bfloat16','indices_dtype':'int64', 'sp_size':sp,'sp_rank':rank,'tp_size':1,
        'global_rows':int(combined.numel()), 'rank_row_start':rank*r,
        'unique_timesteps':unique.tolist(),'active_conditions':sum(n>0 for n in counts),
        'condition_row_counts':counts,'indices_runs':runs,'indices_segments':segments,
        'indices_sha256':hashlib.sha256(indices.numpy().tobytes()).hexdigest(),
        'x_stride':[h,1],'weight_stride':[1],'shift_stride':[6*h,1],
        'scale_stride':[6*h,1],'shift_storage_offset':0,'scale_storage_offset':h,
        'adaln_parent_shape':[c,6*h], 'indices_stride':[1],
        'x_bytes':2*r*h,'output_bytes':2*r*h,'adaln_parent_bytes':2*c*6*h,
        'seed':case['seed'],'requests':[b[0] for b in built],
        'evidence':'pinned_source_rule_derived_not_model_runtime_trace',
        'values':'seeded_synthetic_not_checkpoint_activations',
        'request_assumptions':['Text token count/vision-role spans selected explicitly, not measured tokenizer outputs.',
                               'Pure strict Ulysses with TP=1; no Ring/AllGather or reference-KV compaction.',
                               'Base 50-step schedule, video shift=12 and audio shift=3; no edit masks or distilled schedule.']}
    assert 0 <= int(indices.min()) <= int(indices.max()) < c
    return metadata, indices


def list_cases():
    return json.loads((ROOT/'model_shape_cases.json').read_text(encoding='utf-8'))['cases']


def load_case(case_id, device='cpu'):
    spec = next(c for c in requests() if c['id']==case_id)
    meta, indices = build_case_metadata(spec)
    gen = torch.Generator(device='cpu').manual_seed(spec['seed'])
    r,h,c = meta['rows'],meta['hidden_size'],meta['conditions']
    x = torch.randn(r,h,dtype=torch.bfloat16,generator=gen).to(device)
    weight = torch.randn(h,dtype=torch.bfloat16,generator=gen).to(device)
    # Transfer the full parent BEFORE slicing, so .to(device) cannot compact views.
    parent = torch.randn(c,6*h,dtype=torch.bfloat16,generator=gen).to(device)
    shift,scale,*_ = parent.chunk(6,dim=-1)
    inputs = dict(x=x,weight=weight,shift=shift,scale=scale,
                  indices=indices.to(device),eps=meta['eps'])
    assert list(shift.stride())==list(scale.stride())==[6*h,1]
    assert shift.untyped_storage().data_ptr()==scale.untyped_storage().data_ptr()
    args = [inputs[k] for k in ['x','weight','shift','scale','indices','eps']]
    return {'case':meta,'inputs':inputs,'args':args,'calls':[args],
            'retained_storage':parent}


def export_metadata():
    results = [build_case_metadata(c)[0] for c in requests()]
    output = {'operator':'_rms_norm_indexed_scale_shift_kernel',
        'repository':_sources()['repository'],'revision':_sources()['revision'],
        'classification':'model_rule_derived_synthetic_fixture_suite',
        'runtime_trace_collected':False,'old19_replaced':False,'cases':results}
    (ROOT/'model_shape_cases.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return output


if __name__=='__main__':
    result = export_metadata()
    print(json.dumps([{k:c[k] for k in ['case_idx','id','rows','hidden_size','conditions','active_conditions']}
                      for c in result['cases']],indent=2))
