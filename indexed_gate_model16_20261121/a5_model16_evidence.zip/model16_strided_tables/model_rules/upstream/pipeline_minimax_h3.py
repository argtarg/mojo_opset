# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""vLLM-Omni pipeline for MiniMax H3 FL2VA and Ref2VA partitions."""

from __future__ import annotations

import json
import math
import os
from collections.abc import Iterable, Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager, nullcontext
from dataclasses import fields, replace
from itertools import groupby
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, NamedTuple

import numpy as np
import torch
import torch.distributed as dist
import torch.nn as nn
from PIL import Image
from transformers import Qwen2TokenizerFast, Qwen3VLProcessor
from vllm.logger import init_logger
from vllm.model_executor.layers.quantization.base_config import QuantizationConfig

from vllm_omni.diffusion import envs
from vllm_omni.diffusion.attention.schedule import (
    InvalidAttentionScheduleError,
    require_request_attention_schedule_fits,
)
from vllm_omni.diffusion.cache.cachedit import (
    CacheDiTBackend,
    RequestScopedCacheDiTRuntime,
)
from vllm_omni.diffusion.cache.teacache.hook import TeaCacheHook
from vllm_omni.diffusion.cancellation import check_request_cancellation
from vllm_omni.diffusion.data import DiffusionOutput, OmniDiffusionConfig
from vllm_omni.diffusion.distributed.parallel_state import get_world_group, init_world_group
from vllm_omni.diffusion.distributed.utils import get_local_device
from vllm_omni.diffusion.forward_context import (
    DenoiseProgressMixin,
    get_forward_context,
    is_forward_context_available,
    request_denoise_progress,
)
from vllm_omni.diffusion.model_loader.diffusers_loader import (
    DiffusersPipelineLoader,
)
from vllm_omni.diffusion.models.interface import (
    SupportAudioInput,
    SupportAudioOutput,
    SupportImageInput,
    SupportsComponentDiscovery,
)
from vllm_omni.diffusion.models.progress_bar import ProgressBarMixin
from vllm_omni.diffusion.offloader import (
    BoundedAllocatorCache,
    OffloadPlan,
    apply_sequential_offload,
    remove_sequential_offload,
    sequential_offload_component,
)
from vllm_omni.diffusion.offloader.config import (
    DIT_COMPONENT,
    TEXT_ENCODER_COMPONENT,
    OffloadStrategy,
    offload_streams_blocks,
    resolve_offload,
    resolve_offload_strategy,
    should_offload_component,
)
from vllm_omni.diffusion.offloader.module_collector import ModuleDiscovery
from vllm_omni.diffusion.profiler.diffusion_pipeline_profiler import (
    DiffusionPipelineProfilerMixin,
)
from vllm_omni.diffusion.sched.sigma_schedule import DMD2SigmaSchedule
from vllm_omni.diffusion.utils.media_utils import normalize_preencode_batch_frames, normalize_video_codec_options
from vllm_omni.diffusion.worker.request_batch import DiffusionRequestBatch
from vllm_omni.errors import OmniClientError, client_error_from_metadata
from vllm_omni.inputs.data import OmniDiffusionSamplingParams
from vllm_omni.model_executor.model_loader.weight_utils import (
    download_weights_from_hf_specific,
)
from vllm_omni.model_executor.models.minimax_h3.checkpoint import (
    is_minimax_h3_modular,
    resolve_minimax_h3_partition,
)
from vllm_omni.model_executor.models.minimax_h3.conditioning import (
    MiniMaxH3EncoderConditioning,
    MiniMaxH3EncoderMediaConditioning,
    MiniMaxH3EncoderMediaInput,
    MiniMaxH3TextConditioning,
)
from vllm_omni.model_executor.models.minimax_h3.continuation_request import (
    resolve_continuation_request,
    window_frame_index,
)
from vllm_omni.model_executor.models.minimax_h3.encoder_processing import (
    PreparedEncoderInputs,
    continuation_inherits_source_canvas,
    encode_media,
    prepare_encoder_inputs,
)
from vllm_omni.model_executor.models.minimax_h3.long_video import validate_encoded_frame_limit
from vllm_omni.model_executor.models.minimax_h3.preprocessing import (
    build_minimax_h3_presentation,
    load_minimax_h3_images,
)
from vllm_omni.model_executor.models.minimax_h3.reference_video import (
    MINIMAX_H3_PREPARED_REFERENCE_VIDEOS_KEY,
    deserialize_prepared_reference_videos,
)
from vllm_omni.model_executor.models.minimax_h3.timeline_guides import (
    MINIMAX_H3_TIMELINE_GUIDES_KEY,
    resolve_guide_start,
)
from vllm_omni.outputs.output_metadata import valid_frame_counts
from vllm_omni.platforms import current_omni_platform
from vllm_omni.quantization import (
    resolve_component_quant_config as _resolve_component_quant_config,
)
from vllm_omni.quantization.component_config import (
    resolve_encoder_quant_config as _resolve_encoder_quant_config,
)

from .batched_packing import minimax_h3_batched_forward_kwargs
from .condition_noise import (
    minimax_h3_audio_cond_noise_aug_rows,
    minimax_h3_imgvid_cond_noise_aug_rows,
    minimax_h3_imgvid_cond_noise_rows,
)
from .continuation import (
    ContinuationWindow,
    LatentPrefix,
    _audio_t,
    diffuse_continuation,
    plan_continuation_windows,
    resolve_continuation,
    window_args,
)
from .controlnet import MINIMAX_H3_CONTROL_MEDIA_KEY, build_control_rows, load_control_pixels, parse_control
from .denoise_loop import (
    MiniMaxH3DenoiseBranch,
    minimax_h3_denoise_loop,
    minimax_h3_prepare_denoise_rows,
    minimax_h3_publish_denoise_progress,
)
from .encoder import MiniMaxH3Qwen3VLEncoder
from .fasth3 import FastH3WeightFusion, resolve_fasth3_fusion
from .fasth3_checkpoint import FastH3CheckpointSpec, FastH3OmniCheckpointSpec
from .latent_cache import (
    LATENT_CACHE_KEY,
    CachedClip,
    LatentClipCache,
    LatentContinuation,
    latent_cache_clips,
    plan_latent_continuation,
    trim_decoded_overlap,
)
from .latent_mask import (
    MiniMaxH3LatentEdit,
    minimax_h3_audio_edit_masks,
    minimax_h3_prepare_edit_rows,
    minimax_h3_video_edit_masks,
)
from .latent_upscaler import (
    MiniMaxH3LatentRefineSpec,
    MiniMaxH3LatentUpscalerError,
    MiniMaxH3LatentUpscaleTarget,
    parse_minimax_h3_latent_refine_request,
    parse_minimax_h3_latent_upscale_request,
    resolve_minimax_h3_latent_upscale_target,
    resolve_minimax_h3_latent_upscaler,
)
from .lightvae import resolve_h3_lightvae_decoder_path
from .lora import TurboSpec, load_minimax_h3_turbo_lora
from .minimax_h3_blocks import (
    MiniMaxH3Attention,
    _attention_isolates_packed_requests,
)
from .minimax_h3_transformer import MiniMaxH3DiTModel
from .npu.lora import (
    MINIMAX_H3_NATIVE_INFERENCE_STEPS,
    load_minimax_h3_native_lora,
)
from .packed_sequence import (
    MINIMAX_H3_MAX_PAD_SEQ_LEN,
    MINIMAX_H3_SEQ_ALIGN,
    minimax_h3_packed_sequence,
    minimax_h3_packed_sequence_ref2va_blocks,
)
from .packed_tokens import (
    minimax_h3_pack_audio_latent,
    minimax_h3_patchify_video_latent,
    minimax_h3_unpack_audio_tokens,
    minimax_h3_unpatchify_video_tokens,
)
from .quality_policy import MINIMAX_H3_GENERIC_CACHE_KEY, MiniMaxH3QualityPolicy
from .regenerate import (
    REGENERATE_DEFAULT_UPSCALE,
    REGENERATE_SUPPORTED_TASKS,
    REGENERATE_VIDEO_SHIFT,
    MiniMaxH3RegenerateAdapter,
    regenerate_schedule,
    resolve_regenerate_adapter,
)
from .sampling import create_h3_sample_solver, normalize_h3_sampler
from .scheduling_minimax_h3_euler_ancestral import (
    minimax_h3_rf_v_to_x0,
)
from .time_request import (
    MINIMAX_H3_SHAPE_PLANNER,
    minimax_h3_time_shift_sigmas,
)
from .vae import MiniMaxH3AudioVAE, MiniMaxH3VideoVAE, _load_component_config, _VideoVAEPartProxy
from .vdnh3 import VDNCheckpoint

if TYPE_CHECKING:
    from vllm_omni.diffusion.worker.input_batch import InputBatch
    from vllm_omni.diffusion.worker.utils import StepRequestState

logger = init_logger(__name__)

if TYPE_CHECKING:
    from vllm.lora.lora_model import LoRAModel
    from vllm.lora.peft_helper import PEFTHelper

    from vllm_omni.lora.request import LoRARequest

MINIMAX_H3_FPS = 24
MINIMAX_H3_AUDIO_SAMPLE_RATE = 32000
MINIMAX_H3_IMGVID_COND_TIMESTEP = 0.999
MINIMAX_H3_AUDIO_REF_COND_TIMESTEP = 1.0
MINIMAX_H3_DOWNLOAD_PATTERNS = [
    "FL2VA/**",
    "Ref2VA/model_index.json",
    "Ref2VA/transformer/**",
]
MINIMAX_H3_TASK_DOWNLOAD_PATTERNS = {
    "fl2va": ["FL2VA/**"],
    "ref2va": ["Ref2VA/**"],
}
MINIMAX_H3_DIFFUSION_DOWNLOAD_PATTERNS = {
    "fl2va": [
        "FL2VA/model_index.json",
        "FL2VA/transformer/**",
        "FL2VA/video_vae/**",
        "FL2VA/audio_vae/**",
    ],
    "ref2va": [
        "Ref2VA/model_index.json",
        "Ref2VA/transformer/**",
        "Ref2VA/video_vae/**",
        "Ref2VA/audio_vae/**",
    ],
    "combined": [
        "FL2VA/model_index.json",
        "FL2VA/transformer/**",
        "FL2VA/video_vae/**",
        "FL2VA/audio_vae/**",
        "Ref2VA/model_index.json",
        "Ref2VA/transformer/**",
    ],
}


def _resolve_minimax_h3_text_encoder_quant_config(
    quant_config: QuantizationConfig | None,
) -> QuantizationConfig | None:
    resolved = _resolve_component_quant_config(quant_config, "text_encoder")
    return _resolve_encoder_quant_config(resolved)


def _minimax_h3_partition_for_task(
    task_type: str | None,
    model: str | None = None,
) -> str:
    return resolve_minimax_h3_partition(model or "", task_type, auto_partition="combined")


def _resolve_minimax_h3_model_root(
    model: str,
    revision: str | None,
    partition: str,
    *,
    load_text_encoder: bool,
) -> Path:
    path = Path(model)
    if path.is_dir():
        if path.name in {"FL2VA", "Ref2VA"}:
            return path.parent
        return path
    if is_minimax_h3_modular(model, revision):
        from vllm_omni.model_executor.models.minimax_h3.checkpoint import minimax_h3_transformer_subfolder

        component = minimax_h3_transformer_subfolder(model=model, revision=revision)
        allow_patterns = ["modular_model_index.json", "fastvideo_inference.json", "provenance.json", f"{component}/**"]
        if component == "transformer_ref":
            allow_patterns += ["vae_decoder_nvfp4/**", "vae_decoder_nvfp4_fast/**"]
        if load_text_encoder:
            allow_patterns += ["text_encoder/**", "tokenizer/**", "processor/**"]
    elif load_text_encoder:
        allow_patterns = (
            MINIMAX_H3_DOWNLOAD_PATTERNS if partition == "combined" else MINIMAX_H3_TASK_DOWNLOAD_PATTERNS[partition]
        )
    else:
        allow_patterns = MINIMAX_H3_DIFFUSION_DOWNLOAD_PATTERNS[partition]
    return Path(
        download_weights_from_hf_specific(
            model_name_or_path=model,
            cache_dir=None,
            allow_patterns=allow_patterns,
            revision=revision,
            require_all=True,
        )
    )


_MINIMAX_H3_DENOISE_INPUT_KEYS = (
    "task",
    "text_embeddings",
    "text_tags",
    "seed",
    "latent_t",
    "latent_h",
    "latent_w",
    "audio_t",
    "num_frames",
    "num_steps",
    "video_shift",
    "audio_shift",
    "base_schedule",
    "visual_condition",
    "visual_condition_shape",
    "audio_condition",
    "ref_audio_t",
    "ref_blocks",
    "visual_condition_shapes",
    "audio_condition_lengths",
    "keyframe_frame_indices",
    "control_rows",
    "control_context_scale",
    "guide_blocks",
    "pad_seq_len",
    "locked_audio_rows",
    "video_edit_clean_rows",
    "video_edit_mask_rows",
    "video_edit_restore_mask_rows",
    "audio_edit_clean_rows",
    "audio_edit_mask_rows",
    "audio_edit_restore_mask_rows",
)

# Request-context key for the FL2VA keyframes re-encoded at the refine size.
_REFINE_KEYFRAME_CONDITION = "minimax_h3_refine_keyframe_condition"

# ``StepRequestState.extra`` keys owned by the step-execution path.
_STEP_BRANCH = "minimax_h3_branch"
_STEP_AUDIO_ROWS = "minimax_h3_audio_rows"
_STEP_AUDIO_NOISE_PRED = "minimax_h3_audio_noise_pred"
_STEP_VIDEO_SOLVER = "minimax_h3_video_solver"
_STEP_AUDIO_SOLVER = "minimax_h3_audio_solver"
_STEP_SIGMAS_VIDEO = "minimax_h3_sigmas_video"
_STEP_SIGMAS_AUDIO = "minimax_h3_sigmas_audio"
_STEP_COND_ANCHOR = "minimax_h3_cond_anchor"
_STEP_AUDIO_ANCHOR = "minimax_h3_audio_anchor"
_STEP_SHAPE = "minimax_h3_shape"
_STEP_TRANSFORMER = "minimax_h3_transformer"
_STEP_VIDEO_EDIT = "minimax_h3_video_edit"
_STEP_AUDIO_EDIT = "minimax_h3_audio_edit"


def _minimax_h3_step_schedule(state: StepRequestState) -> dict[str, float]:
    """Return the sigma/timestep values this request needs for its current step.

    Mirrors the per-iteration arithmetic of ``minimax_h3_denoise_loop`` so step
    mode and request mode advance identically.
    """
    step = int(state.step_index)
    sigmas_video = state.extra[_STEP_SIGMAS_VIDEO]
    sigmas_audio = state.extra[_STEP_SIGMAS_AUDIO]
    sigma_video = float(sigmas_video[step])
    sigma_audio = float(sigmas_audio[step])
    t_video = 1.0 - sigma_video
    t_audio = 1.0 - sigma_audio
    return {
        "sigma_video": sigma_video,
        "sigma_video_next": float(sigmas_video[step + 1]),
        "sigma_audio": sigma_audio,
        "sigma_audio_next": float(sigmas_audio[step + 1]),
        "t_video": t_video,
        "t_audio": t_audio,
        "imgvid_cond_timestep": max(t_video, MINIMAX_H3_IMGVID_COND_TIMESTEP),
        "audio_ref_cond_timestep": max(t_audio, MINIMAX_H3_AUDIO_REF_COND_TIMESTEP),
    }


def _read_base_schedule(release: Mapping[str, Any]) -> DMD2SigmaSchedule | None:
    """Read a partition's distilled schedule. An absent key means legacy uniform."""
    return DMD2SigmaSchedule.from_metadata(release)


def resolve_minimax_h3_diffusion_model_path(
    model: str,
    revision: str | None,
    task_type: str | None,
) -> str:
    """Resolve a repository root or Hub ID to its startup partition."""
    partition = (
        "combined"
        if str(task_type or "").lower() == "combined"
        else resolve_minimax_h3_partition(model, task_type, auto_partition="fl2va")
    )
    model_root = _resolve_minimax_h3_model_root(
        model,
        revision,
        partition,
        load_text_encoder=False,
    )
    if is_minimax_h3_modular(str(model_root), revision):
        return str(model_root)
    if partition == "combined":
        return str(model_root)
    subdir = "Ref2VA" if partition == "ref2va" else "FL2VA"
    return str(model_root / subdir)


def _minimax_h3_output_canvas(
    shape: Mapping[str, Any],
    target: MiniMaxH3LatentUpscaleTarget | None,
) -> tuple[int, int]:
    """The decoded frame size, which the upscaler moves when it runs."""
    if target is None:
        return int(shape["height"]), int(shape["width"])
    return target.height, target.width


class _MiniMaxH3EncodedOutput(NamedTuple):
    video: bytes | list[bytes]
    frame_counts: list[int]


def _minimax_h3_post_process(output, output_type: str = "np"):
    """Convert the joint video/audio output without capturing worker state.

    The callable crosses the multiprocessing result queue, so it must remain a
    module-level function that the standard pickle module can resolve.

    ``_prepare_minimax_h3_video_output`` already quantises the video to uint8
    frames on the accelerator, so there is nothing left to scale or transpose
    here.
    """
    frame_counts = None
    if isinstance(output, _MiniMaxH3EncodedOutput):
        frame_counts = output.frame_counts
        output = (output.video, None)
    if not isinstance(output, tuple) or len(output) != 2:
        return output
    video, audio = output
    if isinstance(video, (bytes, bytearray, memoryview)):
        video = [video]
    if isinstance(video, list) and all(isinstance(item, (bytes, bytearray, memoryview)) for item in video):
        encoded_videos = [bytes(item) for item in video]
    else:
        encoded_videos = None
    if encoded_videos is not None:
        result = {
            "video": encoded_videos,
            "audio": [None] * len(encoded_videos),
            "audio_sample_rate": MINIMAX_H3_AUDIO_SAMPLE_RATE,
            "fps": MINIMAX_H3_FPS,
        }
        if frame_counts is not None:
            if not valid_frame_counts(frame_counts, len(encoded_videos)):
                logger.warning("Ignoring invalid encoded frame counts; falling back to MP4 metadata inspection")
                return result
            return {
                "payload": {
                    "video": encoded_videos,
                    "audio": [None] * len(encoded_videos),
                },
                "metadata": {
                    "video": {"fps": MINIMAX_H3_FPS, "frame_counts": frame_counts},
                    "audio": {"sample_rate": MINIMAX_H3_AUDIO_SAMPLE_RATE},
                },
            }
        return result
    if video.dtype != torch.uint8 or video.ndim != 5 or video.shape[-1] not in (3, 4):
        # Float or channel-first frames would reach the muxer as a black or
        # banded video rather than as an error.
        raise ValueError(
            f"MiniMax-H3 post-processing expects (B, T, H, W, C) uint8, got {tuple(video.shape)} {video.dtype}"
        )
    if output_type == "latent":
        return output
    if output_type == "np":
        video = video.detach().cpu().numpy()
        audio = audio.detach().float().cpu().numpy()
        video = [sample for sample in video]
    return {
        "video": video,
        "audio": audio,
        "audio_sample_rate": MINIMAX_H3_AUDIO_SAMPLE_RATE,
        "fps": MINIMAX_H3_FPS,
    }


def _prepare_minimax_h3_video_output(video: torch.Tensor) -> torch.Tensor:
    """Quantize decoded frames in place before worker-to-engine transfer."""
    video = video.detach()
    if video.dtype == torch.uint8:
        # Streaming decode already quantized and clamped; only the transfer
        # layout remains.
        return video.permute(0, 2, 3, 4, 1).contiguous()
    video = video.float()
    video.clamp_(0, 1).mul_(255).round_()
    permuted = video.permute(0, 2, 3, 4, 1)
    out = torch.empty(permuted.shape, dtype=torch.uint8, device=video.device)
    # copy_ fuses the layout change and the cast into one kernel;
    # ``.to(dtype=uint8, memory_format=contiguous_format)`` materializes a
    # contiguous FP32 intermediate first (~4.2GB for a 15s clip).
    out.copy_(permuted)
    return out


def _register_dlo_component_cache(cache: BoundedAllocatorCache, *components: Any) -> None:
    for component in components:
        if component is not None:
            component.set_omni_component_cache(cache)


def _device_prefix(continuation: LatentContinuation, device: torch.device) -> LatentPrefix:
    prefix = continuation.prefix
    return replace(prefix, video=prefix.video.to(device=device), audio=prefix.audio.to(device=device))


def _continuation_trim(continuation: LatentContinuation | None) -> dict[str, Any] | None:
    """How much of the decoded window is a continuation's hidden overlap."""
    if continuation is None:
        return None
    return {
        "frames": continuation.prefix.overlap_frames,
        "audio_fraction": continuation.overlap_audio_t / continuation.audio_t,
    }


def _fit_audio_t(value: torch.Tensor, audio_t: int, *, fill: float) -> torch.Tensor:
    """Pad or crop the last (40-Hz latent) axis to ``audio_t``."""
    if value.shape[-1] >= audio_t:
        return value[..., :audio_t].contiguous()
    return torch.cat((value, value.new_full((*value.shape[:-1], audio_t - value.shape[-1]), fill)), dim=-1)


def get_minimax_h3_post_process_func(od_config: OmniDiffusionConfig):
    del od_config
    return _minimax_h3_post_process


def _expose_padded_audio_tail(
    source_audio_t: int,
    *,
    target_audio_t: int,
    mask_rows: torch.Tensor,
    restore_mask_rows: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Mark the encoder-padded audio tail for generation."""
    if not 0 < source_audio_t <= target_audio_t:
        raise ValueError(f"source_audio_t must be in [1, {target_audio_t}]")
    expected_shape = (2 * target_audio_t,)
    if tuple(mask_rows.shape) != expected_shape or tuple(restore_mask_rows.shape) != expected_shape:
        raise ValueError(f"audio edit masks must have shape {expected_shape}")
    model_mask = mask_rows.reshape(2, target_audio_t).clone()
    restore_mask = restore_mask_rows.reshape(2, target_audio_t).clone()
    if source_audio_t < target_audio_t:
        model_mask[:, source_audio_t:] = 1.0
        restore_mask[:, source_audio_t:] = 1.0
    return model_mask.reshape(-1), restore_mask.reshape(-1)


def _resolve_minimax_h3_num_outputs(value: Any) -> int:
    if value is None:
        return 1
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise OmniClientError("MiniMax H3 num_outputs_per_prompt must be an integer in [1, 10]")
    value = int(value)
    if not 1 <= value <= 10:
        raise OmniClientError(f"MiniMax H3 num_outputs_per_prompt must be in [1, 10], got {value}")
    return value


def _resolve_pad_seq_len(value: object) -> int | None:
    """Validate the optional packed-length pin from ``extra_args``.

    The packer itself only needs a value that covers the used rows. A request
    field needs two more guards: an unaligned value would silently open yet
    another compiled shape, and an unbounded one would size every structural
    tensor the packer allocates.
    """
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
        raise OmniClientError("MiniMax H3 pad_seq_len must be an integer")
    pinned = int(value)
    if pinned <= 0:
        raise OmniClientError(f"MiniMax H3 pad_seq_len must be positive, got {pinned}")
    if pinned % MINIMAX_H3_SEQ_ALIGN:
        raise OmniClientError(f"MiniMax H3 pad_seq_len must be a multiple of {MINIMAX_H3_SEQ_ALIGN}, got {pinned}")
    if pinned > MINIMAX_H3_MAX_PAD_SEQ_LEN:
        raise OmniClientError(f"MiniMax H3 pad_seq_len must be at most {MINIMAX_H3_MAX_PAD_SEQ_LEN}, got {pinned}")
    return pinned


def _minimax_h3_output_seeds(seed: int, num_outputs: int) -> list[int]:
    return [int(seed) + output_index for output_index in range(int(num_outputs))]


def _dit_rank_world() -> tuple[Any, int, int]:
    if not dist.is_initialized():
        return None, 0, 1
    group = get_world_group().device_group
    return group, dist.get_rank(group), dist.get_world_size(group)


def _broadcast_rank0_exception(exc: Exception | None) -> None:
    """Synchronize a rank-0-only exception across every DiT rank.

    H3 reference-video preparation runs only on rank 0; the other DiT ranks
    return ``None`` without touching disk. When rank 0 raises inside that
    path it exits :meth:`prepare_encode` before reaching the downstream
    ``dist.broadcast`` calls, and non-zero ranks then hang on those
    collectives forever. Every rank calls this helper right after the
    rank-0-only work, before any subsequent collective, so all ranks either
    raise the same error together or all continue.
    """
    group, rank, world_size = _dit_rank_world()
    if world_size == 1:
        if exc is not None:
            raise exc
        return
    if rank == 0:
        if exc is None:
            payload: list[Any] = [None]
        else:
            payload = [
                {
                    "type": type(exc).__name__,
                    "message": str(exc),
                    "status_code": getattr(exc, "status_code", None),
                    "error_type": getattr(exc, "error_type", None),
                }
            ]
    else:
        payload = [None]
    dist.broadcast_object_list(payload, src=0, group=group)
    info = payload[0]
    if info is None:
        return
    if rank == 0:
        assert exc is not None
        raise exc
    # Rebuild a matching client-facing error on non-zero ranks so the runner's
    # per-request try/except records the same 4xx status as rank 0. The exact
    # subclass need not survive the wire; the message and status suffice.
    status_code = info.get("status_code")
    error_type = info.get("error_type")
    message = f"[rank 0] {info['type']}: {info['message']}"
    if status_code is not None:
        raise client_error_from_metadata(
            message,
            status_code=int(status_code),
            error_type=error_type,
        )
    raise RuntimeError(message)


def _broadcast_tensor(
    tensor: torch.Tensor | None,
    *,
    dtype: torch.dtype,
    device: torch.device,
) -> torch.Tensor:
    group, rank, world_size = _dit_rank_world()
    if world_size == 1:
        if tensor is None:
            raise ValueError("source tensor is required for single-rank execution")
        return tensor.to(device=device, dtype=dtype)

    shape = torch.zeros(5, dtype=torch.long, device=device)
    if rank == 0:
        if tensor is None:
            raise ValueError("rank 0 must provide a tensor to broadcast")
        shape[0] = tensor.ndim
        shape[1 : tensor.ndim + 1] = torch.tensor(
            tensor.shape,
            device=device,
        )
    dist.broadcast(shape, src=0, group=group)
    ndim = int(shape[0].item())
    tensor_shape = tuple(int(v) for v in shape[1 : ndim + 1].tolist())
    if rank == 0:
        output = tensor.to(device=device, dtype=dtype).contiguous()
    else:
        output = torch.empty(tensor_shape, device=device, dtype=dtype)
    dist.broadcast(output, src=0, group=group)
    return output


class _SingleRankEncoderGroup:
    """Lightweight encoder group for ``text_encoder_tp_size == 1``.

    Avoids creating a distributed ``GroupCoordinator`` with a single-member
    rank set, which would assert on every other DiT rank that is not part of
    the group.  The pipeline and encoder only use the attributes below, and
    all ``world_size == 1`` code paths short-circuit before any collective.
    """

    world_size: int = 1
    ranks: list[int] = [0]

    def __init__(self, rank: int) -> None:
        self.rank_in_group = 0 if rank == 0 else -1
        self.device_group = None


class MiniMaxH3Pipeline(
    nn.Module,
    DenoiseProgressMixin,
    ProgressBarMixin,
    DiffusionPipelineProfilerMixin,
    SupportImageInput,
    SupportAudioInput,
    SupportAudioOutput,
    SupportsComponentDiscovery,
):
    """CFG-distilled joint video/audio generation for MiniMax H3."""

    supports_step_execution: ClassVar[bool] = True
    # DiT implementation constructed for the primary ``transformer``.
    # ``None`` means this module's ``MiniMaxH3DiTModel`` (resolved at call time);
    # a derived pipeline may point this at a subclass.
    _transformer_cls: ClassVar[type[MiniMaxH3DiTModel] | None] = None
    load_vae_decoder: bool = True
    supports_request_cancellation: ClassVar[bool] = True

    _dit_modules: ClassVar[list[str]] = ["transformer", "transformers_ref"]
    _encoder_modules: ClassVar[list[str]] = ["text_encoder"]
    _vae_modules: ClassVar[list[str]] = ["video_vae", "audio_vae"]
    _offload_plan: ClassVar[OffloadPlan] = OffloadPlan(
        offload_submodules={"token_refiner": "blocks"},
        resident_dit_paths=frozenset({"transformer"}),
        encoder_component_types={"text_encoder": TEXT_ENCODER_COMPONENT},
        encoder_block_attrs={"text_encoder": ("vision.blocks", "text_model.layers")},
        on_demand_component_paths=frozenset({"text_encoder", "video_vae", "audio_vae"}),
    )
    _PROFILER_TARGETS: ClassVar[list[str]] = [
        "encode_prompt",
        "_encode_local_media",
        "diffuse",
        "decode",
        "video_vae.decode_latent",
        "audio_vae.decode_latent",
        "prepare_encode",
        "denoise_step",
        "post_decode",
    ]
    dummy_run_num_frames: ClassVar[int] = 0
    # Only distilled releases pin a schedule, so the default keeps the legacy
    # uniform path available to partially constructed pipelines.
    _base_schedule_by_partition: ClassVar[Mapping[str, DMD2SigmaSchedule | None]] = {}
    # Set from --lora-path during construction; absent means no FastH3 adapter.
    _fasth3: FastH3WeightFusion | None = None
    # Set from --lora-path when it names a VDN-H3 checkpoint directory.
    _vdn: VDNCheckpoint | None = None
    _fasth3_checkpoint: FastH3CheckpointSpec | None = None
    # Set from --lora-path when it names an Open-H3-Regenerate release.
    _regenerate: MiniMaxH3RegenerateAdapter | None = None

    def _load_diffusion_lora_adapter(
        self,
        *,
        lora_request: LoRARequest,
        lora_path: str | Path,
        dtype: torch.dtype,
    ) -> tuple[LoRAModel, PEFTHelper] | None:
        # A cache eviction may be followed by a different adapter reusing the
        # same client-supplied ID. Every real load replaces the classification.
        self._clear_adaln_caches()
        self._turbo_lora_specs.pop(lora_request.lora_int_id, None)
        self._native_lora_adapter_ids.discard(lora_request.lora_int_id)
        self._lora_sigma_schedules.pop(lora_request.lora_int_id, None)
        od_config = getattr(self, "od_config", None)
        offload_modes = []
        if od_config is not None:
            resolved_offload = resolve_offload(od_config)
            if resolved_offload.offloads(DIT_COMPONENT):
                if resolved_offload.strategy is OffloadStrategy.MODEL_LEVEL:
                    offload_modes.append("model-level CPU offload")
                elif resolved_offload.strategy is OffloadStrategy.LAYER_WISE:
                    offload_modes.append("layerwise offload")
        loaded = load_minimax_h3_turbo_lora(
            partition=self.partition,
            lora_request=lora_request,
            lora_path=lora_path,
            dtype=dtype,
            unsupported_offload_mode=" or ".join(offload_modes) or None,
        )
        if loaded is not None:
            lora_model, peft_helper, turbo_spec = loaded
            self._turbo_lora_specs[lora_request.lora_int_id] = turbo_spec
            return lora_model, peft_helper

        # Selection is by the artifact's safetensors ``key_format``, not by the
        # running platform: the native loader is checkpoint-format parsing with
        # no ``torch_npu`` dependency, so it needs no ``current_omni_platform``
        # dispatch and binds the same adapter on NPU, CUDA and CPU.
        native_loaded = load_minimax_h3_native_lora(
            partition=self.partition,
            lora_request=lora_request,
            lora_path=lora_path,
            dtype=dtype,
            unsupported_offload_mode=" or ".join(offload_modes) or None,
        )
        if native_loaded is not None:
            lora_model, peft_helper, sigma_schedule = native_loaded
            self._native_lora_adapter_ids.add(lora_request.lora_int_id)
            self._lora_sigma_schedules[lora_request.lora_int_id] = sigma_schedule
            return lora_model, peft_helper
        return None

    def _validate_diffusion_lora_binding(
        self,
        *,
        lora_model: LoRAModel,
        bound_lora_names: frozenset[str],
    ) -> None:
        if lora_model.id in self._turbo_lora_specs:
            missing = sorted(set(lora_model.loras) - bound_lora_names)
            if missing:
                raise ValueError(
                    "MiniMax-H3 Turbo LoRA binding is incomplete: "
                    f"bound={len(bound_lora_names)}/{len(lora_model.loras)}, missing={missing[:5]}"
                )
            return
        if lora_model.id not in self._native_lora_adapter_ids:
            return
        missing = sorted(set(lora_model.loras) - bound_lora_names)
        if missing:
            raise ValueError(
                "MiniMax-H3 native LoRA binding is incomplete: "
                f"bound={len(bound_lora_names)}/{len(lora_model.loras)}, missing={missing[:5]}"
            )

    def _active_turbo_spec(self, sampling: Any) -> TurboSpec | None:
        """Return the spec of the Turbo adapter this request actually applies.

        A recognized adapter at scale 0 contributes nothing, so it neither
        constrains the task nor imposes its sampler contract.
        """

        lora_request = sampling.lora_request
        if lora_request is None or math.isclose(0.0, float(sampling.lora_scale)):
            return None
        return self._turbo_lora_specs.get(lora_request.lora_int_id)

    def _has_active_native_lora(self, sampling: Any) -> bool:
        lora_request = sampling.lora_request
        return (
            lora_request is not None
            and not math.isclose(0.0, float(sampling.lora_scale))
            and lora_request.lora_int_id in self._native_lora_adapter_ids
        )

    def _validate_native_sampling(self, sampling: Any, *, task: str) -> None:
        if task != "t2va":
            raise OmniClientError("MiniMax-H3 native LoRA supports T2VA requests only")
        # Derive the expected count from the adapter's own schedule so the
        # message can never disagree with the schedule the denoise loop runs.
        schedule = self._lora_sigma_schedules.get(sampling.lora_request.lora_int_id)
        expected_steps = MINIMAX_H3_NATIVE_INFERENCE_STEPS if schedule is None else schedule.num_inference_steps
        # Only request mode can take the count from the adapter schedule: step
        # mode admits the request in ``StepScheduler``, which reads
        # ``num_inference_steps`` off it before any pipeline hook runs. Reject
        # omission there rather than advertise a contract that would either fail
        # admission or disagree with the denoise loop.
        od_config = getattr(self, "od_config", None)
        omission_allowed = not getattr(od_config, "step_execution", False)
        or_omitted = " or omitted" if omission_allowed else ""
        sigma_steps = sampling.num_inference_steps
        if sigma_steps is None:
            if omission_allowed:
                return
            raise OmniClientError(
                f"MiniMax-H3 native LoRA requires an explicit num_inference_steps={expected_steps} "
                "under step execution, because the step scheduler derives the total step count from "
                "the request before the adapter schedule is known"
            )
        if int(sigma_steps) == expected_steps + 1:
            raise OmniClientError(
                "MiniMax-H3 native LoRA uses the distilled interval-count contract; "
                f"num_inference_steps must be {expected_steps}{or_omitted}, not {expected_steps + 1}"
            )
        if int(sigma_steps) != expected_steps:
            raise OmniClientError(
                f"MiniMax-H3 native LoRA requires num_inference_steps={expected_steps} "
                f"(one denoiser evaluation per sigma interval){or_omitted}"
            )

    def _sigma_schedule_for_request(self, sampling: Any, task: str) -> DMD2SigmaSchedule | None:
        lora_request = sampling.lora_request
        if (
            lora_request is not None
            and not math.isclose(0.0, float(sampling.lora_scale))
            and lora_request.lora_int_id in self._lora_sigma_schedules
        ):
            adapter_schedule = self._lora_sigma_schedules[lora_request.lora_int_id]
            checkpoint_schedule = self._base_schedule_for_task(task)
            if checkpoint_schedule is not None:
                raise OmniClientError(
                    "MiniMax-H3 native LoRA cannot be activated on a checkpoint that already pins base_schedule"
                )
            return adapter_schedule
        return self._base_schedule_for_task(task)

    def _validate_turbo_sampling(self, sampling: Any, spec: TurboSpec) -> None:
        """Hold a request to the contract of the artifact that is loaded.

        Denoiser count and both flow shifts vary across the Turbo family, so
        each is checked against the adapter's own spec rather than a single
        published configuration.
        """

        extra = sampling.extra_args or {}
        if sampling.num_inference_steps != spec.denoise_steps:
            raise OmniClientError(
                f"{spec.filename} is a {spec.denoise_steps}-step artifact and requires "
                f"num_inference_steps={spec.denoise_steps} "
                f"({spec.sigma_points} sigma points produce {spec.denoise_steps} denoiser evaluations)"
            )
        try:
            video_shift = float(extra.get("flow_shift", self.default_video_shift))
        except (TypeError, ValueError) as exc:
            raise OmniClientError(f"{spec.filename} requires flow_shift={spec.video_shift:g}") from exc
        if not math.isclose(video_shift, spec.video_shift):
            raise OmniClientError(f"{spec.filename} requires flow_shift={spec.video_shift:g}")
        try:
            audio_shift = float(extra.get("audio_flow_shift", self.default_audio_shift))
        except (TypeError, ValueError) as exc:
            raise OmniClientError(f"{spec.filename} requires audio_flow_shift={spec.audio_shift:g}") from exc
        if not math.isclose(audio_shift, spec.audio_shift):
            raise OmniClientError(f"{spec.filename} requires audio_flow_shift={spec.audio_shift:g}")

    def adopt_cache_dit_backend(self, backend: CacheDiTBackend) -> None:
        """Adopt runner-installed generic Cache-DiT for request transitions."""

        self._cache_dit_runtime.adopt(
            backend,
            installation_key=MINIMAX_H3_GENERIC_CACHE_KEY,
        )

    def is_cache_dit_enabled(self) -> bool:
        """Return the request-scoped Cache-DiT installation state."""

        return self._cache_dit_runtime.is_enabled

    def __init__(
        self,
        *,
        od_config: OmniDiffusionConfig,
        prefix: str = "",
    ) -> None:
        del prefix
        super().__init__()
        self.od_config = od_config
        self.parallel_config = od_config.parallel_config
        if int(self.parallel_config.cfg_parallel_size) != 1:
            raise ValueError("MiniMax-H3 is CFG-distilled and has no negative branch; cfg_parallel_size must be 1")
        # A request that omits attention_schedule and latent_refine inherits both defaults, a pair
        # _prepare_encoder_conditioning_inputs rejects; fail here instead of on every such request.
        service_schedule = getattr(od_config, "diffusion_attention_schedule", None)
        additional_config = getattr(od_config, "additional_config", None) or {}
        if (
            service_schedule is not None
            and service_schedule.default
            and parse_minimax_h3_latent_refine_request(additional_config.get("latent_refine")) is not None
        ):
            raise ValueError(
                "MiniMax H3 cannot combine default diffusion_attention_schedule ranges with a latent_refine "
                "default in --additional-config: every request that omits attention_schedule and latent_refine "
                "would be rejected. Remove the default ranges or the latent_refine default."
            )
        self.device = get_local_device()
        self.load_text_encoder = od_config.model_loaded.get("text_encoder", True)
        self.load_vae_encoder = od_config.model_loaded.get("vae_encoder", True)
        self.load_vae_decoder = od_config.model_loaded.get("vae_decoder", True)
        if not self.load_vae_decoder and self.load_vae_encoder:
            raise ValueError(
                "MiniMax H3 external decoding requires vae_encoder=false and external encoder conditioning"
            )
        if self.load_vae_encoder is False and self.load_text_encoder is True:
            raise ValueError(
                "MiniMax H3 does not support local text encoding with external media conditioning; "
                "set text_encoder=false or enable vae_encoder"
            )
        self._encoder_modules = ["text_encoder"] if self.load_text_encoder else []
        self._PROFILER_TARGETS = list(type(self)._PROFILER_TARGETS)
        encoder_block_attrs = dict(self._offload_plan.encoder_block_attrs)
        if not self.load_text_encoder:
            encoder_block_attrs.pop("text_encoder", None)
        on_demand_component_paths = set(self._offload_plan.on_demand_component_paths)
        if not self.load_text_encoder:
            on_demand_component_paths.discard("text_encoder")
        if not self.load_vae_decoder:
            on_demand_component_paths.difference_update(("video_vae", "audio_vae"))
            self._vae_modules = []
            self._PROFILER_TARGETS = [
                name
                for name in self._PROFILER_TARGETS
                if name not in {"decode", "video_vae.decode_latent", "audio_vae.decode_latent"}
            ]
        self._offload_plan = replace(
            self._offload_plan,
            encoder_block_attrs=encoder_block_attrs,
            on_demand_component_paths=frozenset(on_demand_component_paths),
        )
        if not self.load_text_encoder:
            self._PROFILER_TARGETS.remove("encode_prompt")
        if not self.load_vae_encoder:
            self._PROFILER_TARGETS.remove("_encode_local_media")
        modular = is_minimax_h3_modular(str(od_config.model), od_config.revision)
        self.partition = _minimax_h3_partition_for_task(
            getattr(od_config, "task_type", None),
            str(od_config.model),
        )
        control_path = getattr(od_config, "controlnet_model_path", None)
        if control_path:
            if not Path(control_path).is_file() or Path(control_path).suffix != ".safetensors":
                raise ValueError("--controlnet-model-path must be a local original .safetensors file")
            if not modular and self.partition != "fl2va":
                raise ValueError("H3 control requires the FL2VA checkpoint partition")
            unsupported = (
                not self.load_vae_encoder
                or int(self.parallel_config.ulysses_degree) != 1
                or int(self.parallel_config.ring_degree) != 1
                or int(self.parallel_config.allgather_degree) != 1
                or getattr(self.parallel_config, "use_hsdp", False)
                or getattr(od_config, "step_execution", False)
                or getattr(od_config, "quantization_config", None)
                or resolve_offload(od_config).strategy is not OffloadStrategy.NONE
                or getattr(od_config, "host_weight_runtime_mode", "disabled") != "disabled"
                or getattr(od_config, "cache_backend", "none") not in (None, "none")
            )
            if unsupported:
                raise ValueError(
                    "H3 control requires request mode, local VAE encoding, dense weights, "
                    "and no cache/offload/SP/HSDP; TP is supported"
                )
        self._turbo_lora_specs: dict[int, TurboSpec] = {}
        self._native_lora_adapter_ids: set[int] = set()
        self._lora_sigma_schedules: dict[int, DMD2SigmaSchedule] = {}
        model_root = _resolve_minimax_h3_model_root(
            str(od_config.model),
            od_config.revision,
            self.partition,
            load_text_encoder=self.load_text_encoder,
        )
        if modular:
            model_path = model_root
            self._fasth3_checkpoint = FastH3CheckpointSpec.from_metadata(
                json.loads((model_root / "fastvideo_inference.json").read_text(encoding="utf-8"))
            )
            if str(od_config.task_type or "auto").lower() == "auto":
                self.partition = self._fasth3_checkpoint.partition
            if control_path and self.partition != "fl2va":
                raise ValueError("H3 control requires the FL2VA checkpoint partition")
            self._fasth3_checkpoint.check_serving_contract(partition=self.partition, od_config=od_config)
            release = self._fasth3_checkpoint.release_metadata()
            if isinstance(self._fasth3_checkpoint, FastH3OmniCheckpointSpec):
                vae_model_path = self._fasth3_checkpoint.resolve_base_components(
                    load_text_encoder=self.load_text_encoder and not (model_root / "text_encoder/config.json").is_file()
                )
            else:
                vae_model_path = self._fasth3_checkpoint.resolve_native_vaes(model_root)
        else:
            model_path = model_root / ("Ref2VA" if self.partition == "ref2va" else "FL2VA")
            model_index = json.loads((model_path / "model_index.json").read_text(encoding="utf-8"))
            release = model_index.get("_minimax_h3") or {}
            vae_model_path = model_path
        partition = str(release.get("partition", "")).lower()
        expected_partition = "ref2va" if self.partition == "ref2va" else "fl2va"
        if partition != expected_partition:
            raise ValueError(f"invalid MiniMax-H3 {expected_partition} partition at {model_path}")

        supported_tasks = {str(task).lower() for task in release.get("tasks", [])}
        if not supported_tasks:
            supported_tasks = {"ref2va"} if partition == "ref2va" else {"t2va", "fl2va"}
        ref2va_model_path = None
        if self.partition == "combined":
            ref2va_model_path = model_root / "Ref2VA"
            ref2va_index_path = ref2va_model_path / "model_index.json"
            if not ref2va_index_path.is_file():
                raise ValueError(f"Ref2VA partition not found at {ref2va_model_path}")
            ref2va_index = json.loads(ref2va_index_path.read_text(encoding="utf-8"))
            ref2va_release = ref2va_index.get("_minimax_h3") or {}
            if str(ref2va_release.get("partition", "")).lower() != "ref2va":
                raise ValueError(f"invalid MiniMax-H3 ref2va partition at {ref2va_model_path}")
            supported_tasks.update(str(task).lower() for task in ref2va_release.get("tasks", ["ref2va"]))

        self.supported_tasks = frozenset(supported_tasks)
        shifts = release.get("sigma_shift_scales") or {}
        self.default_video_shift = float(shifts.get("video", 12.0))
        self.default_audio_shift = float(shifts.get("audio", 3.0))
        # Distilled releases pin their own few-step rectified-flow positions; the
        # uniform schedule derived from num_inference_steps does not match what
        # such a checkpoint was trained on. Each partition carries its own
        # contract, so a distilled FL2VA must not drag Ref2VA onto its schedule.
        self._base_schedule_by_partition = {expected_partition: _read_base_schedule(release)}
        if ref2va_model_path is not None:
            self._base_schedule_by_partition["ref2va"] = _read_base_schedule(ref2va_release)

        encoder_model_path = (
            vae_model_path
            if isinstance(self._fasth3_checkpoint, FastH3OmniCheckpointSpec)
            and not (model_path / "text_encoder/config.json").is_file()
            else model_path
        )
        transformer_component = self._fasth3_checkpoint.transformer_component if modular else "transformer"
        self.weights_sources = [
            DiffusersPipelineLoader.ComponentSource(
                model_or_path=str(model_path),
                subfolder=transformer_component,
                revision=od_config.revision,
                prefix="transformer.",
                fall_back_to_pt=False,
            )
        ]
        if control_path:
            self.weights_sources.append(
                DiffusersPipelineLoader.ComponentSource(
                    model_or_path=str(Path(control_path).parent),
                    subfolder=None,
                    revision=None,
                    prefix="controlnet.",
                    fall_back_to_pt=False,
                    allow_patterns_overrides=[Path(control_path).name],
                )
            )
        self._dit_modules = ["transformer"]
        if ref2va_model_path is not None:
            self.weights_sources.append(
                DiffusersPipelineLoader.ComponentSource(
                    model_or_path=str(ref2va_model_path),
                    subfolder="transformer",
                    revision=od_config.revision,
                    prefix="transformers_ref.",
                    fall_back_to_pt=False,
                )
            )
            self._dit_modules.append("transformers_ref")
        transformer_quant_config = _resolve_component_quant_config(
            od_config.quantization_config,
            "transformer",
        )
        from vllm_omni.quantization.fp8_config import SerializedPerChannelFp8Config

        if isinstance(transformer_quant_config, SerializedPerChannelFp8Config):
            from .checkpoint_quantization import fasth3_fp8_config

            transformer_quant_config = fasth3_fp8_config(model_path / transformer_component)
        packed_dit = model_path / transformer_component / "nvfp4_weights.safetensors"
        if packed_dit.is_file():
            from vllm.distributed import get_tensor_model_parallel_rank

            from .checkpoint_quantization import FastH3NVFP4Config
            from .vae_nvfp4 import require_nvfp4_linear

            require_nvfp4_linear(self.device)
            if transformer_quant_config is not None:
                raise ValueError("FastH3 QAD already contains NVFP4 weights; remove the quantization override")
            transformer_quant_config = FastH3NVFP4Config.from_dit(packed_dit, rank=get_tensor_model_parallel_rank())
            self.weights_sources.insert(
                1,
                DiffusersPipelineLoader.ComponentSource(
                    model_or_path=str(model_path),
                    subfolder=transformer_component,
                    revision=od_config.revision,
                    prefix="transformer.",
                    fall_back_to_pt=False,
                    allow_patterns_overrides=["nvfp4_weights.safetensors"],
                ),
            )
        transformer_cls = type(self)._transformer_cls or MiniMaxH3DiTModel
        self.transformer = transformer_cls(
            od_config,
            quant_config=transformer_quant_config,
            diffusers_weights=modular,
        )
        if self._fasth3_checkpoint is not None:
            spec = self._fasth3_checkpoint
            if isinstance(spec, FastH3OmniCheckpointSpec) and self.transformer.arch.pdd_steps != 32:
                raise ValueError("FastH3 Omni transformer_ref/config.json must declare pdd_steps=32")
            self.transformer.enable_vsa_gates(
                sparsity=spec.vsa_sparsity,
                tile_size=spec.vsa_tile_size,
                ref_policy=spec.vsa_ref_policy,
                ref_keep_rate=spec.vsa_ref_keep_rate,
            )
            logger.info(
                "%s: 8 forwards, video/audio shifts %s/3, VSA sparsity=%s tile=%s",
                spec.name,
                spec.video_shift,
                spec.vsa_sparsity,
                spec.vsa_tile_size,
            )
        if ref2va_model_path is not None:
            self.transformers_ref = MiniMaxH3DiTModel(
                od_config,
                quant_config=transformer_quant_config,
                diffusers_weights=modular,
            )

        self._vdn = VDNCheckpoint.from_od_config(od_config, self.transformer)
        if self._vdn is not None:
            self._vdn.check_serving_contract(partition=self.partition, od_config=od_config)
            # The hybrid modules must exist before the branch tensors stream in.
            self.transformer.enable_vdn(self._vdn.config)
        if self._vdn is None and not modular:
            self._regenerate = resolve_regenerate_adapter(od_config, self.transformer)
        if self._regenerate is not None:
            self._regenerate.check_serving_contract(partition=self.partition, od_config=od_config)
        self._fasth3 = (
            resolve_fasth3_fusion(od_config, self.transformer)
            if self._vdn is None and self._regenerate is None
            else None
        )
        if self._fasth3 is not None and self._fasth3.requires_vsa:
            # The artifact assigns a compression gate per DiT block, so those
            # modules have to exist before load_weights streams them in. Only
            # the ``transformer.`` stream is fused, and ``check_task`` admits
            # T2VA only, so the Ref2VA DiT would carry 50 gates that nothing
            # ever fills or reads.
            self.transformer.enable_vsa_gates()
        if self._fasth3 is not None:
            self._fasth3.check_serving_contract(
                partition=self.partition,
                od_config=od_config,
                video_shift=self.default_video_shift,
                audio_shift=self.default_audio_shift,
            )

        self._configure_adaln_sidecar(
            self.transformer,
            "minimax_h3_adaln_cache_path",
            expected_partition,
            self._fasth3.source if self._fasth3 is not None else None,
            eligible=transformer_quant_config is None
            and not modular
            and self._vdn is None
            and self._regenerate is None,
        )
        if ref2va_model_path is not None:
            self._configure_adaln_sidecar(
                self.transformers_ref,
                "minimax_h3_ref_adaln_cache_path",
                "ref2va",
                None,
                eligible=transformer_quant_config is None and not modular,
            )

        if self.load_text_encoder:
            self.tokenizer = Qwen2TokenizerFast.from_pretrained(
                str(encoder_model_path),
                subfolder="tokenizer",
                local_files_only=os.path.isdir(encoder_model_path),
            )
            self.processor = Qwen3VLProcessor.from_pretrained(
                str(encoder_model_path),
                subfolder="processor",
                local_files_only=os.path.isdir(encoder_model_path),
            )
        else:
            self.tokenizer = None
            self.processor = None

        _, rank, dit_world = _dit_rank_world()
        self._dit_rank = rank
        if self.load_text_encoder:
            text_encoder_tp_size = int(getattr(self.parallel_config, "text_encoder_tp_size", 1))
            if text_encoder_tp_size < 1:
                raise ValueError(f"text_encoder_tp_size must be >= 1, got {text_encoder_tp_size}")
            if text_encoder_tp_size > dit_world:
                raise ValueError(
                    f"text_encoder_tp_size must not exceed the DiT group size ({dit_world}), got {text_encoder_tp_size}"
                )
            # The Qwen3-VL text model uses 64 attention heads / 8 KV heads.
            if 64 % text_encoder_tp_size or 8 % text_encoder_tp_size:
                raise ValueError(
                    "text_encoder_tp_size must divide both Qwen3-VL "
                    f"num_attention_heads (64) and num_key_value_heads (8), "
                    f"got {text_encoder_tp_size}"
                )
            self.text_encoder_tp_size = text_encoder_tp_size
            self.text_encoder_group = self._build_text_encoder_group(text_encoder_tp_size)
            self.text_encoder = MiniMaxH3Qwen3VLEncoder(
                os.path.join(encoder_model_path, "text_encoder"),
                device=self.device,
                load_model=rank < text_encoder_tp_size,
                encoder_group=self.text_encoder_group,
                quant_config=_resolve_minimax_h3_text_encoder_quant_config(od_config.quantization_config),
            )
            if rank < text_encoder_tp_size:
                self.weights_sources.append(
                    DiffusersPipelineLoader.ComponentSource(
                        model_or_path=str(encoder_model_path),
                        subfolder="text_encoder",
                        revision=od_config.revision,
                        prefix="text_encoder.",
                        fall_back_to_pt=False,
                    )
                )
        else:
            self.text_encoder_tp_size = 0
            self.text_encoder_group = None
            self.text_encoder = None
            self._encoder_modules = []
        legacy_manual_components = getattr(od_config, "diffusion_offload_config", None) is None and (
            offload_streams_blocks(od_config)
        )
        # Preserve the legacy MiniMax-H3 low-residency path. The compact API
        # deliberately limits explicit component selection to dit/text_encoder,
        # so VAEs stay resident for new configurations.
        component_load_device = torch.device("cpu") if legacy_manual_components else self.device
        self.video_vae = None
        self.audio_vae = None
        if self.load_vae_decoder:
            lightvae_decoder_path = resolve_h3_lightvae_decoder_path(od_config.additional_config or {})
            self.video_vae = MiniMaxH3VideoVAE(
                os.path.join(vae_model_path, "video_vae"),
                device=self.device,
                load_device=component_load_device,
                decode_only=not self.load_vae_encoder,
                trust_remote_code=od_config.trust_remote_code,
                decoder_source=(od_config.additional_config or {}).get(
                    "video_vae_decoder",
                    str(model_path / "vae_decoder_nvfp4/decoder-nvfp4.safetensors")
                    if lightvae_decoder_path is None
                    and (model_path / "vae_decoder_nvfp4/decoder-nvfp4.safetensors").is_file()
                    else None,
                ),
                lightvae_decoder_path=lightvae_decoder_path,
            )
            self.audio_vae = MiniMaxH3AudioVAE(
                os.path.join(vae_model_path, "audio_vae"),
                device=self.device,
                load_device=component_load_device,
                decode_only=not self.load_vae_encoder,
                trust_remote_code=od_config.trust_remote_code,
            )
        # Registry-side VAE patch-parallel discovery uses ``pipeline.vae``.
        self.vae = self.video_vae

        # Optional learned latent super-resolution, run between the denoise
        # loop and the VAE. Absent unless --additional-config names a
        # checkpoint, so a plain H3 deployment carries none of its weights.
        # The upscaler works one normalization below the pipeline latent, so it
        # needs the same per-channel statistics the VAE denormalizes with.
        def _upscaler_latent_stats() -> tuple[list[float], list[float]]:
            config = _load_component_config(os.path.join(vae_model_path, "video_vae"))
            return config["latents_mean"], config["latents_std"]

        self.latent_upscaler = resolve_minimax_h3_latent_upscaler(
            od_config,
            device=self.device,
            latent_stats=_upscaler_latent_stats,
            default_path=self._regenerate.upscaler_path if self._regenerate is not None else None,
        )

        self._dlo_component_cache = None
        offloads_text_encoder = should_offload_component(od_config, TEXT_ENCODER_COMPONENT)
        needs_component_cache = legacy_manual_components or offloads_text_encoder
        if resolve_offload_strategy(od_config) is OffloadStrategy.DISTRIBUTED_LAYER_WISE and needs_component_cache:
            self._dlo_component_cache = BoundedAllocatorCache(self.device)
            if legacy_manual_components:
                _register_dlo_component_cache(
                    self._dlo_component_cache,
                    self.text_encoder,
                    self.video_vae,
                    self.audio_vae,
                )
            elif offloads_text_encoder:
                _register_dlo_component_cache(self._dlo_component_cache, self.text_encoder)

        self._quality_policy = MiniMaxH3QualityPolicy(od_config)
        self._cache_dit_runtime = RequestScopedCacheDiTRuntime(self)
        self._latent_clip_cache = LatentClipCache(latent_cache_clips(od_config.additional_config))

        self.setup_diffusion_pipeline_profiler(
            enable_diffusion_pipeline_profiler=(od_config.enable_diffusion_pipeline_profiler)
        )

    def load_weights(
        self,
        weights: Iterable[tuple[str, torch.Tensor]],
    ) -> set[str]:
        def source_prefix(item: tuple[str, torch.Tensor]) -> str:
            name, _ = item
            prefix = name.partition(".")[0] + "."
            if prefix in {"transformer.", "transformers_ref.", "text_encoder.", "controlnet."}:
                return prefix
            raise ValueError(f"unexpected MiniMax-H3 weight {name!r}")

        loaded_with_prefix: set[str] = set()
        loaded_prefixes: set[str] = set()
        transformer_loaded: set[str] = set()
        for prefix, grouped_weights in groupby(weights, key=source_prefix):
            if prefix in loaded_prefixes:
                raise ValueError(f"MiniMax-H3 weight source {prefix!r} is not contiguous")
            loaded_prefixes.add(prefix)
            component = (
                self.transformer.controlnet if prefix == "controlnet." else getattr(self, prefix.removesuffix("."))
            )
            if component is None:
                raise ValueError(f"MiniMax-H3 component {prefix.removesuffix('.')!r} is disabled in this deployment")
            stream = ((name[len(prefix) :], tensor) for name, tensor in grouped_weights)
            if prefix == "transformer." and self._vdn is not None:
                stream = self._vdn.apply(stream)
            if prefix == "transformer." and self._regenerate is not None:
                stream = self._regenerate.apply(stream)
            if prefix == "transformer." and self._fasth3 is not None:
                # Fuse before the model shards anything, which is also the only
                # point where the checkpoint's fused QKV/MLP layouts are intact.
                stream = self._fasth3.apply(stream)
            if getattr(component, "_adaln_sidecar_candidate", None) is not None:
                stream = self._verify_adaln_weights(component, stream)
            loaded = component.load_weights(stream)
            if prefix == "transformer.":
                transformer_loaded = set(loaded)
            if prefix not in {"text_encoder.", "controlnet."}:
                component.post_load_weights()
                self._finish_adaln_sidecar(component)
            loaded_prefix = "transformer.controlnet." if prefix == "controlnet." else prefix
            loaded_with_prefix.update(loaded_prefix + name for name in loaded)
        # Both VAEs load eagerly in ``__init__`` rather than through
        # ``weights_sources``. The text encoder uses the shared component
        # loader so online quantization and offload processing follow the same
        # path as the DiT.
        for component_name in ("video_vae", "audio_vae", "latent_upscaler"):
            component = getattr(self, component_name, None)
            if component is None:
                continue
            loaded_with_prefix.update(f"{component_name}.{name}" for name, _ in component.named_parameters())
        if self._vdn is not None:
            self._vdn.validate(transformer_loaded, self.transformer.vdn_parameter_names())
        if self._fasth3 is not None:
            # load_weights only warns on a parameter the model does not have, so
            # close the adapter against what the DiT actually consumed.
            self._fasth3.validate_fully_applied(transformer_loaded)
        if self._regenerate is not None:
            self._regenerate.validate_fully_applied(transformer_loaded)
        if self._fasth3_checkpoint is not None:
            parameter_names = set(dict(self.transformer.named_parameters()))
            required_gates = set()
            for i in range(self.transformer.arch.num_layers):
                prefix = f"blocks.{i}.attn.to_gate_compress."
                required_gates.update(
                    {name for name in parameter_names if name.startswith(prefix)} or {prefix + "weight"}
                )
            if missing_gates := required_gates - transformer_loaded:
                raise ValueError(f"FastH3 V2 checkpoint is missing compression gates: {sorted(missing_gates)}")
        return loaded_with_prefix

    @property
    def lora_is_fused(self) -> bool:
        """True when --lora-path was consumed as a load-time weight fusion."""
        return self._fasth3 is not None or self._vdn is not None or self._regenerate is not None

    def _configure_adaln_sidecar(
        self,
        transformer: MiniMaxH3DiTModel,
        key: str,
        variant: str,
        adapter_path: str | Path | None,
        *,
        eligible: bool,
    ) -> None:
        from safetensors import SafetensorError
        from vllm.distributed import get_tensor_model_parallel_world_size

        from .adaln_cache import MiniMaxH3AdalnCache, file_digest

        config = self.od_config.cache_config
        path = config.get(key) if isinstance(config, Mapping) else getattr(config, key, None)
        if path is None or not transformer.adaln_cache.max_bytes:
            return
        try:
            if not eligible or get_tensor_model_parallel_world_size() != 1:
                raise ValueError("offline sidecar uses native BF16 TP1 math; use the default runtime cache here")
            sidecar = MiniMaxH3AdalnCache(transformer.arch, path=path, model_variant=variant)
            sidecar.bind_adapter(file_digest(adapter_path) if adapter_path is not None else None)
            # Keep optional CPU-derived data outside the registered model tree.
            object.__setattr__(transformer, "_adaln_sidecar_candidate", sidecar)
        except (OSError, RuntimeError, TypeError, ValueError, SafetensorError) as exc:
            logger.warning("Rejecting optional H3 AdaLN sidecar; runtime caching remains enabled: %s", exc)

    @staticmethod
    def _verify_adaln_weights(
        component: MiniMaxH3DiTModel, weights: Iterable[tuple[str, torch.Tensor]]
    ) -> Iterable[tuple[str, torch.Tensor]]:
        for name, tensor in weights:
            candidate = getattr(component, "_adaln_sidecar_candidate", None)
            if candidate is not None:
                try:
                    candidate.verify_weight(name, tensor)
                except ValueError as exc:
                    object.__setattr__(component, "_adaln_sidecar_candidate", None)
                    logger.warning("Rejecting optional H3 AdaLN sidecar: %s", exc)
            yield name, tensor

    @staticmethod
    def _finish_adaln_sidecar(component: nn.Module) -> None:
        from vllm.model_executor.layers.utils import default_unquantized_gemm

        candidate = getattr(component, "_adaln_sidecar_candidate", None)
        if candidate is None:
            return
        try:
            modules = {
                f"blocks.{i}.adaln_proj.linear": block.adaln_proj.linear for i, block in enumerate(component.blocks)
            }
            modules["final_layer.adaln_proj.linear"] = component.final_layer.adaln_proj.linear
            for module in (*modules.values(), component.time_embedder.proj_in, component.time_embedder.proj_out):
                if getattr(module.quant_method, "_gemm_impl", None) is not default_unquantized_gemm:
                    raise ValueError("offline sidecar requires the builder's torch linear backend")
            candidate.finish_loading(component.video_patch_proj.weight.device)
            component.adaln_cache.seed(candidate, modules)
        except (RuntimeError, ValueError) as exc:
            logger.warning("Rejecting optional H3 AdaLN sidecar; using runtime projections: %s", exc)
        finally:
            object.__setattr__(component, "_adaln_sidecar_candidate", None)

    def _clear_adaln_caches(self) -> None:
        for name in ("transformer", "transformers_ref"):
            cache = getattr(getattr(self, name, None), "adaln_cache", None)
            if cache is not None:
                cache.clear()

    def _prepare_adaln_adapter(self, sampling: OmniDiffusionSamplingParams) -> None:
        request = getattr(sampling, "lora_request", None)
        identity = None if request is None else (request.lora_int_id, request.lora_path, float(sampling.lora_scale))
        if identity != getattr(self, "_adaln_adapter_identity", None):
            self._clear_adaln_caches()
            self._adaln_adapter_identity = identity

    def _transformer_for_task(self, task: str) -> MiniMaxH3DiTModel:
        if task == "ref2va" and hasattr(self, "transformers_ref"):
            return self.transformers_ref
        return self.transformer

    def _resolve_sigma_positions(self, task: str, sampling: Any) -> tuple[tuple[float, ...] | None, int]:
        """Pick the rectified-flow positions this request denoises on.

        Returns them explicitly, or ``None`` to leave the uniform ladder to be
        derived from the step count, together with the count the rest of the
        request speaks in.
        """
        if self._fasth3 is not None:
            # A fused student carries its own positions; the checkpoint
            # underneath it is the many-step teacher, whose schedule does not
            # apply. Its five points bound four transformer forwards, and
            # forwards is the unit ``check_request``, the pinned-schedule branch
            # below and Cache-DiT all speak in.
            positions = self._fasth3.base_schedule
            return positions, len(positions) - 1
        sigma_schedule = self._sigma_schedule_for_request(sampling, task)
        if sigma_schedule is None:
            return None, int(sampling.num_inference_steps or 50)
        # The schedule lists sigma boundaries; the denoise loop runs one step
        # per interval, and that count is what requests and Cache-DiT speak in.
        num_steps = sigma_schedule.num_inference_steps
        requested_steps = sampling.num_inference_steps
        if requested_steps is not None and int(requested_steps) != num_steps:
            raise OmniClientError(
                "this MiniMax H3 checkpoint pins a distilled sigma schedule; num_inference_steps "
                f"must be {num_steps} or omitted, got {int(requested_steps)}"
            )
        return sigma_schedule.base_schedule, num_steps

    def _base_schedule_for_task(self, task: str) -> DMD2SigmaSchedule | None:
        """Return the distilled schedule of the partition that serves ``task``."""
        partition = "ref2va" if task == "ref2va" else "fl2va"
        return self._base_schedule_by_partition.get(partition)

    def _resolve_task(
        self,
        requested: str | None,
        multi_modal_data: dict[str, Any] | None = None,
        *,
        audio_mode: str = "native",
        turbo_spec: TurboSpec | None = None,
        has_native_lora: bool = False,
    ) -> str:
        multi_modal_data = multi_modal_data or {}
        if requested is None:
            # A Ref2VA-only startup has no FL2VA transformer; preserve its
            # historical implicit default even for image-only references.
            if self.partition == "ref2va":
                requested = "ref2va"
            elif multi_modal_data.get("video") is not None or (
                multi_modal_data.get("audio") is not None and audio_mode != "lock_source"
            ):
                requested = "ref2va"
            elif multi_modal_data.get("image") is not None:
                requested = "fl2va"
            else:
                requested = "t2va"
        task = str(requested).lower()
        if task not in self.supported_tasks:
            raise OmniClientError(
                f"checkpoint partition {self.partition!r} supports {sorted(self.supported_tasks)}, got task={task!r}"
            )
        if turbo_spec is not None and task not in turbo_spec.supported_tasks:
            raise OmniClientError(
                f"{turbo_spec.filename} is a {turbo_spec.task_family} Turbo artifact and serves "
                f"{sorted(turbo_spec.supported_tasks)}, got task={task!r}"
            )
        if has_native_lora and task != "t2va":
            raise OmniClientError("MiniMax-H3 native LoRA supports T2VA requests only")
        if self._fasth3 is not None:
            self._fasth3.check_task(task)
        return task

    def _build_text_encoder_group(self, text_encoder_tp_size: int) -> Any:
        """Create the encoder tensor-parallel process group.

        The encoder group covers the first ``text_encoder_tp_size`` DiT ranks
        (the DiT group is always global ranks ``[0, dit_world)``).  Every rank
        participates in ``new_group`` so the collective completes; ranks
        outside the group never run encoder collectives.  For a single-rank
        encoder we return a lightweight placeholder so non-encoder ranks do
        not need to join a ``GroupCoordinator`` that would assert on ranks
        outside the group.
        """
        if text_encoder_tp_size == 1:
            return _SingleRankEncoderGroup(rank=self._dit_rank)
        ranks = list(range(text_encoder_tp_size))
        return init_world_group(
            ranks=ranks,
            local_rank=envs.LOCAL_RANK,
            backend=current_omni_platform.dist_backend,
        )

    def _encoder_group_broadcast_tensor(
        self,
        tensor: torch.Tensor | None,
        *,
        dtype: torch.dtype,
        device: torch.device,
    ) -> torch.Tensor:
        """Broadcast a tensor from encoder rank 0 over the encoder TP group."""
        group = self.text_encoder_group
        if group.world_size == 1:
            if tensor is None:
                raise ValueError("source tensor is required for single-rank execution")
            return tensor.to(device=device, dtype=dtype)

        shape = torch.zeros(8, dtype=torch.long, device=device)
        if group.rank_in_group == 0:
            if tensor is None:
                raise ValueError("encoder rank 0 must provide a tensor to broadcast")
            shape[0] = tensor.ndim
            shape[1 : tensor.ndim + 1] = torch.tensor(tensor.shape, device=device)
        torch.distributed.broadcast(shape, src=group.ranks[0], group=group.device_group)
        ndim = int(shape[0].item())
        tensor_shape = tuple(int(value) for value in shape[1 : ndim + 1].tolist())
        if group.rank_in_group == 0:
            output = tensor.to(device=device, dtype=dtype).contiguous()
        else:
            output = torch.empty(tensor_shape, device=device, dtype=dtype)
        torch.distributed.broadcast(output, src=group.ranks[0], group=group.device_group)
        return output

    def _distribute_encode_inputs(
        self,
        ids: torch.Tensor | None,
        vision_kwargs: dict[str, torch.Tensor],
    ) -> torch.Tensor:
        """Fan out encode inputs from encoder rank 0 to the encoder TP ranks.

        Mutates ``vision_kwargs`` in place so every encoder rank ends up with
        the same vision tensors, and returns the broadcast ``input_ids``.
        """
        keys = ("pixel_values", "image_grid_thw", "pixel_values_videos", "video_grid_thw")
        key_dtypes = {
            "pixel_values": torch.bfloat16,
            "pixel_values_videos": torch.bfloat16,
            "image_grid_thw": torch.long,
            "video_grid_thw": torch.long,
        }
        group = self.text_encoder_group
        device = self.device
        if group.world_size == 1:
            if ids is None:
                raise ValueError("encoder rank 0 must produce input ids")
            return ids.to(device=device, dtype=torch.long)

        mask = torch.zeros(len(keys), dtype=torch.long, device=device)
        if group.rank_in_group == 0:
            for index, key in enumerate(keys):
                mask[index] = 1 if key in vision_kwargs else 0
        torch.distributed.broadcast(mask, src=group.ranks[0], group=group.device_group)

        if group.rank_in_group == 0:
            ids = self._encoder_group_broadcast_tensor(ids, dtype=torch.long, device=device)
        else:
            ids = self._encoder_group_broadcast_tensor(None, dtype=torch.long, device=device)
        for index, key in enumerate(keys):
            if mask[index].item() == 0:
                continue
            source = vision_kwargs.get(key) if group.rank_in_group == 0 else None
            vision_kwargs[key] = self._encoder_group_broadcast_tensor(
                source,
                dtype=key_dtypes[key],
                device=device,
            )
        return ids

    def _encode_text_hidden(
        self,
        input_ids: torch.Tensor,
        vision_kwargs: dict[str, torch.Tensor],
    ) -> torch.Tensor:
        if getattr(self, "_model_cpu_offload_modules", None):
            # Invoke nn.Module.__call__ so the generic model-level offloader
            # swaps the resident DiT and encoder.
            return self.text_encoder(input_ids, **vision_kwargs)

        if self._uses_manual_component_offload(self.text_encoder):
            with self._component_on_device(self.text_encoder):
                return self.text_encoder.encode_ids(input_ids, **vision_kwargs)

        # Keep Qwen resident when it is not selected for layerwise offload.
        self.text_encoder.load_to_device()
        return self.text_encoder.encode_ids(input_ids, **vision_kwargs)

    def _uses_manual_component_offload(self, component: nn.Module) -> bool:
        od_config = getattr(self, "od_config", None)
        if od_config is None:
            return False
        if getattr(od_config, "diffusion_offload_config", None) is None:
            # The compatibility topology stages every component it can.
            return offload_streams_blocks(od_config)
        return component is getattr(self, "text_encoder", None) and should_offload_component(
            od_config, TEXT_ENCODER_COMPONENT
        )

    def enable_omni_model_cpu_offload(
        self,
        *,
        device: torch.device,
        pin_memory: bool,
        use_hsdp: bool,
        offload_components: frozenset[str] | None = None,
    ) -> None:
        if getattr(self, "_model_cpu_offload_modules", None):
            return

        components = ModuleDiscovery.discover(self)
        dits = components.dits
        # This optional stage owns its own weight placement. Register it only
        # with model-level sequential offload; generic VAE discovery would
        # otherwise move it onto the GPU during unrelated layerwise setup.
        upscaler = getattr(self, "latent_upscaler", None)
        stages = [*components.encoders, *components.vaes]
        if upscaler is not None:
            stages.append(upscaler)
        modules = [*dits, *stages]
        # The upscaler normally parks its own weights on the host. Keep it as
        # an execution stage so activating it evicts the DiT, but do not scan
        # its parameters on every DiT step unless residency was requested.
        selected_stages = [stage for stage in stages if stage is not upscaler or upscaler.resident]
        selection_options: dict[str, Any] = {}
        if offload_components is not None:
            if DIT_COMPONENT in offload_components and not dits:
                raise ValueError("MiniMax-H3 has no loaded DiT for selected module offload")
            if TEXT_ENCODER_COMPONENT in offload_components and not components.encoders:
                raise ValueError("MiniMax-H3 has no loaded text encoder for selected module offload")
            selected_explicit_stages = [*components.encoders] if TEXT_ENCODER_COMPONENT in offload_components else []
            if upscaler is not None and upscaler.resident:
                selected_explicit_stages.append(upscaler)
            selection_options = {
                "offload_dit_modules": dits if DIT_COMPONENT in offload_components else (),
                "offload_encoder_modules": selected_explicit_stages,
            }
        elif upscaler is not None:
            selection_options["offload_encoder_modules"] = selected_stages
        apply_sequential_offload(
            dit_modules=dits,
            encoder_modules=stages,
            device=device,
            pin_memory=pin_memory,
            use_hsdp=use_hsdp,
            offload_initial_dits=offload_components is None or DIT_COMPONENT in offload_components,
            **selection_options,
        )

        self._model_cpu_offload_modules = modules
        logger.info(
            "MiniMax-H3 model-level CPU offload enabled for selected components: %s",
            sorted(offload_components) if offload_components is not None else "legacy full topology",
        )

    def disable_omni_model_cpu_offload(self) -> None:
        modules = getattr(self, "_model_cpu_offload_modules", None)
        if not modules:
            return
        remove_sequential_offload(modules)
        self._model_cpu_offload_modules = []

    @contextmanager
    def _component_on_device(self, component: nn.Module):
        if getattr(self, "_model_cpu_offload_modules", None):
            # Sequential offload hooks whole modules (enable_omni_model_cpu_offload
            # registers them on the discovered components, e.g. the real
            # video_vae). Split-residency proxies carry no hook, so unwrap to the
            # hooked module before entering the context — whole-module movement
            # has no half-residency benefit anyway. The check is a type check, not
            # getattr: Mock components auto-create any attribute, which would
            # unwrap them to a child mock and break scope tracking.
            if isinstance(component, _VideoVAEPartProxy):
                component = component.sequential_offload_target
            with sequential_offload_component(component):
                yield
            return
        staged = self._uses_manual_component_offload(component)
        try:
            if staged:
                component.load_to_device()
            yield
        except BaseException:
            if staged:
                try:
                    component.offload_to_cpu()
                except BaseException:
                    logger.exception("Failed to release %s after component failure", component.__class__.__name__)
                cache = getattr(self, "_dlo_component_cache", None)
                if cache is not None:
                    try:
                        cache.release_if_needed(force=True)
                    except BaseException:
                        logger.exception("Failed to release retained allocator cache after component failure")
            raise
        else:
            if staged:
                try:
                    component.offload_to_cpu()
                except BaseException:
                    cache = getattr(self, "_dlo_component_cache", None)
                    if cache is not None:
                        try:
                            cache.release_if_needed(force=True)
                        except BaseException:
                            logger.exception("Failed to release retained allocator cache after offload failure")
                    raise

    @staticmethod
    def _is_output_owner_rank() -> bool:
        """Whether this rank's output is returned by the diffusion executor."""
        return not dist.is_available() or not dist.is_initialized() or dist.get_rank() == 0

    def _encode_visual_conditions(
        self,
        images: list[Image.Image],
        prepared_videos: list[dict[str, Any]] | None,
        *,
        video_count: int,
    ) -> tuple[torch.Tensor | None, list[tuple[int, int, int]]]:
        rows: list[torch.Tensor] = []
        shapes: list[tuple[int, int, int]] = []
        _, rank, _ = _dit_rank_world()
        # encode_image retains parallel tiling when there are enough tiles.
        # Every VAE rank must finish its codec collectives before the latent
        # broadcast, including when refinement enlarges the keyframe images.
        encode_images = bool(images) and (rank == 0 or self.video_vae.is_distributed_enabled())
        # Keep image and video references in one residency window when both
        # appear in a request; otherwise the video branch would reload the VAE.
        # Encoding touches only the CNN encoder half, so the 9GB ViT decoder
        # stays off the device for the whole window.
        needs_video_vae = video_count > 0 or encode_images
        video_vae_context = (
            self._component_on_device(self.video_vae.encoder_component) if needs_video_vae else nullcontext()
        )
        with video_vae_context:
            if images:
                image_rows = None
                if encode_images:
                    image_rows = torch.cat([self.video_vae.encode_image(image) for image in images])
                rows.append(
                    _broadcast_tensor(
                        image_rows if rank == 0 else None,
                        dtype=torch.float32,
                        device=self.device,
                    )
                )
                shapes.extend((1, image.height // 16, image.width // 16) for image in images)
            if video_count:
                video_rows, video_shapes = self._encode_video_conditions_resident(
                    prepared_videos,
                    count=video_count,
                )
                rows.append(video_rows)
                shapes.extend(video_shapes)
        # The latents are extracted; the encode's input/staging pages are idle
        # and must not stay mapped through the denoise and decode peaks.
        if needs_video_vae:
            self._release_stage_cache()
        return (torch.cat(rows) if rows else None), shapes

    def _offload_model_cpu_stage_output(self, tensor: torch.Tensor) -> torch.Tensor:
        """Release a decoded output's storage before a later seed reloads the DiT.

        Model-level CPU offload makes the VAE hook evict the DiT before decode.
        For a multi-output request, however, the next seed reloads the DiT while
        the preceding decoded output would otherwise still occupy the device.
        The reply rank performs the D2H copy early; ranks whose outputs are not
        consumed retain only a metadata placeholder for the final concatenation.

        Call this on the tensor that is actually returned to the engine. Audio is
        released inside ``decode``; video is released by the callers of ``decode``
        only after ``_prepare_minimax_h3_video_output`` has quantized it, so the
        early D2H copy carries ``uint8`` frames rather than the decoded floats.
        """
        if not getattr(self, "_model_cpu_offload_modules", None):
            return tensor
        if self._is_output_owner_rank():
            return tensor.cpu()
        return torch.empty(tensor.shape, dtype=tensor.dtype, device="meta")

    def _initial_noise(
        self,
        *,
        seed: int,
        latent_t: int,
        latent_h: int,
        latent_w: int,
        audio_t: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        video_generator = torch.Generator(device="cpu").manual_seed(seed)
        video = torch.randn(
            1,
            24,
            latent_t,
            latent_h,
            latent_w,
            generator=video_generator,
            dtype=torch.float32,
        )
        video_rows = minimax_h3_patchify_video_latent(
            video,
            patch_size=(1, 2, 2),
        )
        audio_generator = torch.Generator(device="cpu").manual_seed(seed)
        audio_rows = torch.randn(
            audio_t * 2,
            32,
            generator=audio_generator,
            dtype=torch.float32,
        )
        return video_rows, audio_rows

    @staticmethod
    def _renoise_rows(
        init_latents: tuple[torch.Tensor, torch.Tensor],
        *,
        noise_video: torch.Tensor,
        noise_audio: torch.Tensor,
        sigma_video: float,
        sigma_audio: float,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Put finished latents back on the flow at the given sigmas.

        The rectified-flow forward process is ``x_s = (1 - s) * x0 + s * noise``
        -- the interpolation :func:`minimax_h3_euler_eta0_step` walks back down
        -- so this lands the latents exactly where a full pass would have been
        at that sigma, which is what makes resuming mid-schedule in-distribution.
        """
        video_latent, audio_latent = init_latents
        video_prior = minimax_h3_patchify_video_latent(
            video_latent.detach().to(device="cpu", dtype=torch.float32),
            patch_size=(1, 2, 2),
        )
        audio_prior = minimax_h3_pack_audio_latent(audio_latent.detach().to(device="cpu", dtype=torch.float32))
        if video_prior.shape != noise_video.shape:
            raise ValueError(
                f"refine video rows {tuple(video_prior.shape)} do not match the "
                f"target layout {tuple(noise_video.shape)}"
            )
        if audio_prior.shape != noise_audio.shape:
            raise ValueError(
                f"refine audio rows {tuple(audio_prior.shape)} do not match the "
                f"target layout {tuple(noise_audio.shape)}"
            )
        return (
            (1.0 - sigma_video) * video_prior + sigma_video * noise_video,
            (1.0 - sigma_audio) * audio_prior + sigma_audio * noise_audio,
        )

    @contextmanager
    def _resident_dit_layers_on_device(self, *, enabled: bool = True):
        controller = getattr(self, "_dlo_residency_controller", None)
        if controller is not None and enabled:
            controller.load_resident_layers()
        try:
            yield
        finally:
            if controller is not None and enabled:
                controller.offload_resident_layers()

    def _build_denoise_inputs(
        self,
        *,
        task: str,
        text_embeddings: torch.Tensor,
        text_tags: torch.Tensor,
        seed: int,
        latent_t: int,
        latent_h: int,
        latent_w: int,
        audio_t: int,
        num_frames: int,
        num_steps: int,
        video_shift: float,
        audio_shift: float,
        base_schedule: Sequence[float] | None,
        visual_condition: torch.Tensor | None,
        visual_condition_shape: tuple[int, int, int] | None,
        audio_condition: torch.Tensor | None,
        ref_audio_t: int | None,
        ref_blocks: list[dict[str, Any]] | None = None,
        visual_condition_shapes: list[tuple[int, int, int]] | None = None,
        audio_condition_lengths: list[int] | None = None,
        keyframe_frame_indices: list[int] | None = None,
        control_rows: torch.Tensor | None = None,
        control_context_scale: float = 1.0,
        guide_blocks: list[dict[str, Any]] | None = None,
        pad_seq_len: int | None = None,
        locked_audio_rows: torch.Tensor | None = None,
        temporal_offset: float = 0.0,
        media_time_origin: int | None = None,
        video_edit_clean_rows: torch.Tensor | None = None,
        video_edit_mask_rows: torch.Tensor | None = None,
        video_edit_restore_mask_rows: torch.Tensor | None = None,
        audio_edit_clean_rows: torch.Tensor | None = None,
        audio_edit_mask_rows: torch.Tensor | None = None,
        audio_edit_restore_mask_rows: torch.Tensor | None = None,
        sampler: str = "euler",
        init_latents: tuple[torch.Tensor, torch.Tensor] | None = None,
        refine: MiniMaxH3LatentRefineSpec | None = None,
        precomputed_initial_noise: tuple[torch.Tensor, torch.Tensor] | None = None,
        precomputed_visual_condition_noise: torch.Tensor | None = None,
    ) -> dict[str, Any]:
        """Build the packed layout, initial rows, anchors, and sigma schedules.

        Shared by request-mode :meth:`diffuse` and step-mode
        :meth:`prepare_encode` so both paths start from identical state.

        ``init_latents`` and ``refine`` turn the pass into a second, partial
        one: the rows start from those latents re-noised to the schedule
        position ``refine`` selects, and the returned schedules begin there.
        """
        sampler = normalize_h3_sampler(sampler)
        if sampler != "euler" and base_schedule is not None:
            raise ValueError(
                "MiniMax H3 res_multistep sampling with a fixed distilled sigma schedule has not been validated; "
                "use sampler='euler' for this schedule."
            )
        video_sigmas = minimax_h3_time_shift_sigmas(
            num_steps=num_steps,
            shift_scale=video_shift,
            base_schedule=base_schedule,
        )
        audio_sigmas = minimax_h3_time_shift_sigmas(
            num_steps=num_steps,
            shift_scale=audio_shift,
            base_schedule=base_schedule,
        )
        if precomputed_initial_noise is None:
            initial_video, initial_audio = self._initial_noise(
                seed=seed,
                latent_t=latent_t,
                latent_h=latent_h,
                latent_w=latent_w,
                audio_t=audio_t,
            )
        else:
            initial_video, initial_audio = precomputed_initial_noise
        if init_latents is not None:
            if refine is None:
                raise ValueError("init_latents needs a refine spec to place them on the schedule")
            # Video and audio are shifted apart (12.0 against 3.0 by default),
            # so the two schedules hold different sigmas at the same position.
            # The loop steps them by index, so the pass has to resume at one
            # index and re-noise each modality to its own sigma there.
            start = refine.start_index(len(video_sigmas))
            video_sigmas = video_sigmas[start:]
            audio_sigmas = audio_sigmas[start:]
            initial_video, initial_audio = self._renoise_rows(
                init_latents,
                noise_video=initial_video,
                noise_audio=initial_audio,
                sigma_video=video_sigmas[0],
                sigma_audio=audio_sigmas[0],
            )
        if task == "ref2va" or guide_blocks:
            # Timeline guides use the block layout for every task: guides pack
            # first, then any references, and only the guides carry frame_index.
            if ref_blocks is None and not guide_blocks:
                if visual_condition_shape is None or ref_audio_t is None:
                    raise ValueError("ref2va condition metadata is missing")
                _, ref_h, ref_w = visual_condition_shape
                ref_blocks = [
                    {"kind": "image", "latent_h": ref_h, "latent_w": ref_w},
                    {"kind": "audio", "ref_audio_t": ref_audio_t},
                ]
            packed = minimax_h3_packed_sequence_ref2va_blocks(
                text_len=int(text_embeddings.shape[0]),
                latent_t=latent_t,
                latent_h=latent_h,
                latent_w=latent_w,
                audio_t=audio_t,
                ref_blocks=ref_blocks or [],
                guide_blocks=guide_blocks,
                seq_len=pad_seq_len,
                temporal_offset=temporal_offset,
                media_time_origin=media_time_origin,
            )
        else:
            packed = minimax_h3_packed_sequence(
                text_len=int(text_embeddings.shape[0]),
                latent_t=latent_t,
                latent_h=latent_h,
                latent_w=latent_w,
                audio_t=audio_t,
                include_keyframe_cond=task == "fl2va",
                keyframe_frame_indices=keyframe_frame_indices if task == "fl2va" else None,
                frame_count=num_frames if task == "fl2va" else None,
                seq_len=pad_seq_len,
            )
        # Report the effective shape at info level exactly when a request pins
        # it, so a deployment can confirm the pin landed without raising the
        # log level for every request.
        log = logger.info if pad_seq_len is not None else logger.debug
        log(
            "MiniMax H3 packed sequence: task=%s pad_seq_len=%s used=%d seq_len=%d",
            task,
            pad_seq_len,
            int(packed["cu_seqlens"][1]),
            int(packed["seq_len"]),
        )

        tags = packed["token_tags"].clone()
        tags[packed["text_pos"]] = text_tags.cpu()
        branch = MiniMaxH3DenoiseBranch(
            packed=packed,
            text_embeddings=text_embeddings,
            token_tags=tags,
            device=self.device,
        )

        if control_rows is not None:
            branch.static_kwargs.update(
                control_rows=control_rows,
                control_context_scale=control_context_scale,
            )

        visual_anchor = visual_condition
        if visual_anchor is not None:
            condition_shapes = visual_condition_shapes
            if condition_shapes is None and visual_condition_shape is not None:
                condition_shapes = [visual_condition_shape]
            if not condition_shapes:
                raise ValueError("visual condition shape is missing")
            visual_anchor = minimax_h3_imgvid_cond_noise_aug_rows(
                visual_anchor,
                condition_shapes=condition_shapes,
                target_latent_t=latent_t,
                imgvid_cond_num_frames=len(condition_shapes),
                seed=seed,
                noise_aug=MINIMAX_H3_IMGVID_COND_TIMESTEP,
                precomputed_noise_rows=precomputed_visual_condition_noise,
                guided=bool(guide_blocks),
            )
            full_video = torch.zeros(
                branch.img_pos.shape[0],
                96,
                dtype=torch.float32,
            )
            full_video[branch.update_mask] = initial_video
            initial_video = full_video

        if locked_audio_rows is not None:
            expected = (2 * audio_t, 32)
            if tuple(locked_audio_rows.shape) != expected:
                raise OmniClientError(f"MiniMax H3 driving audio rows must have shape {expected}")
            branch.locked_audio_rows = locked_audio_rows.to(device=self.device, dtype=torch.float32)
            initial_audio = branch.locked_audio_rows.cpu().clone()

        audio_anchor = audio_condition
        if audio_anchor is not None:
            condition_audio_t = audio_condition_lengths
            if condition_audio_t is None and ref_audio_t is not None:
                condition_audio_t = [ref_audio_t]
            if not condition_audio_t:
                raise ValueError("reference audio length is missing")
            audio_anchor = minimax_h3_audio_cond_noise_aug_rows(
                audio_anchor,
                condition_audio_t=condition_audio_t,
                seed=seed,
                noise_aug=MINIMAX_H3_AUDIO_REF_COND_TIMESTEP,
                guided=bool(guide_blocks),
            )
            full_audio = torch.zeros(
                branch.audio_pos.shape[0],
                32,
                dtype=torch.float32,
            )
            full_audio[branch.audio_update_mask] = initial_audio
            initial_audio = full_audio

        video_edit = None
        video_edit_values = (video_edit_clean_rows, video_edit_mask_rows, video_edit_restore_mask_rows)
        if any(value is None for value in video_edit_values) and any(value is not None for value in video_edit_values):
            raise ValueError("video edit clean, model-mask, and restore-mask rows must be provided together")
        if (
            video_edit_clean_rows is not None
            and video_edit_mask_rows is not None
            and video_edit_restore_mask_rows is not None
        ):
            target_noise = initial_video[branch.update_mask].to(device=self.device, dtype=torch.float32)
            clean = video_edit_clean_rows.to(device=self.device, dtype=torch.float32)
            video_edit = MiniMaxH3LatentEdit.from_rows(
                clean,
                MINIMAX_H3_IMGVID_COND_TIMESTEP * clean + (1.0 - MINIMAX_H3_IMGVID_COND_TIMESTEP) * target_noise,
                video_edit_mask_rows,
                video_edit_restore_mask_rows,
            )

        audio_edit = None
        audio_edit_values = (audio_edit_clean_rows, audio_edit_mask_rows, audio_edit_restore_mask_rows)
        if any(value is None for value in audio_edit_values) and any(value is not None for value in audio_edit_values):
            raise ValueError("audio edit clean, model-mask, and restore-mask rows must be provided together")
        if (
            audio_edit_clean_rows is not None
            and audio_edit_mask_rows is not None
            and audio_edit_restore_mask_rows is not None
        ):
            clean = audio_edit_clean_rows.to(device=self.device, dtype=torch.float32)
            audio_edit = MiniMaxH3LatentEdit.from_rows(
                clean,
                clean,
                audio_edit_mask_rows,
                audio_edit_restore_mask_rows,
            )

        if isinstance(self._fasth3_checkpoint, FastH3OmniCheckpointSpec):
            from .pdd import pdd_sigmas

            video_sigmas, audio_sigmas = pdd_sigmas(video_shift), pdd_sigmas(audio_shift)
            # Only target rows are sampled from sigma_0 * N(0, I).
            initial_video[branch.update_mask] *= video_sigmas[0]
            initial_audio[branch.audio_update_mask] *= audio_sigmas[0]
        return {
            "branch": branch,
            # The request-mode loop moves these onto the device itself; step mode
            # keeps them resident across steps, so normalize once for both.
            "video_rows": initial_video.to(device=self.device, dtype=torch.float32),
            "audio_rows": initial_audio.to(device=self.device, dtype=torch.float32),
            "cond_anchor": (
                None if visual_anchor is None else visual_anchor.to(device=self.device, dtype=torch.float32)
            ),
            "audio_anchor": (
                None if audio_anchor is None else audio_anchor.to(device=self.device, dtype=torch.float32)
            ),
            "sampler": sampler,
            "sigmas_video": video_sigmas,
            "sigmas_audio": audio_sigmas,
            "video_edit": video_edit,
            "audio_edit": audio_edit,
        }

    def _unpack_denoised_rows(
        self,
        branch: MiniMaxH3DenoiseBranch,
        video_rows: torch.Tensor,
        audio_rows: torch.Tensor,
        *,
        latent_t: int,
        latent_h: int,
        latent_w: int,
        audio_t: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Select the target rows and unpack them back into VAE latents."""
        target_video = video_rows[branch.update_mask_dev]
        video_latent = minimax_h3_unpatchify_video_tokens(
            target_video,
            latent_shape=(
                latent_t,
                latent_h // 2,
                latent_w // 2,
                24,
            ),
            patch_size=(1, 2, 2),
        )
        target_audio = audio_rows[branch.audio_update_mask_dev]
        audio_latent = minimax_h3_unpack_audio_tokens(
            target_audio,
            audio_t=audio_t * 2,
            audio_channel=2,
        )
        return video_latent, audio_latent

    def diffuse(
        self,
        *,
        task: str,
        text_embeddings: torch.Tensor,
        text_tags: torch.Tensor,
        seed: int,
        latent_t: int,
        latent_h: int,
        latent_w: int,
        audio_t: int,
        num_frames: int,
        num_steps: int,
        video_shift: float,
        audio_shift: float,
        base_schedule: Sequence[float] | None,
        visual_condition: torch.Tensor | None,
        visual_condition_shape: tuple[int, int, int] | None,
        audio_condition: torch.Tensor | None,
        ref_audio_t: int | None,
        ref_blocks: list[dict[str, Any]] | None = None,
        visual_condition_shapes: list[tuple[int, int, int]] | None = None,
        audio_condition_lengths: list[int] | None = None,
        keyframe_frame_indices: list[int] | None = None,
        control_rows: torch.Tensor | None = None,
        control_context_scale: float = 1.0,
        guide_blocks: list[dict[str, Any]] | None = None,
        pad_seq_len: int | None = None,
        locked_audio_rows: torch.Tensor | None = None,
        temporal_offset: float = 0.0,
        media_time_origin: int | None = None,
        video_edit_clean_rows: torch.Tensor | None = None,
        video_edit_mask_rows: torch.Tensor | None = None,
        video_edit_restore_mask_rows: torch.Tensor | None = None,
        audio_edit_clean_rows: torch.Tensor | None = None,
        audio_edit_mask_rows: torch.Tensor | None = None,
        audio_edit_restore_mask_rows: torch.Tensor | None = None,
        sampler: str = "euler",
        init_latents: tuple[torch.Tensor, torch.Tensor] | None = None,
        refine: MiniMaxH3LatentRefineSpec | None = None,
        request_context: dict[str, Any] | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        # Consume request-owned noise here so caller keyword dictionaries cannot
        # keep the host buffers alive throughout denoising.
        inputs = self._build_denoise_inputs(
            sampler=sampler,
            task=task,
            text_embeddings=text_embeddings,
            text_tags=text_tags,
            seed=seed,
            latent_t=latent_t,
            latent_h=latent_h,
            latent_w=latent_w,
            audio_t=audio_t,
            num_frames=num_frames,
            num_steps=num_steps,
            video_shift=video_shift,
            audio_shift=audio_shift,
            base_schedule=base_schedule,
            visual_condition=visual_condition,
            visual_condition_shape=visual_condition_shape,
            audio_condition=audio_condition,
            ref_audio_t=ref_audio_t,
            ref_blocks=ref_blocks,
            visual_condition_shapes=visual_condition_shapes,
            audio_condition_lengths=audio_condition_lengths,
            keyframe_frame_indices=keyframe_frame_indices,
            control_rows=control_rows,
            control_context_scale=control_context_scale,
            guide_blocks=guide_blocks,
            pad_seq_len=pad_seq_len,
            locked_audio_rows=locked_audio_rows,
            temporal_offset=temporal_offset,
            media_time_origin=media_time_origin,
            video_edit_clean_rows=video_edit_clean_rows,
            video_edit_mask_rows=video_edit_mask_rows,
            video_edit_restore_mask_rows=video_edit_restore_mask_rows,
            audio_edit_clean_rows=audio_edit_clean_rows,
            audio_edit_mask_rows=audio_edit_mask_rows,
            audio_edit_restore_mask_rows=audio_edit_restore_mask_rows,
            init_latents=init_latents,
            refine=refine,
            precomputed_initial_noise=(
                None if request_context is None else request_context.pop("precomputed_initial_noise", None)
            ),
            precomputed_visual_condition_noise=(
                None if request_context is None else request_context.pop("precomputed_visual_condition_noise", None)
            ),
        )
        branch = inputs["branch"]
        transformer = self._transformer_for_task(task)
        # Each pass (including each output and hi-res refine) owns its cache.
        # Refine can change both the packed shape and the schedule length.
        registry = getattr(transformer, "_hook_registry", None)
        if registry is not None:
            registry.reset_hook(TeaCacheHook._HOOK_NAME)
        cache_runtime = getattr(self, "_cache_dit_runtime", None)
        if cache_runtime is not None:
            cache_runtime.refresh(len(inputs["sigmas_video"]) - 1)
        with self._resident_dit_layers_on_device(enabled=transformer is self.transformer):
            with self.progress_bar(total=len(inputs["sigmas_video"]) - 1) as progress:
                video_rows, audio_rows = minimax_h3_denoise_loop(
                    sampler=inputs["sampler"],
                    model=transformer,
                    positive=branch,
                    initial_video_rows=inputs["video_rows"],
                    initial_audio_rows=inputs["audio_rows"],
                    keyframe_cond_rows=inputs["cond_anchor"],
                    audio_ref_rows=inputs["audio_anchor"],
                    sigmas_video=inputs["sigmas_video"],
                    sigmas_audio=inputs["sigmas_audio"],
                    device=self.device,
                    imgvid_cond_noise_aug_for_inference=(MINIMAX_H3_IMGVID_COND_TIMESTEP),
                    audio_cond_noise_aug_for_inference=(MINIMAX_H3_AUDIO_REF_COND_TIMESTEP),
                    video_edit=inputs["video_edit"],
                    audio_edit=inputs["audio_edit"],
                    on_step=lambda step, video, audio: progress.update(),
                )

        return self._unpack_denoised_rows(
            branch,
            video_rows,
            audio_rows,
            latent_t=latent_t,
            latent_h=latent_h,
            latent_w=latent_w,
            audio_t=audio_t,
        )

    def decode_to_mp4(
        self,
        video_latent: torch.Tensor,
        audio_latent: torch.Tensor,
        *,
        height: int,
        width: int,
        max_pending: int = 2,
        batch_frames: int = 17,
        video_codec_options: dict[str, str] | None = None,
        frame_counts: list[int] | None = None,
        trim: Mapping[str, Any] | None = None,
    ) -> bytes:
        """Decode and encode one output on the worker without full-video materialization.

        Audio is decoded first so the incremental mux session can attach its
        audio stream before temporal video chunks arrive. Everything after a
        chunk is committed -- crop, quantization, transfer, encoding -- is the
        shared consumer's job; this method only supplies what is specific to
        H3: the audio waveform, the requested-size crop, and the fixed rate.

        Every rank of a distributed VAE group drives the temporal collectives,
        but only the output owner receives chunks, so a peer rank returns empty
        bytes -- the pre-encoded counterpart of the empty tensor the full
        decode leaves there.
        """
        from vllm_omni.diffusion.utils.chunked_video import (
            ChunkedVideoMP4Session,
        )
        from vllm_omni.diffusion.utils.chunked_video import (
            decode_to_mp4 as decode_chunks_to_mp4,
        )

        session = None
        try:
            with self._component_on_device(self.audio_vae):
                audio = self.audio_vae.decode_latent(audio_latent)
                audio_np = audio.detach().float().cpu().numpy()
                if audio_np.ndim == 3 and audio_np.shape[0] == 1:
                    audio_np = audio_np[0]
                if trim is not None:
                    # A continuation's hidden overlap is decoded for causal context, never encoded.
                    audio_np = audio_np[..., round(audio_np.shape[-1] * trim["audio_fraction"]) :]
                session = ChunkedVideoMP4Session(
                    value_range=self.video_vae.chunk_value_range,
                    fps=MINIMAX_H3_FPS,
                    audio_waveforms=[audio_np],
                    audio_sample_rate=MINIMAX_H3_AUDIO_SAMPLE_RATE,
                    batch_frames=batch_frames,
                    max_pending=max_pending,
                    video_codec_options=video_codec_options,
                    crop=(height, width),
                    skip_frames=0 if trim is None else int(trim["frames"]),
                )
                start_error: BaseException | None = None
                if self.video_vae.owns_chunk_output:
                    try:
                        session.start(width=width, height=height, batch_size=1)
                    except BaseException as exc:
                        start_error = exc
                if self.video_vae.is_distributed_enabled():
                    # Prestart runs only on the output owner, outside the chunk
                    # callback's error guard. Agree before any rank enters the
                    # VAE collectives, including when the owner is not global 0.
                    group = self.video_vae._native_parallel_state()["sp_process_group"]
                    # The current VAE SP group supports tensors on video_latent.device,
                    # matching the callback-failure broadcast in chunked_decode.
                    failed = torch.tensor([int(start_error is not None)], dtype=torch.int32, device=video_latent.device)
                    dist.broadcast(failed, src=dist.get_global_rank(group, 0), group=group)
                    if int(failed.item()) and start_error is None:
                        raise RuntimeError("MiniMax-H3 MP4 encoder startup failed on the output owner")
                if start_error is not None:
                    raise start_error

            with self._component_on_device(self.video_vae.decoder_component):
                with current_omni_platform.create_autocast_context(
                    device_type=self.device.type,
                    dtype=self.video_vae.decode_dtype,
                    enabled=True,
                ):
                    videos = decode_chunks_to_mp4(
                        self.video_vae, video_latent, session=session, frame_counts=frame_counts
                    )
        except BaseException:
            if session is not None:
                session.abort()
            raise
        if not videos:
            return b""
        if len(videos) != 1:
            raise ValueError("MiniMax H3 chunked MP4 encoding currently expects one output per decoder")
        return videos[0]

    def _release_stage_cache(self) -> None:
        """Return idle allocator pages to the device at stage boundaries.

        The bounded component cache releases only past its idle-cache bound
        (>25% of device capacity), which on large devices lets a finished
        stage's freed activations -- the DiT's denoise buffers, an encode
        input, a decoded frame tensor -- stay physically mapped across the
        next stage's peak. Forcing the release at a boundary is exact (only
        free pages are returned; live tensors are untouched) and costs one
        remap per later allocation.
        """
        cache = getattr(self, "_dlo_component_cache", None)
        if cache is not None:
            try:
                cache.release_if_needed(force=True)
            except BaseException:
                logger.exception("Failed to release retained allocator cache at stage boundary")
            return
        current_omni_platform.empty_cache()

    def decode(
        self,
        video_latent: torch.Tensor,
        audio_latent: torch.Tensor,
        *,
        height: int,
        width: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        # Denoise just ended: its freed activation pages must not stay mapped
        # through the VAE decode peak. Decoding needs only the ViT decoder
        # half of the VAE, so the CNN encoder stays off the device.
        self._release_stage_cache()
        with self._component_on_device(self.video_vae.decoder_component):
            with current_omni_platform.create_autocast_context(
                device_type=self.device.type,
                dtype=self.video_vae.decode_dtype,
                enabled=True,
            ):
                video = self.video_vae.decode_latent(video_latent)
        video = video[..., :height, :width].contiguous()
        with self._component_on_device(self.audio_vae):
            audio = self.audio_vae.decode_latent(audio_latent)
        audio = self._offload_model_cpu_stage_output(audio)
        return video, audio

    def _resolve_latent_upscale(
        self,
        extra: Mapping[str, Any],
        *,
        latent_h: int,
        latent_w: int,
    ) -> MiniMaxH3LatentUpscaleTarget | None:
        """Resolve the requested latent super-resolution target, if any.

        A request opts in with ``extra_args['latent_upscale']``; a deployment
        can set the same value under ``--additional-config`` to upscale every
        request, which a request then overrides (``false`` opts back out).
        Resolving here means an unserviceable size is rejected before the
        denoise loop rather than after it.
        """
        additional = getattr(getattr(self, "od_config", None), "additional_config", None) or {}
        raw = extra["latent_upscale"] if "latent_upscale" in extra else additional.get("latent_upscale")
        try:
            spec = parse_minimax_h3_latent_upscale_request(raw)
            if spec is None:
                return None
            if self.latent_upscaler is None:
                raise MiniMaxH3LatentUpscalerError(
                    "latent_upscale needs a checkpoint: serve with "
                    '--additional-config \'{"latent_upscaler_path": "<path>"}\''
                )
            target = resolve_minimax_h3_latent_upscale_target(
                latent_height=latent_h,
                latent_width=latent_w,
                **spec,
            )
            if self._resolve_latent_refine(extra) is not None and (target.latent_height % 2 or target.latent_width % 2):
                raise MiniMaxH3LatentUpscalerError(
                    "latent_refine requires upscale latent height and width divisible by 2 "
                    "(32 pixels); use align=32 or a compatible target size"
                )
        except MiniMaxH3LatentUpscalerError as exc:
            raise OmniClientError(str(exc)) from exc
        if (target.latent_height, target.latent_width) == (latent_h, latent_w):
            return None
        logger.info(
            "MiniMax H3 latent upscale %dx%d -> %dx%d (scale %.3f)",
            latent_w * 16,
            latent_h * 16,
            target.width,
            target.height,
            target.scale,
        )
        return target

    def _resolve_latent_refine(self, extra: Mapping[str, Any]) -> MiniMaxH3LatentRefineSpec | None:
        """Resolve the requested second denoise pass, if any.

        Read like ``latent_upscale``: ``extra_args['latent_refine']`` wins over
        an ``--additional-config`` default, and ``false`` opts back out.
        """
        additional = getattr(getattr(self, "od_config", None), "additional_config", None) or {}
        raw = extra["latent_refine"] if "latent_refine" in extra else additional.get("latent_refine")
        try:
            return parse_minimax_h3_latent_refine_request(raw)
        except MiniMaxH3LatentUpscalerError as exc:
            raise OmniClientError(str(exc)) from exc

    def _validate_refine_token_budget(
        self,
        *,
        task: str,
        target: MiniMaxH3LatentUpscaleTarget | None,
        latent_t: int,
        latent_h: int,
        latent_w: int,
        audio_t: int,
        text_len: int,
        keyframe_count: int,
        ref_blocks: list[dict[str, Any]] | None,
    ) -> None:
        """Reject refine layouts known to exceed the tested per-rank limit.

        Count the same rows as the packed layout without materializing its
        large position tensors before the first denoise pass.
        """
        additional = getattr(getattr(self, "od_config", None), "additional_config", None) or {}
        limit = additional.get("latent_refine_max_tokens_per_rank", 65_536)
        if type(limit) is not int or limit < 0:
            raise OmniClientError("latent_refine_max_tokens_per_rank must be a non-negative integer")
        if limit == 0:
            return
        height = target.latent_height if target is not None else latent_h
        width = target.latent_width if target is not None else latent_w
        frame_rows = (height // 2) * (width // 2)
        used = text_len + 2 * audio_t + latent_t * frame_rows
        if task == "fl2va":
            used += keyframe_count * frame_rows
        elif task == "ref2va":
            for block in ref_blocks or ():
                kind = block["kind"]
                if kind == "image":
                    used += (block["latent_h"] // 2) * (block["latent_w"] // 2)
                elif kind == "audio":
                    used += 2 * block["ref_audio_t"]
                else:
                    used += 2 * block["ref_audio_t"]
                    used += block["latent_t"] * (block["latent_h"] // 2) * (block["latent_w"] // 2)
        padded = ((used + MINIMAX_H3_SEQ_ALIGN - 1) // MINIMAX_H3_SEQ_ALIGN) * MINIMAX_H3_SEQ_ALIGN
        parallel = getattr(self, "parallel_config", None)
        degree = int(getattr(parallel, "ulysses_degree", 1))
        per_rank = (padded + degree - 1) // degree
        if per_rank > limit:
            raise OmniClientError(
                f"MiniMax H3 latent_refine needs about {per_rank:,} packed tokens per Ulysses rank "
                f"(limit {limit:,}); reduce the target size or duration, increase --usp, "
                "or adjust latent_refine_max_tokens_per_rank for a validated deployment"
            )

    def _refine_keyframe_condition(
        self,
        context: dict[str, Any],
    ) -> tuple[torch.Tensor | None, list[tuple[int, int, int]]]:
        """Encode the FL2VA keyframes at the refine size, once per request.

        The encode broadcasts across the DiT group, so every rank has to reach
        it the same number of times; caching on the request context keeps that
        true while sparing the repeat for each additional output.
        """
        cached = context.get(_REFINE_KEYFRAME_CONDITION)
        if cached is None:
            target = context["latent_upscale"]
            cached = self._encode_visual_conditions(
                [
                    image.resize((target.width, target.height), Image.Resampling.LANCZOS)
                    for image in context["keyframe_images"]
                ],
                None,
                video_count=0,
            )
            context[_REFINE_KEYFRAME_CONDITION] = cached
        return cached

    def _refined_latents(
        self,
        video_latent: torch.Tensor,
        audio_latent: torch.Tensor,
        *,
        context: dict[str, Any],
        seed: int,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Re-denoise finished latents at their current size.

        This is the second half of the hi-res route: the first pass generates
        at a cheap size, the upscaler moves the latent, and this pass resumes
        the schedule at the target size to put back the detail the upscaler can
        only approximate. Without an upscale it is an ordinary detail pass.
        """
        refine = context["latent_refine"]
        target = context["latent_upscale"]
        kwargs = dict(self._denoise_kwargs(context))
        kwargs["seed"] = seed
        if target is not None:
            kwargs["latent_h"] = target.latent_height
            kwargs["latent_w"] = target.latent_width
            # A pinned pad_seq_len sizes the first pass's layout. This pass packs
            # several times as many video rows, so carrying the pin over would
            # fail the seq_len >= used check with an error that names neither
            # the refine pass nor the size that outgrew it.
            kwargs["pad_seq_len"] = None
            if context["task"] == "fl2va":
                condition, shapes = self._refine_keyframe_condition(context)
                kwargs["visual_condition"] = condition
                kwargs["visual_condition_shapes"] = shapes
                kwargs["visual_condition_shape"] = shapes[0] if len(shapes) == 1 else None
        return self.diffuse(**kwargs, init_latents=(video_latent, audio_latent), refine=refine)

    def _upscaled_latent(
        self,
        video_latent: torch.Tensor,
        target: MiniMaxH3LatentUpscaleTarget | None,
    ) -> torch.Tensor:
        if target is None:
            return video_latent
        with self._component_on_device(self.latent_upscaler):
            return self.latent_upscaler.upscale(video_latent, target)

    @staticmethod
    def _extract_prompt(raw_prompt: Any) -> tuple[str, dict[str, Any]]:
        """Split a request prompt into its text and multimodal parts."""
        if isinstance(raw_prompt, str):
            prompt = raw_prompt
            multi_modal_data: dict[str, Any] = {}
        else:
            prompt = str(raw_prompt.get("prompt") or "")
            multi_modal_data = raw_prompt.get("multi_modal_data") or {}
        if not prompt:
            raise OmniClientError("MiniMax H3 requires a non-empty prompt")
        return prompt, multi_modal_data

    @staticmethod
    def _extract_text_conditioning(raw_prompt: Any) -> MiniMaxH3TextConditioning | None:
        if isinstance(raw_prompt, str):
            return None
        additional_information = raw_prompt.get("additional_information") or {}
        encoder_output = additional_information.get("encoder_output")
        if encoder_output is None:
            # Preserve main's text-only handoff for deployments that still
            # encode media locally; a supplied unified payload takes priority.
            encoder_output = additional_information.get("text_encoder_output")
        if encoder_output is None:
            return None
        if not isinstance(encoder_output, Mapping):
            raise OmniClientError("MiniMax H3 encoder output must be a mapping")
        try:
            if "hidden_states" in encoder_output and "token_tags" in encoder_output:
                return MiniMaxH3TextConditioning.from_payload(encoder_output)
            conditioning = MiniMaxH3EncoderConditioning.from_omni_payload(encoder_output)
            return MiniMaxH3TextConditioning(conditioning.hidden_states, conditioning.token_tags)
        except ValueError as exc:
            raise OmniClientError(str(exc)) from exc

    @staticmethod
    def _extract_prepared_reference_videos(raw_prompt: Any) -> list[dict[str, Any]] | None:
        if isinstance(raw_prompt, str):
            return None
        additional_information = raw_prompt.get("additional_information") or {}
        meta = additional_information.get("meta") or {}
        descriptor = meta.get(MINIMAX_H3_PREPARED_REFERENCE_VIDEOS_KEY)
        if descriptor is None:
            return None
        if not isinstance(descriptor, str):
            raise OmniClientError("MiniMax H3 prepared-reference-video descriptor must be a string")
        try:
            _, videos = deserialize_prepared_reference_videos(descriptor)
        except ValueError as exc:
            raise OmniClientError(str(exc)) from exc
        return videos

    def encode_prompt(self, prepared: PreparedEncoderInputs | None) -> tuple[torch.Tensor, torch.Tensor]:
        _, rank, _ = _dit_rank_world()
        ids = tags = hidden = None
        vision_kwargs: dict[str, torch.Tensor] = {}
        error = None
        if rank == 0:
            try:
                if prepared is None:
                    raise ValueError("rank 0 must prepare MiniMax H3 text inputs")
                if prepared.images:
                    vision = self.processor.image_processor(images=prepared.images, return_tensors="pt")
                    vision_kwargs.update(
                        pixel_values=vision["pixel_values"],
                        image_grid_thw=vision["image_grid_thw"],
                    )
                if prepared.qwen_videos:
                    vision = self.processor.video_processor(
                        videos=[frames for frames, _ in prepared.qwen_videos],
                        do_sample_frames=False,
                        return_tensors="pt",
                    )
                    vision_kwargs.update(
                        pixel_values_videos=vision["pixel_values_videos"],
                        video_grid_thw=vision["video_grid_thw"],
                    )
                ids, tags = build_minimax_h3_presentation(
                    self.tokenizer,
                    prompt=prepared.prompt,
                    task=prepared.media.task,
                    condition_labels=prepared.condition_labels,
                    image_grid_thw=vision_kwargs.get("image_grid_thw"),
                    video_grid_thw=vision_kwargs.get("video_grid_thw"),
                    video_timestamps=prepared.video_timestamps,
                    merge_size=int(self.processor.image_processor.merge_size),
                )
            except Exception as exc:
                error = exc
        _broadcast_rank0_exception(error)
        if rank < self.text_encoder_tp_size:
            ids = self._distribute_encode_inputs(ids, vision_kwargs)
            hidden = self._encode_text_hidden(ids, vision_kwargs)
        return (
            _broadcast_tensor(hidden, dtype=torch.bfloat16, device=self.device),
            _broadcast_tensor(tags, dtype=torch.long, device=self.device),
        )

    def _distribute_media_inputs(self, media: MiniMaxH3EncoderMediaInput | None) -> MiniMaxH3EncoderMediaInput:
        group, rank, world_size = _dit_rank_world()
        if world_size == 1:
            assert media is not None
            return media
        tensors = media.to_mm_tensors() if media is not None else []
        header = [(media.to_metadata(), [value.dtype for value in tensors])] if media is not None else [None]
        dist.broadcast_object_list(header, src=0, group=group)
        metadata, dtypes = header[0]
        received = []
        for index, dtype in enumerate(dtypes):
            value = _broadcast_tensor(tensors[index] if rank == 0 else None, dtype=dtype, device=self.device)
            if rank != 0:
                received.append(value.cpu())
            del value
        if rank == 0:
            assert media is not None
            return media
        return MiniMaxH3EncoderMediaInput.from_mm_tensors(received, metadata)

    def _broadcast_media_conditioning(
        self, conditioning: MiniMaxH3EncoderMediaConditioning | None
    ) -> MiniMaxH3EncoderMediaConditioning:
        group, rank, world_size = _dit_rank_world()
        if world_size == 1:
            assert conditioning is not None
            return conditioning
        tensor_names = (
            "visual_condition",
            "audio_condition",
            "video_edit_clean_rows",
            "video_edit_mask",
            "audio_edit_clean_rows",
            "audio_edit_mask",
            "guide_visual_condition",
            "guide_audio_condition",
        )
        header = [None]
        if rank == 0:
            assert conditioning is not None
            metadata = {
                item.name: getattr(conditioning, item.name)
                for item in fields(conditioning)
                if item.name not in tensor_names
            }
            dtypes = {
                name: value.dtype if (value := getattr(conditioning, name)) is not None else None
                for name in tensor_names
            }
            header[0] = (metadata, dtypes)
        dist.broadcast_object_list(header, src=0, group=group)
        metadata, dtypes = header[0]
        tensors = {}
        for name, dtype in dtypes.items():
            source = getattr(conditioning, name) if rank == 0 else None
            tensors[name] = _broadcast_tensor(source, dtype=dtype, device=self.device) if dtype is not None else None
        return MiniMaxH3EncoderMediaConditioning(**metadata, **tensors)

    def _encode_local_media(self, media: MiniMaxH3EncoderMediaInput | None) -> MiniMaxH3EncoderMediaConditioning:
        group, rank, world_size = _dit_rank_world()
        distributed_video = self.video_vae.is_distributed_enabled()
        if distributed_video:
            media = self._distribute_media_inputs(media)
        conditioning = None
        error = None
        try:
            if rank == 0 or distributed_video:
                assert media is not None
                conditioning = encode_media(
                    media,
                    video_vae=self.video_vae,
                    audio_vae=self.audio_vae,
                    emit_conditioning=rank == 0,
                    component_scope=self._component_on_device,
                )
        except ValueError as exc:
            error = OmniClientError(str(exc))
        except Exception as exc:
            error = exc
        if world_size > 1:
            # All participants finish the codec phase before any latent broadcast.
            errors = [None] * world_size
            info = (str(error), isinstance(error, OmniClientError)) if error is not None else None
            dist.all_gather_object(errors, info, group=group)
            for info in errors:
                if info is not None:
                    if error is not None:
                        raise error
                    message, is_client_error = info
                    raise OmniClientError(message) if is_client_error else RuntimeError(message)
        elif error is not None:
            raise error
        return self._broadcast_media_conditioning(conditioning)

    def _predict_visual_condition_shapes(
        self,
        media: MiniMaxH3EncoderMediaInput,
    ) -> tuple[tuple[int, int, int], ...]:
        shapes = [(1, int(image.shape[0]) // 16, int(image.shape[1]) // 16) for image in media.images]
        for video in media.videos:
            frames = np.asarray(video.detach().cpu().to(torch.uint8).contiguous().numpy())
            shapes.append(self.video_vae.predict_video_latent_shape(frames))
        return tuple(shapes)

    def _prepare_local_conditioning(
        self,
        raw_prompt: Any,
        sampling: Any,
        *,
        require_external_text: bool = False,
        request_context: dict[str, Any] | None = None,
    ) -> tuple[MiniMaxH3EncoderConditioning, list[tuple[torch.Tensor, torch.Tensor]] | None]:
        """Prepare media once and encode either shared text or each window's text.

        Returns initial conditioning and optional request-owned window embeddings.
        Invalid continuation prompts are broadcast before any encoder collective.
        """
        group, rank, world_size = _dit_rank_world()
        prompts = (sampling.extra_args or {}).get("continuation_prompts")
        prepared = text_conditioning = None
        initial_noise_params = None
        visual_noise_params = None
        error = None
        if rank == 0:
            try:
                _, multi_modal_data = self._extract_prompt(raw_prompt)
                if multi_modal_data.get(MINIMAX_H3_TIMELINE_GUIDES_KEY) is not None and not self.load_vae_encoder:
                    raise OmniClientError("MiniMax H3 timeline guides require a VAE encoder in the diffusion stage")
                turbo_spec = self._active_turbo_spec(sampling)
                has_native_lora = self._has_active_native_lora(sampling)
                task = self._resolve_task(
                    (sampling.extra_args or {}).get("task"),
                    multi_modal_data,
                    audio_mode=(sampling.extra_args or {}).get("audio_mode", "native"),
                    turbo_spec=turbo_spec,
                    has_native_lora=has_native_lora,
                )
                if turbo_spec is not None:
                    self._validate_turbo_sampling(sampling, turbo_spec)
                if has_native_lora:
                    self._validate_native_sampling(sampling, task=task)
                if self._fasth3 is not None:
                    self._fasth3.check_request(
                        sampling,
                        video_shift=self.default_video_shift,
                        audio_shift=self.default_audio_shift,
                    )
                if self._vdn is not None:
                    self._vdn.check_request(sampling, task)
                text_conditioning = self._extract_text_conditioning(raw_prompt)
                if require_external_text and text_conditioning is None:
                    raise OmniClientError(
                        "MiniMax H3 diffusion stage requires text encoder conditioning when text_encoder is not loaded"
                    )
                prepared = prepare_encoder_inputs(
                    raw_prompt,
                    sampling,
                    task=task,
                    prepared_reference_videos=self._extract_prepared_reference_videos(raw_prompt),
                )
                continuation = None
                if prompts is not None or (request_context is not None and task == "ref2va"):
                    continuation = resolve_continuation(
                        sampling.extra_args or {},
                        task=task,
                        step_execution=bool(getattr(self.od_config, "step_execution", False)),
                    )
                if prompts is not None:
                    if continuation is None or not self.load_text_encoder:
                        raise OmniClientError(
                            "continuation_prompts requires continuation mode with a local text encoder"
                        )
                    window, overlap = continuation
                    count = len(plan_continuation_windows(prepared.media.num_frames, window, overlap))
                    if (
                        not isinstance(prompts, list)
                        or len(prompts) != count
                        or any(not isinstance(prompt, str) or not prompt.strip() for prompt in prompts)
                    ):
                        raise OmniClientError(f"continuation_prompts must contain exactly {count} non-empty strings")
                    prepared = replace(prepared, prompt=prompts[0])
                    # External text belongs to the main prompt, not the first window.
                    text_conditioning = None
                if (
                    request_context is not None
                    and task == "ref2va"
                    and continuation is None
                    and resolve_continuation_request(sampling.extra_args or {}) is None
                ):
                    initial_noise_params = {
                        "seed": int(sampling.seed if sampling.seed is not None else 42),
                        "latent_t": prepared.media.latent_t,
                        "latent_h": prepared.media.height // 16,
                        "latent_w": prepared.media.width // 16,
                        "audio_t": prepared.media.audio_t,
                    }
                    # Guided requests draw per-condition noise over the merged
                    # guide + reference rows, so only the target noise is reused.
                    condition_shapes = (
                        self._predict_visual_condition_shapes(prepared.media)
                        if not prepared.media.timeline_guides
                        else ()
                    )
                    if condition_shapes:
                        visual_noise_params = {
                            "condition_shapes": condition_shapes,
                            "target_latent_t": prepared.media.latent_t,
                            "imgvid_cond_num_frames": len(condition_shapes),
                            "seed": initial_noise_params["seed"],
                        }
            except Exception as exc:
                error = exc
        _broadcast_rank0_exception(error)
        header = [(text_conditioning is not None, initial_noise_params, visual_noise_params)]
        if world_size > 1:
            dist.broadcast_object_list(header, src=0, group=group)
        reuse_text, initial_noise_params, visual_noise_params = header[0]
        executor = (
            ThreadPoolExecutor(max_workers=1, thread_name_prefix="minimax_h3_initial_noise")
            if initial_noise_params is not None
            else None
        )
        # Independent CPU generators preserve sampling; join the worker on request exit.
        try:
            initial_noise = (
                executor.submit(self._initial_noise, **initial_noise_params)
                if initial_noise_params is not None
                else None
            )
            visual_noise = (
                executor.submit(minimax_h3_imgvid_cond_noise_rows, **visual_noise_params)
                if visual_noise_params is not None
                else None
            )
            if reuse_text:
                hidden = _broadcast_tensor(
                    text_conditioning.hidden_states if rank == 0 else None,
                    dtype=torch.bfloat16,
                    device=self.device,
                )
                tags = _broadcast_tensor(
                    text_conditioning.token_tags if rank == 0 else None, dtype=torch.long, device=self.device
                )
            else:
                hidden, tags = self.encode_prompt(prepared)
            window_text = None
            if prompts is not None:
                window_text = [(hidden, tags)]
                for index, prompt in enumerate(prompts[1:], start=2):
                    logger.info("MiniMax H3 encoding continuation prompt %d/%d", index, len(prompts))
                    window_text.append(self.encode_prompt(replace(prepared, prompt=prompt) if rank == 0 else None))
            media = self._encode_local_media(prepared.media if prepared is not None else None)
            if initial_noise is not None:
                assert request_context is not None
                request_context["precomputed_initial_noise"] = initial_noise.result()
            if visual_noise is not None:
                assert request_context is not None
                assert visual_noise_params is not None
                predicted_shapes = visual_noise_params["condition_shapes"]
                actual_shapes = tuple(media.visual_condition_shapes)
                if predicted_shapes != actual_shapes:
                    raise RuntimeError(
                        "MiniMax H3 predicted visual condition shapes do not match encoded shapes: "
                        f"predicted {predicted_shapes}, encoded {actual_shapes}"
                    )
                request_context["precomputed_visual_condition_noise"] = visual_noise.result()
            return MiniMaxH3EncoderConditioning.from_components(
                MiniMaxH3TextConditioning(hidden, tags), media
            ), window_text
        finally:
            if executor is not None:
                executor.shutdown(wait=True, cancel_futures=True)

    def _prepare_request_inputs(self, raw_prompt: Any, sampling: Any) -> dict[str, Any]:
        if (getattr(sampling, "extra_args", None) or {}).get(
            "continuation_prompts"
        ) is not None and not self.load_text_encoder:
            raise OmniClientError("continuation_prompts requires continuation mode with a local text encoder")
        window_text = None
        context: dict[str, Any] = {}
        if self.load_text_encoder or self.load_vae_encoder:
            conditioning, window_text = self._prepare_local_conditioning(
                raw_prompt,
                sampling,
                require_external_text=not self.load_text_encoder,
                request_context=context,
            )
        else:
            conditioning = self._extract_encoder_conditioning(raw_prompt)
        prompt_media = raw_prompt.get("multi_modal_data") if isinstance(raw_prompt, Mapping) else None
        control_media = prompt_media.get(MINIMAX_H3_CONTROL_MEDIA_KEY) if isinstance(prompt_media, Mapping) else None
        context.update(self._prepare_encoder_conditioning_inputs(conditioning, sampling, control_media=control_media))
        if (
            context.get("latent_refine") is not None
            and context.get("latent_upscale") is not None
            and context["task"] == "fl2va"
        ):
            if not self.load_vae_encoder:
                raise OmniClientError("MiniMax H3 FL2VA latent_refine with upscale requires a local VAE encoder")
            _, media = self._extract_prompt(raw_prompt)
            images = media.get("image")
            images = list(images) if isinstance(images, (list, tuple)) else [images] if images is not None else []
            context["keyframe_images"] = load_minimax_h3_images(images)
            if len(context["keyframe_images"]) != len(context["keyframe_frame_indices"] or ()):
                raise OmniClientError("MiniMax H3 latent_refine requires the original FL2VA keyframe images")
        if window_text is not None:
            context["continuation_text_conditioning"] = window_text
        return context

    @staticmethod
    def _extract_encoder_conditioning(prompt: Any) -> MiniMaxH3EncoderConditioning:
        if isinstance(prompt, list):
            prompt = prompt[0] if prompt else None
        additional_information = prompt.get("additional_information") if isinstance(prompt, Mapping) else None
        payload = additional_information.get("encoder_output") if isinstance(additional_information, Mapping) else None
        if not isinstance(payload, Mapping) or not payload:
            raise OmniClientError("MiniMax H3 diffusion stage requires encoder conditioning from the encoder stage")
        try:
            return MiniMaxH3EncoderConditioning.from_omni_payload(payload)
        except ValueError as exc:
            raise OmniClientError(str(exc)) from exc

    def _prepare_encoder_conditioning_inputs(
        self,
        conditioning: MiniMaxH3EncoderConditioning,
        sampling: Any,
        control_media: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        extra = sampling.extra_args or {}
        try:
            control = parse_control(extra, control_media)
        except ValueError as exc:
            raise OmniClientError(str(exc)) from exc
        if control is not None:
            if not getattr(self.od_config, "controlnet_model_path", None):
                raise OmniClientError("Control request requires --controlnet-model-path")
            if sampling.quality == "high" or extra.get(MINIMAX_H3_GENERIC_CACHE_KEY):
                raise OmniClientError("H3 control does not support Cache-DiT quality profiles")
        continuation = resolve_continuation(
            extra, task=conditioning.task, step_execution=bool(getattr(self.od_config, "step_execution", False))
        )
        validate_encoded_frame_limit(extra, conditioning.task, conditioning.num_frames)
        if continuation is not None and (
            conditioning.video_edit_clean_rows is not None or conditioning.audio_edit_clean_rows is not None
        ):
            raise OmniClientError(
                "MiniMax H3 continuation does not support latent-mask editing; use long_video_mode=full"
            )
        if extra.get("audio_mode") == "lock_source" and conditioning.audio_edit_clean_rows is not None:
            raise OmniClientError("MiniMax H3 audio_mode=lock_source cannot be combined with audio latent-mask editing")
        requested_task = extra.get("task")
        if requested_task is not None and str(requested_task).lower() != conditioning.task:
            raise OmniClientError(
                f"MiniMax H3 encoder task {conditioning.task!r} does not match diffusion request {requested_task!r}"
            )
        if self._regenerate is not None or extra.get("regenerate", False):
            if continuation is not None:
                raise OmniClientError("Open-H3-Regenerate does not support latent-tail continuation")
            if control is not None:
                raise OmniClientError("Open-H3-Regenerate does not take control inputs")
            return self._prepare_regenerate_inputs(conditioning, sampling)
        turbo_spec = self._active_turbo_spec(sampling)
        has_native_lora = self._has_active_native_lora(sampling)
        task = self._resolve_task(
            conditioning.task,
            turbo_spec=turbo_spec,
            has_native_lora=has_native_lora,
        )
        if control is not None and task != "t2va":
            raise OmniClientError("H3 control supports t2va only; reference/keyframe conditioning is unsupported")
        if control is not None and continuation is not None:
            raise OmniClientError(
                "MiniMax H3 control does not support long-video continuation; use long_video_mode=full"
            )
        if turbo_spec is not None:
            self._validate_turbo_sampling(sampling, turbo_spec)
        if has_native_lora:
            self._validate_native_sampling(sampling, task=task)
        if self._fasth3_checkpoint is not None:
            self._fasth3_checkpoint.check_request(
                sampling,
                step_execution=bool(getattr(self.od_config, "step_execution", False)),
            )
        if self._fasth3 is not None:
            self._fasth3.check_request(
                sampling,
                video_shift=self.default_video_shift,
                audio_shift=self.default_audio_shift,
            )
        if self._vdn is not None:
            self._vdn.check_request(sampling, task)

        if conditioning.height % 32 or conditioning.width % 32:
            raise OmniClientError(
                f"MiniMax H3 encoder canvas must be divisible by 32, got {conditioning.width}x{conditioning.height}"
            )
        expected_latent_t = MINIMAX_H3_SHAPE_PLANNER.video_latent_t(conditioning.num_frames)
        expected_audio_t = MINIMAX_H3_SHAPE_PLANNER.audio_latent_t(conditioning.num_frames / MINIMAX_H3_FPS)
        if (conditioning.latent_t, conditioning.audio_t) != (expected_latent_t, expected_audio_t):
            raise OmniClientError(
                "MiniMax H3 encoder latent shape does not match its output frame count: "
                f"got ({conditioning.latent_t}, {conditioning.audio_t}), expected "
                f"({expected_latent_t}, {expected_audio_t})"
            )

        conditioning, latent_continuation = self._resolve_latent_continuation(
            extra, conditioning, inherit_canvas=continuation_inherits_source_canvas(conditioning.task, sampling)
        )
        # A continuation samples audio on the chain's global timeline, which may
        # differ by a rounding step from the encoder's standalone length.
        audio_t = latent_continuation.audio_t if latent_continuation is not None else conditioning.audio_t
        visual_shapes = list(conditioning.visual_condition_shapes) or None
        audio_lengths = list(conditioning.audio_condition_lengths) or None
        audio_condition = conditioning.audio_condition
        locked_audio_rows = None
        if extra.get("audio_mode", "native") == "lock_source":
            if audio_condition is None or not audio_lengths:
                raise OmniClientError("MiniMax H3 lock_source requires encoded driving audio")
            drive_t = audio_lengths[-1]
            drive = audio_condition[-2 * drive_t :].reshape(2, drive_t, 32)
            # Pad/crop each stereo channel independently; flattening first would
            # shift the right channel when the source and target lengths differ.
            fitted = drive.new_zeros((2, audio_t, 32))
            # The hidden overlap keeps the audio it continues; the driving audio starts after it.
            start = 0 if latent_continuation is None else latent_continuation.overlap_audio_t
            if latent_continuation is not None:
                fitted[:, :start] = latent_continuation.prefix.audio.permute(0, 2, 1).to(fitted)
            count = min(drive_t, audio_t - start)
            fitted[:, start : start + count] = drive[:, :count]
            locked_audio_rows = fitted.reshape(-1, 32).to(device=self.device)
            audio_condition = audio_condition[: -2 * drive_t]
            audio_condition = audio_condition if audio_condition.numel() else None
            audio_lengths = audio_lengths[:-1] or None

        latent_edit: dict[str, torch.Tensor | None] = {
            "video_edit_clean_rows": None,
            "video_edit_mask_rows": None,
            "video_edit_restore_mask_rows": None,
            "audio_edit_clean_rows": None,
            "audio_edit_mask_rows": None,
            "audio_edit_restore_mask_rows": None,
        }
        try:
            if conditioning.video_edit_clean_rows is not None:
                if conditioning.video_edit_mask is None:
                    raise ValueError("MiniMax H3 video edit rows require a mask")
                video_mask = minimax_h3_video_edit_masks(
                    conditioning.video_edit_mask,
                    latent_t=conditioning.latent_t,
                    latent_h=conditioning.height // 16,
                    latent_w=conditioning.width // 16,
                )
                latent_edit.update(
                    video_edit_clean_rows=conditioning.video_edit_clean_rows,
                    video_edit_mask_rows=video_mask.model_mask_rows,
                    video_edit_restore_mask_rows=video_mask.restore_mask_rows,
                )
            if conditioning.audio_edit_clean_rows is not None:
                if conditioning.audio_edit_mask is None:
                    raise ValueError("MiniMax H3 audio edit rows require a mask")
                audio_mask = minimax_h3_audio_edit_masks(
                    _fit_audio_t(conditioning.audio_edit_mask, audio_t, fill=1.0),
                    audio_t=audio_t,
                )
                model_mask, restore_mask = _expose_padded_audio_tail(
                    min(conditioning.audio_edit_source_t, audio_t),
                    target_audio_t=audio_t,
                    mask_rows=audio_mask.model_mask_rows,
                    restore_mask_rows=audio_mask.restore_mask_rows,
                )
                clean = conditioning.audio_edit_clean_rows.reshape(2, -1, 32)
                latent_edit.update(
                    audio_edit_clean_rows=_fit_audio_t(clean.permute(0, 2, 1), audio_t, fill=0.0)
                    .permute(0, 2, 1)
                    .reshape(-1, 32),
                    audio_edit_mask_rows=model_mask,
                    audio_edit_restore_mask_rows=restore_mask,
                )
        except ValueError as exc:
            raise OmniClientError(str(exc)) from exc

        control_rows = None
        control_scale = control["control_context_scale"] if control is not None else 1.0
        if control is not None and control_scale != 0:
            if any(block["kind"] in ("image", "video", "video_audio") for block in conditioning.guide_blocks):
                raise OmniClientError(
                    "H3 control does not support visual timeline guides; control rows cover only the target canvas"
                )
            try:
                media = {
                    role: load_control_pixels(
                        control[role],
                        height=conditioning.height,
                        width=conditioning.width,
                        num_frames=conditioning.num_frames,
                        mask=role == "mask_path",
                    )
                    if control.get(role)
                    else None
                    for role in ("control_path", "source_path", "mask_path")
                }
                with self._component_on_device(self.video_vae.encoder_component):
                    control_rows = build_control_rows(
                        media["control_path"],
                        media["source_path"],
                        media["mask_path"],
                        height=conditioning.height,
                        width=conditioning.width,
                        num_frames=conditioning.num_frames,
                        latent_shape=(
                            conditioning.latent_t,
                            conditioning.height // 16,
                            conditioning.width // 16,
                        ),
                        encode=self.video_vae.encode_control_latents,
                        device=self.device,
                    )
                self._release_stage_cache()
            except (ValueError, OSError) as exc:
                raise OmniClientError(f"Invalid H3 control media: {exc}") from exc

        self._prepare_adaln_adapter(sampling)
        base_schedule, num_steps = self._resolve_sigma_positions(task, sampling)
        sampler = normalize_h3_sampler(extra.get("sampler"))
        if sampler != "euler" and base_schedule is not None:
            raise ValueError(
                "MiniMax H3 res_multistep sampling with a fixed distilled sigma schedule has not been validated; "
                "use sampler='euler' for this schedule."
            )
        # num_steps is the length of the sequence this request denoises; FastH3 and pinned distilled
        # schedules can differ from num_inference_steps. A latent_refine pass has its own step count, which
        # this check does not cover, so a schedule together with latent_refine is rejected below. Both
        # execution modes reach this point before any denoise forward. Step mode runs it outside the forward
        # context, so the request's own schedule is resolved against the service default; in request mode
        # that is the schedule the runner bound.
        attention_schedule = require_request_attention_schedule_fits(
            sampling, getattr(self.od_config, "diffusion_attention_schedule", None), num_steps
        )
        transformer = getattr(
            self, "transformers_ref" if task == "ref2va" and hasattr(self, "transformers_ref") else "transformer", None
        )
        cache = getattr(transformer, "adaln_cache", None)
        if cache is not None and cache.sidecar is not None:
            mode = task
            if task == "ref2va":
                mode += "-mixed" if visual_shapes and audio_lengths else "-audio" if audio_lengths else "-image"
            try:
                cache.sidecar.check_request(
                    mode=mode,
                    num_steps=num_steps,
                    base_schedule=base_schedule,
                    flow_shift=float(extra.get("flow_shift", self.default_video_shift)),
                    audio_flow_shift=float(extra.get("audio_flow_shift", self.default_audio_shift)),
                )
            except ValueError as exc:
                logger.warning("Rejecting optional AdaLN sidecar for this schedule; using runtime cache: %s", exc)
                cache.clear()
        quality_plan = self._quality_policy.resolve(
            quality=sampling.quality,
            num_inference_steps=num_steps,
            extra_args=extra,
        )
        if continuation is not None and quality_plan.cache_dit is not None:
            raise OmniClientError("MiniMax H3 continuation requires uncached denoising; set quality=lossless")
        if attention_schedule and quality_plan.cache_dit is not None:
            # Cache-DiT reuses transformer outputs across steps, so a cached residual can come from a step
            # that ran a different attention profile. Reject before its hooks are installed.
            raise InvalidAttentionScheduleError(
                "attention_schedule cannot be combined with MiniMax H3 Cache-DiT (quality=high); "
                "send quality=lossless or attention_schedule=[]"
            )
        if attention_schedule and self._resolve_latent_refine(extra) is not None:
            # latent_refine runs a second denoise sequence over the tail of the sigma list. It publishes step
            # indexes from 0 and its own step count, and the schedule was checked against num_steps only. A
            # range could select a profile at another sigma position there, or fall outside the refine
            # sequence and fail in the attention layer after the first pass has run. An invalid latent_refine
            # value raises its own client error from the resolver.
            raise InvalidAttentionScheduleError(
                "attention_schedule cannot be combined with MiniMax H3 latent_refine (a latent_refine in the "
                "request, or an omitted latent_refine on a server that sets one in --additional-config): the "
                "refine pass is a second denoise sequence with its own step count; send attention_schedule=[] "
                "or latent_refine=false"
            )
        self._cache_dit_runtime.prepare(quality_plan.cache_dit)
        upscale_target = self._resolve_latent_upscale(
            extra, latent_h=conditioning.height // 16, latent_w=conditioning.width // 16
        )
        latent_refine = self._resolve_latent_refine(extra)
        if latent_refine is not None:
            if (
                control_rows is not None
                and upscale_target is not None
                and (upscale_target.height, upscale_target.width) != (conditioning.height, conditioning.width)
            ):
                raise OmniClientError(
                    "H3 control conditioning uses the first-pass canvas; latent_refine cannot change its resolution. "
                    "Disable latent_refine or keep the base canvas."
                )
            if continuation is not None:
                raise OmniClientError("MiniMax H3 latent_refine does not support latent-tail continuation")
            if latent_continuation is not None:
                # The refine pass re-denoises the whole window from the original
                # request, without the hidden prefix guide or its global offset.
                raise OmniClientError("MiniMax H3 latent_refine does not support continue_from")
            if conditioning.video_edit_clean_rows is not None or conditioning.audio_edit_clean_rows is not None:
                raise OmniClientError("MiniMax H3 latent_refine does not support latent-mask editing")
            self._validate_refine_token_budget(
                task=task,
                target=upscale_target,
                latent_t=conditioning.latent_t,
                latent_h=conditioning.height // 16,
                latent_w=conditioning.width // 16,
                audio_t=conditioning.audio_t,
                text_len=int(conditioning.hidden_states.shape[0]),
                keyframe_count=len(conditioning.keyframe_frame_indices),
                ref_blocks=list(conditioning.ref_blocks) or None,
            )
        visual_condition = conditioning.visual_condition
        ref_blocks = list(conditioning.ref_blocks) or None
        keyframe_frame_indices = list(conditioning.keyframe_frame_indices) or None
        guide_blocks = None
        if conditioning.guide_blocks or latent_continuation is not None:
            # Continuation, latent-mask editing and audio_mode=lock_source are
            # rejected by prepare_encoder_inputs before any guide is decoded;
            # guides are only produced there, from this request's extra_args.
            if conditioning.guide_blocks:
                if latent_refine is not None or upscale_target is not None:
                    raise OmniClientError("MiniMax H3 timeline guides do not support latent refine/upscale")
                self._validate_timeline_guide_sampling(
                    sampling,
                    task,
                    cache_dit=quality_plan.cache_dit,
                    turbo=turbo_spec is not None,
                    native_lora=has_native_lora,
                )
            # A continuation's hidden prefix rides as a frame-0 guide, so its
            # request takes the guided layout; FL2VA keyframes then address the
            # returned frames after it.
            guide_blocks, visual_condition, visual_shapes, audio_condition, audio_lengths, ref_blocks = (
                self._merge_timeline_guides(
                    conditioning,
                    visual_condition,
                    visual_shapes,
                    audio_condition,
                    audio_lengths,
                    frame_offset=latent_continuation.prefix.overlap_frames if latent_continuation is not None else 0,
                )
            )
        num_outputs = _resolve_minimax_h3_num_outputs(sampling.num_outputs_per_prompt)
        cache_key = extra.get(LATENT_CACHE_KEY)
        return {
            "continuation": continuation,
            "latent_continuation": latent_continuation,
            "latent_cache_key": cache_key if isinstance(cache_key, str) else None,
            "task": task,
            "control_rows": control_rows,
            "control_context_scale": control_scale,
            "latent_upscale": upscale_target,
            "latent_refine": latent_refine,
            "keyframe_images": [],
            "height": conditioning.height,
            "width": conditioning.width,
            "num_frames": conditioning.num_frames,
            "latent_t": conditioning.latent_t,
            "latent_h": conditioning.height // 16,
            "latent_w": conditioning.width // 16,
            "audio_t": audio_t,
            "text_embeddings": conditioning.hidden_states.to(device=self.device, dtype=torch.bfloat16),
            "text_tags": conditioning.token_tags.to(device=self.device, dtype=torch.long),
            "visual_condition": (visual_condition.to(device=self.device) if visual_condition is not None else None),
            "visual_condition_shape": visual_shapes[0] if visual_shapes and len(visual_shapes) == 1 else None,
            "audio_condition": (audio_condition.to(device=self.device) if audio_condition is not None else None),
            "ref_audio_t": audio_lengths[0] if audio_lengths and len(audio_lengths) == 1 else None,
            "ref_blocks": ref_blocks,
            "visual_condition_shapes": visual_shapes,
            "audio_condition_lengths": audio_lengths,
            "locked_audio_rows": locked_audio_rows,
            "keyframe_frame_indices": keyframe_frame_indices,
            "guide_blocks": guide_blocks,
            "pad_seq_len": _resolve_pad_seq_len(extra.get("pad_seq_len")),
            "seed": int(sampling.seed if sampling.seed is not None else 42),
            "sampler": sampler,
            "num_steps": num_steps,
            "video_shift": float(extra.get("flow_shift", self.default_video_shift)),
            "audio_shift": float(extra.get("audio_flow_shift", self.default_audio_shift)),
            "base_schedule": base_schedule,
            "num_outputs": num_outputs,
            "preencode_mp4": bool(extra.get("preencode_mp4", False)),
            "preencode_batch_frames": (
                normalize_preencode_batch_frames(extra.get("preencode_batch_frames", 17))
                if extra.get("preencode_mp4", False)
                else 17
            ),
            "video_codec_options": normalize_video_codec_options(
                extra.get("video_codec_options", {"preset": "ultrafast", "threads": "0"})
                if extra.get("preencode_mp4", False)
                else None
            ),
            **latent_edit,
        }

    def _regenerate_silence_rows(self, num_frames: int, audio_t: int) -> torch.Tensor:
        """Encoded stereo silence, the audio the release's refiner conditions on.

        The last encoding is reused only for the same clip length; it is kept on
        the CPU in FP32, and callers place it where they need it.
        """
        key = (num_frames, audio_t)
        cached = getattr(self, "_regenerate_silence", None)
        if cached is not None and cached[0] == key:
            return cached[1]
        samples = round(num_frames / MINIMAX_H3_FPS * MINIMAX_H3_AUDIO_SAMPLE_RATE)
        with self._component_on_device(self.audio_vae):
            rows, encoded_t = self.audio_vae.encode_waveform(torch.zeros(2, samples), MINIMAX_H3_AUDIO_SAMPLE_RATE)
        if encoded_t != audio_t:
            raise RuntimeError(f"encoded silence has {encoded_t} audio latents, the canvas {audio_t}")
        self._regenerate_silence = (key, rows.to(device="cpu", dtype=torch.float32))
        return self._regenerate_silence[1]

    def _prepare_regenerate_inputs(
        self,
        conditioning: MiniMaxH3EncoderConditioning,
        sampling: Any,
    ) -> dict[str, Any]:
        """Turn an encoded draft into an Open-H3-Regenerate refine pass.

        The draft arrives as latent-edit source rows under an all-keep mask (see
        ``prepare_encoder_inputs``) and skips the first denoise pass: it is
        upscaled and refined directly. The refiner conditions on encoded
        silence, as the release does; the output keeps the draft's own audio
        when it has a track.
        """
        extra = sampling.extra_args or {}
        if self._regenerate is None:
            raise OmniClientError(
                "regenerate needs a server started with --lora-path pointing at an Open-H3-Regenerate release"
            )
        if extra.get("regenerate") is not True:
            raise OmniClientError(
                "this server regenerates drafts only; send the draft as source_video with regenerate=true "
                "(extra_params over HTTP)"
            )
        if getattr(self.od_config, "step_execution", False):
            raise OmniClientError("Open-H3-Regenerate does not support step execution")
        if resolve_continuation_request(extra) is not None:
            raise OmniClientError("Open-H3-Regenerate does not support continue_from")
        if extra.get(LATENT_CACHE_KEY) is not None:
            # The 2K output leaves the base canvas a later continue_from would need.
            raise OmniClientError("Open-H3-Regenerate outputs are not cached for continue_from; drop latent_cache_key")
        if not self.load_vae_encoder:
            raise OmniClientError("Open-H3-Regenerate needs a local VAE encoder")
        num_steps = self._regenerate.check_request(sampling)
        if conditioning.task not in REGENERATE_SUPPORTED_TASKS:
            raise OmniClientError(f"Open-H3-Regenerate refines T2VA drafts, got task={conditioning.task!r}")
        source = conditioning.video_edit_clean_rows
        if source is None or conditioning.video_edit_mask is None or bool(conditioning.video_edit_mask.any()):
            raise OmniClientError("Open-H3-Regenerate needs the draft as source_video and no video_noise_mask")
        if conditioning.audio_edit_mask is not None and bool(conditioning.audio_edit_mask.any()):
            raise OmniClientError("Open-H3-Regenerate does not take an audio_noise_mask")
        if (
            conditioning.visual_condition is not None
            or conditioning.audio_condition is not None
            or conditioning.ref_blocks
            or conditioning.guide_blocks
        ):
            raise OmniClientError("Open-H3-Regenerate takes a prompt and the draft only")

        latent_t, latent_h, latent_w = conditioning.latent_t, conditioning.height // 16, conditioning.width // 16
        video_latent = minimax_h3_unpatchify_video_tokens(
            source.to(device=self.device, dtype=torch.float32),
            latent_shape=(latent_t, latent_h // 2, latent_w // 2, 24),
            patch_size=(1, 2, 2),
        )
        silence = self._regenerate_silence_rows(conditioning.num_frames, conditioning.audio_t)
        audio_latent = minimax_h3_unpack_audio_tokens(silence, audio_t=2 * conditioning.audio_t, audio_channel=2)
        draft_audio = conditioning.audio_edit_clean_rows
        if draft_audio is not None:
            draft_audio = minimax_h3_unpack_audio_tokens(
                draft_audio.float(), audio_t=2 * conditioning.audio_t, audio_channel=2
            )
        upscale_extra = (
            extra if extra.get("latent_upscale") is not None else {"latent_upscale": REGENERATE_DEFAULT_UPSCALE}
        )
        target = self._resolve_latent_upscale(upscale_extra, latent_h=latent_h, latent_w=latent_w)
        if target is not None and (target.latent_height % 2 or target.latent_width % 2):
            # Regenerate always refines the upscaled draft, which patchifies 2x2.
            raise OmniClientError(
                "Open-H3-Regenerate refines the upscaled draft, so latent_upscale must give a latent height and "
                "width divisible by 2 (32 pixels); use align=32 or a compatible target size"
            )
        self._validate_refine_token_budget(
            task=conditioning.task,
            target=target,
            latent_t=latent_t,
            latent_h=latent_h,
            latent_w=latent_w,
            audio_t=conditioning.audio_t,
            text_len=int(conditioning.hidden_states.shape[0]),
            keyframe_count=0,
            ref_blocks=None,
        )
        quality_plan = self._quality_policy.resolve(
            quality=sampling.quality,
            num_inference_steps=num_steps,
            extra_args=extra,
        )
        if quality_plan.cache_dit is not None:
            raise OmniClientError("Open-H3-Regenerate requires uncached denoising; set quality=lossless")
        cache_backend = str(getattr(self.od_config, "cache_backend", None) or "none").lower()
        if cache_backend not in ("none", "cache_dit"):
            raise OmniClientError(f"Open-H3-Regenerate does not support --cache-backend {cache_backend}")
        self._cache_dit_runtime.prepare(None)
        self._prepare_adaln_adapter(sampling)
        return {
            "continuation": None,
            "control_rows": None,
            "control_context_scale": 1.0,
            "regenerate_source": (video_latent, audio_latent),
            "regenerate_output_audio": draft_audio,
            "task": conditioning.task,
            "latent_upscale": target,
            "latent_refine": MiniMaxH3LatentRefineSpec(strength=1.0),
            "keyframe_images": [],
            "height": conditioning.height,
            "width": conditioning.width,
            "num_frames": conditioning.num_frames,
            "latent_t": latent_t,
            "latent_h": latent_h,
            "latent_w": latent_w,
            "audio_t": conditioning.audio_t,
            "text_embeddings": conditioning.hidden_states.to(device=self.device, dtype=torch.bfloat16),
            "text_tags": conditioning.token_tags.to(device=self.device, dtype=torch.long),
            "visual_condition": None,
            "visual_condition_shape": None,
            "audio_condition": None,
            "ref_audio_t": None,
            "ref_blocks": None,
            "visual_condition_shapes": None,
            "audio_condition_lengths": None,
            "locked_audio_rows": silence.to(device=self.device),
            "keyframe_frame_indices": None,
            "guide_blocks": None,
            "pad_seq_len": None,
            "seed": int(sampling.seed if sampling.seed is not None else 42),
            "sampler": "euler",
            "num_steps": num_steps,
            "video_shift": REGENERATE_VIDEO_SHIFT,
            "audio_shift": self.default_audio_shift,
            "base_schedule": regenerate_schedule(num_steps).base_schedule,
            "num_outputs": _resolve_minimax_h3_num_outputs(sampling.num_outputs_per_prompt),
            "preencode_mp4": bool(extra.get("preencode_mp4", False)),
            "preencode_batch_frames": (
                normalize_preencode_batch_frames(extra.get("preencode_batch_frames", 17))
                if extra.get("preencode_mp4", False)
                else 17
            ),
            "video_codec_options": normalize_video_codec_options(
                extra.get("video_codec_options", {"preset": "ultrafast", "threads": "0"})
                if extra.get("preencode_mp4", False)
                else None
            ),
            "video_edit_clean_rows": None,
            "video_edit_mask_rows": None,
            "video_edit_restore_mask_rows": None,
            "audio_edit_clean_rows": None,
            "audio_edit_mask_rows": None,
            "audio_edit_restore_mask_rows": None,
        }

    def _resolve_latent_continuation(
        self,
        extra: Mapping[str, Any],
        conditioning: MiniMaxH3EncoderConditioning,
        *,
        inherit_canvas: bool,
    ) -> tuple[MiniMaxH3EncoderConditioning, LatentContinuation | None]:
        """Hide the cached tail of ``extra['continue_from']`` in front of the encoded window.

        With ``inherit_canvas`` (an unsized T2VA continuation) the encoder's
        16:9 canvas is provisional and the source clip's replaces it. Of the
        encoder outputs only timeline-guide frames depend on that canvas: T2VA
        has no image references, and the text and the frame and audio lengths do
        not. Sequence lengths, RoPE grids and step chunks are all derived from
        the returned canvas.
        """
        request = resolve_continuation_request(extra)
        if request is None:
            return conditioning, None
        clip = self._latent_clip_cache.get(request.source)
        if clip is None:
            raise OmniClientError(
                f"MiniMax H3 has no cached latents for continue_from={request.source!r}; "
                "the video is unknown, was not generated by this server, or was evicted"
            )
        if inherit_canvas:
            height, width = (int(size) * 16 for size in clip.video.shape[-2:])
            if (height, width) != (conditioning.height, conditioning.width):
                if any(block["kind"] != "audio" for block in conditioning.guide_blocks):
                    raise OmniClientError(
                        "MiniMax H3 timeline guides with continue_from need a size or aspect_ratio "
                        "matching the source video"
                    )
                conditioning = replace(conditioning, height=height, width=width)
        return conditioning, plan_latent_continuation(
            clip,
            request,
            num_frames=conditioning.num_frames,
            latent_h=conditioning.height // 16,
            latent_w=conditioning.width // 16,
        )

    def _validate_timeline_guide_sampling(
        self,
        sampling: Any,
        task: str,
        *,
        cache_dit: Any,
        turbo: bool,
        native_lora: bool,
    ) -> None:
        """Guides are validated against base weights and the full schedule only."""
        if cache_dit is not None:
            raise OmniClientError("MiniMax H3 timeline guides require cache-free execution; use quality=lossless")
        cache_backend = str(getattr(self.od_config, "cache_backend", None) or "none").lower()
        if cache_backend not in ("none", "cache_dit"):
            raise OmniClientError("MiniMax H3 timeline guides do not support cache acceleration")
        if self._fasth3 is not None or self._fasth3_checkpoint is not None:
            raise OmniClientError("MiniMax H3 timeline guides require base H3 weights, not FastH3")
        active_lora = sampling.lora_request is not None and not math.isclose(float(sampling.lora_scale), 0.0)
        if turbo or native_lora or active_lora:
            raise OmniClientError("MiniMax H3 timeline guides do not support active LoRA/Turbo adapters")
        if self._sigma_schedule_for_request(sampling, task) is not None:
            raise OmniClientError("MiniMax H3 timeline guides do not support distilled schedules")

    def _merge_timeline_guides(
        self,
        conditioning: MiniMaxH3EncoderConditioning,
        visual_condition: torch.Tensor | None,
        visual_shapes: list[tuple[int, int, int]] | None,
        audio_condition: torch.Tensor | None,
        audio_lengths: list[int] | None,
        *,
        frame_offset: int = 0,
    ) -> tuple[
        list[dict[str, Any]],
        torch.Tensor | None,
        list[tuple[int, int, int]] | None,
        torch.Tensor | None,
        list[int] | None,
        list[dict[str, Any]] | None,
    ]:
        """Put guide rows ahead of reference rows for each modality.

        FL2VA keyframes become trailing still-image guides, so a guided request
        packs every clean visual condition through one block layout. Their
        indices address the returned frames, after ``frame_offset`` hidden ones.
        """
        guide_blocks = [dict(block) for block in conditioning.guide_blocks]
        guide_shapes = [
            (int(block["latent_t"]), int(block["latent_h"]), int(block["latent_w"]))
            for block in guide_blocks
            if block["kind"] != "audio"
        ]
        guide_lengths = [
            int(block["ref_audio_t"]) for block in guide_blocks if block["kind"] in ("audio", "video_audio")
        ]
        ref_blocks = list(conditioning.ref_blocks)
        if conditioning.task == "fl2va":
            for index, shape in zip(conditioning.keyframe_frame_indices, visual_shapes or (), strict=True):
                guide_blocks.append(
                    {
                        "kind": "image",
                        "frame_index": resolve_guide_start(
                            window_frame_index(int(index), frame_offset), conditioning.num_frames
                        ),
                        "latent_h": shape[1],
                        "latent_w": shape[2],
                    }
                )
            ref_blocks = []
        visual_parts = [
            part.to(device=self.device)
            for part in (conditioning.guide_visual_condition, visual_condition)
            if part is not None
        ]
        audio_parts = [
            part.to(device=self.device)
            for part in (conditioning.guide_audio_condition, audio_condition)
            if part is not None
        ]
        return (
            guide_blocks,
            torch.cat(visual_parts) if visual_parts else None,
            (guide_shapes + list(visual_shapes or ())) or None,
            torch.cat(audio_parts) if audio_parts else None,
            (guide_lengths + list(audio_lengths or ())) or None,
            ref_blocks or None,
        )

    @staticmethod
    def _denoise_kwargs(context: dict[str, Any]) -> dict[str, Any]:
        """Select the denoise-input arguments from a prepared request context."""
        return {
            **{key: context[key] for key in _MINIMAX_H3_DENOISE_INPUT_KEYS},
            "sampler": context.get("sampler", "euler"),
        }

    @torch.no_grad()
    def forward(self, request: DiffusionRequestBatch) -> DiffusionOutput:
        if len(request.prompts) != 1:
            raise OmniClientError("MiniMax H3 supports one request at a time")
        check_request_cancellation()
        context = self._prepare_request_inputs(
            request.prompts[0],
            request.sampling_params,
        )
        check_request_cancellation()
        denoise_kwargs = self._denoise_kwargs(context)
        num_outputs = context["num_outputs"]
        upscale_target = context.get("latent_upscale")
        latent_refine = context.get("latent_refine")
        height, width = _minimax_h3_output_canvas(context, upscale_target)
        latent_continuation = context.get("latent_continuation")
        prefix = None if latent_continuation is None else _device_prefix(latent_continuation, self.device)
        trim = _continuation_trim(latent_continuation)
        videos = []
        audios = []
        # Each seed appends one count on the output owner and none on peers;
        # decode_to_mp4 rejects multiple MP4 outputs for a single seed.
        frame_counts = []
        regenerate_source = context.get("regenerate_source")
        if regenerate_source is not None and upscale_target is not None:
            # The draft is the same for every seed and the upscale deterministic:
            # upscale it once; only the refine pass below depends on the seed.
            regenerate_source = (self._upscaled_latent(regenerate_source[0], upscale_target), regenerate_source[1])
        for output_index, output_seed in enumerate(_minimax_h3_output_seeds(context["seed"], num_outputs)):
            check_request_cancellation()
            output_kwargs = {**denoise_kwargs, "seed": output_seed}
            if regenerate_source is not None:
                # Open-H3-Regenerate starts from the encoded draft, not noise.
                video_latent, audio_latent = regenerate_source
            elif context.get("continuation") is None and prefix is None:
                video_latent, audio_latent = self.diffuse(
                    **output_kwargs,
                    request_context=context,
                )
            else:
                # A continued request is one window behind its hidden prefix,
                # or long-video windows whose first one starts behind it.
                window_frames, overlap_frames = context.get("continuation") or (
                    context["num_frames"],
                    prefix.overlap_frames,
                )
                video_latent, audio_latent = diffuse_continuation(
                    self.diffuse,
                    output_kwargs,
                    window_frames=window_frames,
                    overlap_frames=overlap_frames,
                    text_conditioning=context.get("continuation_text_conditioning"),
                    prefix=prefix,
                )
            check_request_cancellation()
            # Continuations stay on the base canvas, so an upscaled clip is cached
            # before the upscale; otherwise cache what the client receives.
            cache_clip = output_index == 0 and context.get("latent_cache_key") is not None
            if cache_clip and upscale_target is not None:
                self._cache_clip_latents(context, video_latent, audio_latent)
            if upscale_target is not None and regenerate_source is None:
                video_latent = self._upscaled_latent(video_latent, upscale_target)
            if latent_refine is not None:
                video_latent, audio_latent = self._refined_latents(
                    video_latent,
                    audio_latent,
                    context=context,
                    seed=output_seed,
                )
            if cache_clip and upscale_target is None:
                self._cache_clip_latents(context, video_latent, audio_latent)
            if context.get("regenerate_output_audio") is not None:
                audio_latent = context["regenerate_output_audio"]
            if not self.load_vae_decoder:
                videos.append(video_latent)
                audios.append(audio_latent)
                continue
            if context["preencode_mp4"]:
                videos.append(
                    self.decode_to_mp4(
                        video_latent,
                        audio_latent,
                        height=height,
                        width=width,
                        video_codec_options=context["video_codec_options"],
                        batch_frames=context["preencode_batch_frames"],
                        frame_counts=frame_counts,
                        trim=trim,
                    )
                )
                audios.append(None)
            else:
                video, audio = self.decode(
                    video_latent,
                    audio_latent,
                    height=height,
                    width=width,
                )
                if trim is not None:
                    # Decode keeps the real tail as causal context; return only new frames.
                    video, audio = trim_decoded_overlap(video, audio, **trim)
                # Rebind rather than append the expression: the local would
                # otherwise keep the decoded frames' device storage alive for the
                # rest of the iteration, and the next seed's diffuse() -- the DiT
                # reload this release exists to make room for -- runs before the
                # loop rebinds it. post_decode() rebinds for the same reason.
                video = self._offload_model_cpu_stage_output(_prepare_minimax_h3_video_output(video))
                videos.append(video)
                # The FP32 decoded frames are quantized into the appended uint8
                # tensor; drop the reference and return the idle pages instead of
                # holding them through the next output's denoise/decode.
                del video
                self._release_stage_cache()
                audios.append(audio)
        if not self.load_vae_decoder:
            return self._decoder_stage_output(
                videos, audios, {**context, "height": height, "width": width, "trim": trim}
            )
        if videos and isinstance(videos[0], bytes):
            video = videos[0] if len(videos) == 1 else videos
            audio = None
        else:
            video = videos[0] if len(videos) == 1 else torch.cat(videos, dim=0)
            audio = audios[0] if len(audios) == 1 else torch.cat(audios, dim=0)
        return DiffusionOutput(
            output=(
                _MiniMaxH3EncodedOutput(video=video, frame_counts=frame_counts) if frame_counts else (video, audio)
            ),
            video_output_index=0 if isinstance(video, torch.Tensor) else None,
            post_process_func=get_minimax_h3_post_process_func(self.od_config),
            stage_durations=(self.stage_durations if hasattr(self, "_stage_durations") else {}),
        )

    def _cache_clip_latents(
        self,
        context: Mapping[str, Any],
        video_latent: torch.Tensor,
        audio_latent: torch.Tensor,
    ) -> None:
        """Keep a finished clip's base-canvas latents for later continue_from requests."""
        continuation = context.get("latent_continuation")
        self._latent_clip_cache.put(
            context["latent_cache_key"],
            CachedClip(
                video=video_latent.detach().to("cpu", copy=True),
                audio=audio_latent.detach().to("cpu", copy=True),
                # A continued clip starts with the tail it repeats.
                start_frame=continuation.prefix.start_frame if continuation is not None else 0,
                num_frames=context["num_frames"],
            ),
        )

    def _decoder_stage_output(
        self,
        video_latents: list[torch.Tensor],
        audio_latents: list[torch.Tensor],
        shape: dict[str, Any],
    ) -> DiffusionOutput:
        # Move latents to CPU at the process boundary; the decoder owns its parallel group.
        decode_options = {
            "height": shape["height"],
            "width": shape["width"],
            "preencode_mp4": shape.get("preencode_mp4", False),
            "video_codec_options": shape.get("video_codec_options"),
            "preencode_batch_frames": shape.get("preencode_batch_frames", 17),
            "trim": shape.get("trim"),
        }
        return DiffusionOutput(
            output={
                "payload": {"trajectory": {"latents": {"video": video_latents, "audio": audio_latents}}},
                "metadata": {"minimax_h3_decode": decode_options},
            },
            to_cpu=True,
            stage_durations=(self.stage_durations if hasattr(self, "_stage_durations") else {}),
        )

    # ------------------------------------------------------------------
    # Step-wise execution (continuous batching)
    # ------------------------------------------------------------------

    @staticmethod
    def _packed_batch_supported(transformer: MiniMaxH3DiTModel) -> bool:
        """Whether every attention in this DiT honors multi-document cu_seqlens.

        A packed batch is only isolated if *all* of them do: the token refiner
        runs under its own attention role and can resolve to a different backend
        from the DiT blocks. Ring sequence parallelism dispatches through
        ``RingParallelAttention``, whose kernels ignore the packed
        ``cu_seqlens`` metadata regardless of the configured backend; packing
        multiple requests under ring would let attention cross document
        boundaries, so any layer running ring disqualifies the batch.

        The gate probes a per-backend capability rather than a fixed backend
        name: FLASH_ATTN, for example, only isolates arbitrary N-document
        packed cu_seqlens on CUDA/ROCm/MUSA. Its NPU path only accepts a
        ``[real, pad]`` two-document layout and its XPU path ignores
        cu_seqlens outright — either would silently attend across request
        boundaries.
        """
        attentions = [module for module in transformer.modules() if isinstance(module, MiniMaxH3Attention)]
        if not attentions:
            return False
        # Each layer is checked against the backend it runs under the published progress: inside a
        # scheduled step that is the step's candidate, otherwise the baseline.
        return all(
            _attention_isolates_packed_requests(module.attention, module.attention.effective_attention()[1])
            for module in attentions
        )

    def prepare_encode(self, state: StepRequestState, **kwargs: Any) -> StepRequestState:
        """Run every request-level stage once and seed the per-request step state."""
        del kwargs
        # Two request-mode features have no place in the shared step contract:
        # a request state carries exactly one latent tensor, and distributed
        # layerwise offload streams the DiT around one whole denoise loop rather
        # than around a single scheduler-driven step.
        num_outputs = _resolve_minimax_h3_num_outputs(state.sampling.num_outputs_per_prompt)
        if num_outputs != 1:
            raise OmniClientError(
                f"MiniMax H3 step execution produces one output per request, got num_outputs_per_prompt={num_outputs}"
            )
        if getattr(self, "_dlo_residency_controller", None) is not None:
            raise ValueError(
                "MiniMax H3 step execution is not compatible with distributed layerwise offload; "
                "the resident-layer window spans a whole denoise loop, so per-step streaming would "
                "reload the DiT every step. Drop --step-execution or --enable-distributed-layerwise-offload."
            )
        # Request-scoped Cache-DiT (quality=high) mutates hook state on the
        # shared transformer rather than on ``StepRequestState``. In step mode
        # two requests can interleave denoise steps, or be co-batched into a
        # single forward, and the second one would then re-enter the DiT with
        # cache buffers shaped for the first. Reject the profile here rather
        # than let it corrupt outputs at runtime; startup-configured Cache-DiT
        # is already blocked in ``DiffusionModelRunner.execute_stepwise``.
        if getattr(state.sampling, "quality", None) == "high":
            raise OmniClientError(
                "MiniMax H3 step execution does not support the high-quality Cache-DiT profile "
                "(quality=high); its hooks live on the shared transformer, so interleaved or "
                "co-batched requests would reuse incompatible cache state. Drop --step-execution "
                "or omit quality=high."
            )
        # A refine pass is a second denoise loop, at its own resolution and over
        # its own truncated schedule. The step contract gives the scheduler one
        # latent and one schedule per request, so there is nowhere to put it.
        # Latent upscaling alone has no such problem and stays supported: it
        # runs once in ``post_decode``.
        if self._resolve_latent_refine(getattr(state.sampling, "extra_args", None) or {}) is not None:
            raise OmniClientError(
                "MiniMax H3 step execution does not support latent_refine; it is a second denoise "
                "loop and the step contract carries one schedule per request. Drop --step-execution, "
                "or keep latent_upscale without latent_refine."
            )
        context = self._prepare_request_inputs(
            state.prompt,
            state.sampling,
        )
        denoise_kwargs = self._denoise_kwargs(context)
        continuation = context.get("latent_continuation")
        prefix = None if continuation is None else _device_prefix(continuation, self.device)
        if prefix is not None:
            # One window behind the hidden prefix, on the chain's global clock.
            denoise_kwargs = window_args(
                denoise_kwargs,
                ContinuationWindow(
                    prefix.start_frame, prefix.start_frame + context["num_frames"], prefix.overlap_frames
                ),
                video_tail=prefix.video,
                audio_tail=prefix.audio,
                timeline_guide=True,
                audio_origin=_audio_t(prefix.start_frame),
            )
        inputs = self._build_denoise_inputs(
            **denoise_kwargs,
            precomputed_initial_noise=context.pop("precomputed_initial_noise", None) if prefix is None else None,
            precomputed_visual_condition_noise=(
                context.pop("precomputed_visual_condition_noise", None) if prefix is None else None
            ),
        )

        sigmas_video = inputs["sigmas_video"]
        sigmas_audio = inputs["sigmas_audio"]
        if len(sigmas_video) < 2:
            raise OmniClientError(
                f"MiniMax H3 step execution needs at least one denoise step, got num_inference_steps="
                f"{len(sigmas_video) - 1}"
            )

        branch = inputs["branch"]
        video_rows, audio_rows, cond_anchor, audio_anchor = minimax_h3_prepare_denoise_rows(
            positive=branch,
            initial_video_rows=inputs["video_rows"],
            initial_audio_rows=inputs["audio_rows"],
            keyframe_cond_rows=inputs["cond_anchor"],
            audio_ref_rows=inputs["audio_anchor"],
            device=self.device,
        )

        # The denoise loop consumes sigma pairs, so the schedule carries one more
        # point than there are steps. ``timesteps`` holds the video branch because
        # the shared contract gives a request exactly one timestep sequence; the
        # audio schedule rides along in ``extra``.
        state.timesteps = torch.tensor(
            [1.0 - sigma for sigma in sigmas_video[:-1]],
            dtype=torch.float32,
            device=self.device,
        )
        state.step_index = 0
        # Video rows are the batched tensor the runner slices per request; audio
        # rows have a different width, so they stay request-private.
        state.latents = video_rows
        state.do_true_cfg = False  # H3 checkpoints are CFG-distilled.
        state.extra.update(
            {
                _STEP_BRANCH: branch,
                _STEP_TRANSFORMER: self._transformer_for_task(context["task"]),
                _STEP_AUDIO_ROWS: audio_rows,
                _STEP_COND_ANCHOR: cond_anchor,
                _STEP_AUDIO_ANCHOR: audio_anchor,
                _STEP_VIDEO_SOLVER: create_h3_sample_solver(inputs.get("sampler", "euler"), sigmas_video),
                _STEP_AUDIO_SOLVER: create_h3_sample_solver(inputs.get("sampler", "euler"), sigmas_audio),
                _STEP_SIGMAS_VIDEO: sigmas_video,
                _STEP_SIGMAS_AUDIO: sigmas_audio,
                _STEP_VIDEO_EDIT: inputs.get("video_edit"),
                _STEP_AUDIO_EDIT: inputs.get("audio_edit"),
                _STEP_SHAPE: {
                    "height": context["height"],
                    "width": context["width"],
                    "latent_t": context["latent_t"],
                    "latent_h": context["latent_h"],
                    "latent_w": context["latent_w"],
                    "audio_t": context["audio_t"],
                    "preencode_mp4": context.get("preencode_mp4", False),
                    "preencode_batch_frames": context.get("preencode_batch_frames", 17),
                    "video_codec_options": context.get("video_codec_options"),
                    "latent_upscale": context.get("latent_upscale"),
                    "latent_continuation": context.get("latent_continuation"),
                    "latent_cache_key": context.get("latent_cache_key"),
                    "num_frames": context["num_frames"],
                },
            }
        )
        return state

    def denoise_step(
        self,
        input_batch: InputBatch,
        *,
        states: Sequence[StepRequestState] | None = None,
        **kwargs: Any,
    ) -> torch.Tensor | None:
        """Run one denoise forward covering every request in the batch.

        Requests are concatenated into a single packed sequence that keeps one
        attention document each, so the whole batch costs one DiT forward.
        Backends that ignore ``cu_seqlens`` cannot express that isolation, so
        they fall back to one forward per request. A batch under a bound
        attention schedule is packed only when every request carries the same
        schedule and sits at the same progress, so all of them select one
        profile, and that profile's backends isolate packed requests; otherwise
        it runs one forward per request, each under that request's own step,
        sigma and total.
        """
        del kwargs
        batch_states = list(states if states is not None else input_batch.states)

        branches = [state.extra[_STEP_BRANCH] for state in batch_states]
        schedules = [_minimax_h3_step_schedule(state) for state in batch_states]
        transformers = [state.extra[_STEP_TRANSFORMER] for state in batch_states]
        mixed_transformers = len({id(transformer) for transformer in transformers}) > 1

        video_rows: list[torch.Tensor] = []
        audio_rows: list[torch.Tensor] = []
        video_target_timesteps: list[torch.Tensor | None] = []
        audio_target_timesteps: list[torch.Tensor | None] = []
        for state, branch, schedule in zip(batch_states, branches, schedules, strict=True):
            video_edit = state.extra.get(_STEP_VIDEO_EDIT)
            request_video, request_video_timesteps = minimax_h3_prepare_edit_rows(
                state.latents,
                branch.update_mask_dev,
                video_edit,
                schedule["t_video"],
                schedule["imgvid_cond_timestep"],
                sigma=schedule["sigma_video"],
            )
            video_target_timesteps.append(request_video_timesteps)
            video_rows.append(request_video)

            state_audio = state.extra[_STEP_AUDIO_ROWS]
            audio_edit = state.extra.get(_STEP_AUDIO_EDIT)
            request_audio, request_audio_timesteps = minimax_h3_prepare_edit_rows(
                state_audio,
                branch.audio_update_mask_dev,
                audio_edit,
                schedule["t_audio"],
                schedule["audio_ref_cond_timestep"],
                sigma=schedule["sigma_audio"],
            )
            audio_target_timesteps.append(request_audio_timesteps)
            audio_rows.append(request_audio)

        # Both execution modes must publish denoise progress for step-gated
        # attention features. Requests can differ in both step index and sigma
        # schedule, so a batch that is not at one single point has nothing to
        # publish and those gates stay dense -- which is their safe default.
        # A batch under a bound attention schedule also publishes each request's
        # own progress around its forward below.
        request_progress = [
            (state.step_index, schedule["sigma_video"], len(state.extra[_STEP_SIGMAS_VIDEO]) - 1)
            for state, schedule in zip(batch_states, schedules)
        ]
        progress = set(request_progress)
        uniform_progress = len(progress) == 1
        minimax_h3_publish_denoise_progress(*(progress.pop() if uniform_progress else (None, None, None)))
        scheduled = is_forward_context_available() and bool(getattr(get_forward_context(), "attention_schedule", None))
        # Under a schedule, a packed forward selects one profile from the progress published above,
        # so it may only carry requests that all select that profile: one schedule, one progress.
        # _packed_batch_supported() then checks the selected profile's backends, not the baseline.
        schedule_splits_batch = scheduled and (
            not uniform_progress or len({state.attention_schedule for state in batch_states}) > 1
        )

        pdd = isinstance(self._fasth3_checkpoint, FastH3OmniCheckpointSpec)
        if pdd or (
            len(batch_states) > 1
            and (schedule_splits_batch or mixed_transformers or not self._packed_batch_supported(transformers[0]))
        ):
            if pdd:
                logger.debug(
                    "FastH3 Omni PDD executes %d request(s) separately with request-local step indices.",
                    len(batch_states),
                )
            elif mixed_transformers:
                logger.warning_once(
                    "MiniMax H3 step batch contains requests for different task-specific DiTs; "
                    "running %d requests one forward at a time.",
                    len(batch_states),
                )
            elif schedule_splits_batch:
                logger.info_once(
                    "MiniMax H3 runs a scheduled step batch whose requests differ in progress or schedule "
                    "one request per forward, so each request selects attention at its own step; running %d "
                    "requests one forward at a time.",
                    len(batch_states),
                )
            elif any(
                getattr(getattr(module, "attention", None), "use_ring", False)
                for module in transformers[0].modules()
                if isinstance(module, MiniMaxH3Attention)
            ):
                logger.warning_once(
                    "MiniMax H3 step batching is disabled when ring attention is active: "
                    "the ring kernels ignore packed cu_seqlens and would attend across request "
                    "boundaries. Running %d requests one forward at a time.",
                    len(batch_states),
                )
            else:
                logger.warning_once(
                    "MiniMax H3 step batching needs every attention on a backend that isolates "
                    "packed multi-document cu_seqlens (see AttentionBackend."
                    "supports_multi_doc_packed_varlen); running %d requests one forward at a time.",
                    len(batch_states),
                )
            video_parts: list[torch.Tensor] = []
            audio_parts: list[torch.Tensor] = []
            for index, branch in enumerate(branches):
                forward_kwargs = branch.forward_kwargs(
                    video_rows=video_rows[index],
                    audio_rows=audio_rows[index],
                    t_video=schedules[index]["t_video"],
                    t_audio=schedules[index]["t_audio"],
                    imgvid_cond_timestep=schedules[index]["imgvid_cond_timestep"],
                    audio_ref_cond_timestep=schedules[index]["audio_ref_cond_timestep"],
                    video_target_timesteps=video_target_timesteps[index],
                    audio_target_timesteps=audio_target_timesteps[index],
                )
                if pdd:
                    forward_kwargs["pdd_step"] = int(batch_states[index].step_index)
                # Each scheduled request selects its profile at its own progress. The
                # batch-level progress published above is restored after each forward,
                # including when it raises.
                step, sigma_video, total_steps = request_progress[index]
                with request_denoise_progress(step, total_steps, sigma_video) if scheduled else nullcontext():
                    request_video, request_audio = transformers[index](**forward_kwargs)
                video_parts.append(request_video)
                audio_parts.append(request_audio)
            video_velocity = torch.cat(video_parts)
            audio_velocity = torch.cat(audio_parts)
        else:
            forward_kwargs = minimax_h3_batched_forward_kwargs(
                branches=branches,
                video_rows=video_rows,
                audio_rows=audio_rows,
                t_video=[schedule["t_video"] for schedule in schedules],
                t_audio=[schedule["t_audio"] for schedule in schedules],
                imgvid_cond_timesteps=[schedule["imgvid_cond_timestep"] for schedule in schedules],
                audio_ref_cond_timesteps=[schedule["audio_ref_cond_timestep"] for schedule in schedules],
                video_target_timesteps=video_target_timesteps,
                audio_target_timesteps=audio_target_timesteps,
            )
            logger.debug(
                "MiniMax H3 denoise step: %d request(s) packed into %d rows",
                len(batch_states),
                int(forward_kwargs["x"].shape[1]),
            )
            video_velocity, audio_velocity = transformers[0](**forward_kwargs)

        # The shared contract carries one velocity tensor per step, and audio rows
        # are a different width than video rows, so hand the audio branch to
        # step_scheduler() through request-private state.
        audio_parts_by_request = torch.split(audio_velocity, [int(branch.audio_pos.shape[0]) for branch in branches])
        for state, request_audio in zip(batch_states, audio_parts_by_request, strict=True):
            state.extra[_STEP_AUDIO_NOISE_PRED] = request_audio
        return video_velocity

    def step_scheduler(self, state: StepRequestState, noise_pred: torch.Tensor, **kwargs: Any) -> None:
        """Apply one request-local solver update to the video and audio rows."""
        del kwargs
        # denoise_step() stages the audio half of this step's velocity; popping
        # it keeps a second step_scheduler() call from reusing a stale one.
        audio_noise_pred = state.extra.pop(_STEP_AUDIO_NOISE_PRED)

        branch = state.extra[_STEP_BRANCH]
        schedule = _minimax_h3_step_schedule(state)
        update = branch.update_mask_dev
        audio_update = branch.audio_update_mask_dev
        video_rows = state.latents
        audio_rows = state.extra[_STEP_AUDIO_ROWS]
        cond_anchor = state.extra[_STEP_COND_ANCHOR]
        audio_anchor = state.extra[_STEP_AUDIO_ANCHOR]
        device = video_rows.device

        video_edit = state.extra.get(_STEP_VIDEO_EDIT)
        if video_edit is None:
            x0_video = minimax_h3_rf_v_to_x0(
                video_rows[update],
                noise_pred.float()[update],
                torch.tensor(schedule["t_video"], dtype=torch.float32, device=device),
            )
        else:
            x0_video = video_edit.x0(
                video_edit.model_rows(video_rows[update]),
                noise_pred.float()[update],
                schedule["t_video"],
            )
        new_video = state.extra[_STEP_VIDEO_SOLVER].step(video_rows[update], x0_video, state.step_index)
        video_rows = video_rows.clone()
        video_rows[update] = new_video
        if cond_anchor is not None:
            video_rows[~update] = cond_anchor  # per-step imgvid cond reset

        audio_edit = state.extra.get(_STEP_AUDIO_EDIT)
        if audio_edit is None:
            x0_audio = minimax_h3_rf_v_to_x0(
                audio_rows[audio_update],
                audio_noise_pred.float()[audio_update],
                torch.tensor(schedule["t_audio"], dtype=torch.float32, device=device),
            )
        else:
            x0_audio = audio_edit.x0(
                audio_edit.model_rows(audio_rows[audio_update]),
                audio_noise_pred.float()[audio_update],
                schedule["t_audio"],
            )
        new_audio = state.extra[_STEP_AUDIO_SOLVER].step(audio_rows[audio_update], x0_audio, state.step_index)
        audio_rows = audio_rows.clone()
        audio_rows[audio_update] = new_audio if branch.locked_audio_rows is None else branch.locked_audio_rows
        if audio_anchor is not None:
            audio_rows[~audio_update] = audio_anchor  # per-step audio ref reset

        state.latents = video_rows
        state.extra[_STEP_AUDIO_ROWS] = audio_rows
        state.step_index += 1

    def post_decode(self, state: StepRequestState, **kwargs: Any) -> DiffusionOutput:
        """Unpack the denoised rows and run the joint video/audio VAE decode."""
        del kwargs
        shape = state.extra[_STEP_SHAPE]
        video_latent, audio_latent = self._unpack_denoised_rows(
            state.extra[_STEP_BRANCH],
            state.latents,
            state.extra[_STEP_AUDIO_ROWS],
            latent_t=shape["latent_t"],
            latent_h=shape["latent_h"],
            latent_w=shape["latent_w"],
            audio_t=shape["audio_t"],
        )
        continuation = shape.get("latent_continuation")
        prefix = None if continuation is None else _device_prefix(continuation, self.device)
        if prefix is not None:
            # Keep the real tail in front of the new frames, as in-request continuation does.
            video_latent = torch.cat((prefix.video, video_latent[:, :, prefix.video.shape[2] :]), dim=2)
            audio_latent = torch.cat((prefix.audio, audio_latent[..., prefix.audio.shape[-1] :]), dim=-1)
        if shape.get("latent_cache_key") is not None:
            self._cache_clip_latents(shape, video_latent, audio_latent)
        trim = _continuation_trim(continuation)
        upscale_target = shape.get("latent_upscale")
        if upscale_target is not None:
            video_latent = self._upscaled_latent(video_latent, upscale_target)
        height, width = _minimax_h3_output_canvas(shape, upscale_target)
        if not self.load_vae_decoder:
            return self._decoder_stage_output(
                [video_latent], [audio_latent], {**shape, "height": height, "width": width, "trim": trim}
            )
        frame_counts = []
        if shape.get("preencode_mp4", False):
            video = self.decode_to_mp4(
                video_latent,
                audio_latent,
                height=height,
                width=width,
                video_codec_options=shape.get("video_codec_options"),
                batch_frames=shape.get("preencode_batch_frames", 17),
                frame_counts=frame_counts,
                trim=trim,
            )
            audio = None
        else:
            video, audio = self.decode(
                video_latent,
                audio_latent,
                height=height,
                width=width,
            )
            if trim is not None:
                video, audio = trim_decoded_overlap(video, audio, **trim)
            video = self._offload_model_cpu_stage_output(_prepare_minimax_h3_video_output(video))
            self._release_stage_cache()
        return DiffusionOutput(
            output=(
                _MiniMaxH3EncodedOutput(video=video, frame_counts=frame_counts) if frame_counts else (video, audio)
            ),
            video_output_index=0 if isinstance(video, torch.Tensor) else None,
            post_process_func=get_minimax_h3_post_process_func(self.od_config),
            stage_durations=(self.stage_durations if hasattr(self, "_stage_durations") else {}),
        )


__all__ = [
    "MiniMaxH3Pipeline",
    "get_minimax_h3_post_process_func",
]
