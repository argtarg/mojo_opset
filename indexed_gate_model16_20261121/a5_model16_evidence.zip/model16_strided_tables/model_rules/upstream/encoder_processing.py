# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM-Omni project
"""Shared request preparation and condition codec execution for MiniMax H3."""

from __future__ import annotations

import math
import os
import subprocess
import tempfile
from collections.abc import Callable, Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from contextlib import AbstractContextManager, nullcontext
from dataclasses import dataclass
from typing import Any

import numpy as np
import torch
from PIL import Image
from vllm.logger import init_logger

from vllm_omni.errors import OmniClientError
from vllm_omni.model_executor.models.minimax_h3.conditioning import (
    MiniMaxH3EncoderMediaConditioning,
    MiniMaxH3EncoderMediaInput,
    MiniMaxH3TimelineGuide,
)
from vllm_omni.model_executor.models.minimax_h3.continuation_request import (
    continuation_output_frames,
    resolve_continuation_request,
    window_frame_index,
)
from vllm_omni.model_executor.models.minimax_h3.long_video import max_output_seconds, resolve_long_video_mode
from vllm_omni.model_executor.models.minimax_h3.preprocessing import (
    MINIMAX_H3_OUTPUT_SHORT_EDGE,
    load_minimax_h3_images,
    resolve_minimax_h3_aspect_ratio,
    resolve_minimax_h3_output_canvas,
    resolve_minimax_h3_reference_image_shape,
)
from vllm_omni.model_executor.models.minimax_h3.reference_video import (
    MINIMAX_H3_QWEN_VIDEO_SAMPLE_FPS,
    load_audio_file,
    load_video_audio,
    load_video_frames,
    prepare_edit_video,
    prepare_reference_videos,
    sample_reference_video_frames,
    validate_reference_audio_files,
    validate_reference_audio_waveforms,
)
from vllm_omni.model_executor.models.minimax_h3.timeline_guides import (
    MINIMAX_H3_TIMELINE_GUIDES_KEY,
    prepare_timeline_guides,
)

logger = init_logger(__name__)

MINIMAX_H3_FPS = 24
MINIMAX_H3_MIN_OUTPUT_SECONDS = 4.0
MINIMAX_H3_MAX_OUTPUT_SECONDS = 15.0


def _items(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple) and not (len(value) == 2 and isinstance(value[1], Mapping)):
        return list(value)
    return [value]


def _audio_items(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, (list, tuple)) and len(value) == 2 and isinstance(value[1], (int, np.integer)):
        return [value]
    return list(value) if isinstance(value, (list, tuple)) else [value]


def _load_audio(value: Any) -> tuple[torch.Tensor, int]:
    if isinstance(value, (list, tuple)) and not (len(value) == 2 and isinstance(value[1], (int, np.integer))):
        audios = _load_audios(value)
        if len(audios) != 1:
            raise OmniClientError(f"MiniMax H3 expected one audio, got {len(audios)}")
        return audios[0]
    if isinstance(value, (str, os.PathLike)):
        return load_audio_file(str(value))
    if isinstance(value, (list, tuple)) and len(value) == 2:
        waveform, sample_rate = value
        return torch.as_tensor(waveform).float(), int(sample_rate)
    if isinstance(value, dict):
        waveform = value.get("waveform", value.get("array"))
        sample_rate = value.get("sample_rate", value.get("sampling_rate"))
        if waveform is not None and sample_rate is not None:
            return torch.as_tensor(waveform).float(), int(sample_rate)
    raise OmniClientError("MiniMax H3 audio input must be a path, (waveform, sample_rate), or a waveform mapping")


def _load_audios(value: Any) -> list[tuple[torch.Tensor, int]]:
    if isinstance(value, (list, tuple)) and not (len(value) == 2 and isinstance(value[1], (int, np.integer))):
        if not value:
            raise OmniClientError("MiniMax H3 audio input must not be empty")
        return [_load_audio(item) for item in value]
    return [_load_audio(value)]


def _as_int_list(value: Any, *, name: str) -> list[int]:
    if isinstance(value, bool):
        raise OmniClientError(f"{name} must be an integer or a list of integers")
    if isinstance(value, (int, np.integer)):
        return [int(value)]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        result = list(value)
        if not result:
            raise OmniClientError(f"{name} must not be empty")
        if any(isinstance(item, bool) or not isinstance(item, (int, np.integer)) for item in result):
            raise OmniClientError(f"{name} must contain only integers")
        return [int(item) for item in result]
    raise OmniClientError(f"{name} must be an integer or a list of integers")


def _resolve_fl2va_keyframe_indices(extra: Mapping[str, Any], image_count: int) -> list[int]:
    target = extra.get("target")
    target = target if isinstance(target, Mapping) else {}
    raw = extra.get("frame_indices", extra.get("frame_index"))
    if raw is None:
        raw = target.get("frame_indices", target.get("frame_index"))
    raw_indices = ([0] if image_count == 1 else [0, -1]) if raw is None else _as_int_list(raw, name="frame_indices")
    if len(raw_indices) != image_count:
        raise OmniClientError(
            f"MiniMax H3 FL2VA requires one frame index per image: got {raw_indices!r} for {image_count} image(s)"
        )
    if tuple(raw_indices) not in ((0,), (-1,), (0, -1)):
        raise OmniClientError("MiniMax H3 FL2VA frame_indices must be [0], [-1], or [0, -1]")
    return raw_indices


def _validate_ref2va_reference_counts(
    image_count: int,
    video_count: int,
    audio_count: int,
    *,
    latent_continuation: bool = False,
) -> None:
    if min(image_count, video_count, audio_count) < 0:
        raise OmniClientError("MiniMax H3 reference counts must be non-negative")
    # A cross-request continuation is guided by cached latents of the clip it
    # continues, so it needs no image or video reference of its own.
    if image_count + video_count == 0 and not latent_continuation:
        raise OmniClientError("ref2va requires at least one image or video reference")
    if image_count > 9:
        raise OmniClientError("ref2va accepts at most 9 image references")
    if video_count > 3:
        raise OmniClientError("ref2va accepts at most 3 video references")
    if audio_count > 3:
        raise OmniClientError("ref2va accepts at most 3 standalone audio references")
    if image_count + video_count + audio_count > 12:
        raise OmniClientError("ref2va accepts at most 12 total references")


def _validate_reference_image(image: Image.Image) -> None:
    resolve_minimax_h3_reference_image_shape(image)


def continuation_inherits_source_canvas(task: str, sampling: Any) -> bool:
    """Whether a T2VA ``continue_from`` request names no canvas and so keeps its source clip's."""
    extra = sampling.extra_args or {}
    target = extra.get("target") if isinstance(extra.get("target"), Mapping) else {}
    return (
        task == "t2va"
        and resolve_continuation_request(extra) is not None
        and target.get("aspect_ratio", extra.get("aspect_ratio")) is None
        and getattr(sampling, "height", None) is None
        and getattr(sampling, "width", None) is None
    )


def resolve_minimax_h3_shape(
    task: str,
    sampling: Any,
    image: Image.Image | None,
    *,
    continuation_window: bool = True,
) -> tuple[int, int, int, int, int]:
    """Resolve the sampled canvas and length.

    A ``continue_from`` request describes the clip it returns; its sampled
    window prepends the hidden overlap unless ``continuation_window`` is off.
    """
    # The diffusion package exports a pipeline that imports this shared module.
    from vllm_omni.diffusion.models.minimax_h3.time_request import (
        MINIMAX_H3_SHAPE_PLANNER,
        minimax_h3_align_frame_count,
    )

    fps = int(getattr(sampling, "fps", None) or MINIMAX_H3_FPS)
    if fps != MINIMAX_H3_FPS:
        raise OmniClientError(f"MiniMax H3 output fps is fixed at {MINIMAX_H3_FPS}")
    extra = sampling.extra_args or {}
    target = extra.get("target")
    if target is not None and not isinstance(target, Mapping):
        raise OmniClientError("MiniMax H3 extra_args['target'] must be an object")
    target = target if isinstance(target, Mapping) else {}
    max_seconds = max_output_seconds(extra, task)
    duration_range = f"in [4, {max_seconds:g}] seconds"
    duration = target.get("duration_seconds", extra.get("duration_seconds", extra.get("duration")))
    if duration is not None:
        if isinstance(duration, bool):
            raise OmniClientError(f"MiniMax H3 output duration must be {duration_range}, got {duration!r}")
        try:
            duration = float(duration)
        except (TypeError, ValueError) as exc:
            raise OmniClientError(f"MiniMax H3 output duration must be {duration_range}, got {duration!r}") from exc
        if not math.isfinite(duration) or not MINIMAX_H3_MIN_OUTPUT_SECONDS <= duration <= max_seconds:
            raise OmniClientError(f"MiniMax H3 output duration must be {duration_range}, got {duration}")
        requested_frames = int(round(duration * fps))
    elif int(getattr(sampling, "num_frames", None) or 1) > 1:
        requested_frames = int(sampling.num_frames)
    else:
        requested_frames = 124 if task == "ref2va" else 209
    # Cap on the 17n+5 grid so num_frames accepts what the same duration aligns to.
    max_frames = minimax_h3_align_frame_count(int(max_seconds * fps))
    if requested_frames / fps < MINIMAX_H3_MIN_OUTPUT_SECONDS or requested_frames > max_frames:
        raise OmniClientError(
            f"MiniMax H3 output duration must be {duration_range} (at most {max_frames} frames), "
            f"got {requested_frames / fps:.3f}"
        )
    num_frames = minimax_h3_align_frame_count(requested_frames)
    continuation = resolve_continuation_request(extra) if continuation_window else None
    if continuation is not None:
        num_frames = continuation.overlap_frames + continuation_output_frames(num_frames)
        if num_frames > max_frames:
            raise OmniClientError(
                f"MiniMax H3 continuation output must be at most {max_frames - continuation.overlap_frames} frames, "
                f"got {requested_frames / fps:.3f} seconds"
            )

    height = getattr(sampling, "height", None)
    width = getattr(sampling, "width", None)
    if task == "t2va" and (height is None) != (width is None) and resolve_continuation_request(extra) is not None:
        # A lone dimension would otherwise be replaced by the inherited source canvas.
        raise OmniClientError("MiniMax H3 continue_from needs both height and width, or neither")
    requested_aspect_ratio = target.get("aspect_ratio", extra.get("aspect_ratio"))
    if task == "t2va" and requested_aspect_ratio is None and resolve_continuation_request(extra) is not None:
        # A continuation needs no aspect ratio of its own: an explicit size wins
        # below. Without one this canvas is provisional; only the diffusion worker
        # holds the source clip, and it substitutes the source's canvas
        # (see continuation_inherits_source_canvas).
        requested_aspect_ratio = "16:9"
    aspect_ratio = resolve_minimax_h3_aspect_ratio(task, requested_aspect_ratio, image)
    raw_short_edge = target.get("short_edge", extra.get("short_edge", MINIMAX_H3_OUTPUT_SHORT_EDGE))
    if isinstance(raw_short_edge, bool) or not isinstance(raw_short_edge, (int, np.integer)):
        raise OmniClientError(
            f"MiniMax H3 target.short_edge must be {MINIMAX_H3_OUTPUT_SHORT_EDGE}, got {raw_short_edge!r}"
        )
    if height is None or width is None:
        height, width = resolve_minimax_h3_output_canvas(aspect_ratio, int(raw_short_edge))
    height = int(height) // 32 * 32
    width = int(width) // 32 * 32
    if min(height, width) <= 0:
        raise OmniClientError(f"invalid MiniMax H3 canvas {width}x{height}")
    if width > 4 * height or height > 4 * width:
        raise OmniClientError("MiniMax H3 canvas aspect ratio must be in [1:4, 4:1]")
    return (
        height,
        width,
        num_frames,
        MINIMAX_H3_SHAPE_PLANNER.video_latent_t(num_frames),
        MINIMAX_H3_SHAPE_PLANNER.audio_latent_t(num_frames / fps),
    )


def _resolve_task(
    extra_args: Mapping[str, Any],
    multi_modal_data: Mapping[str, Any],
) -> str:
    requested = extra_args.get("task")
    if requested is not None:
        return str(requested).lower()
    has_reference_audio = (
        multi_modal_data.get("audio") is not None and extra_args.get("audio_mode", "native") != "lock_source"
    )
    if multi_modal_data.get("video") is not None or has_reference_audio:
        return "ref2va"
    if multi_modal_data.get("image") is not None:
        return "fl2va"
    return "t2va"


def _prepare_encoder_images(
    task: str,
    images: list[Image.Image],
    *,
    height: int,
    width: int,
    guided: bool = False,
) -> list[Any]:
    if not images:
        return []
    if task == "ref2va":
        # Guided references are kept within the output area: they ride through
        # every denoising step next to the guide anchors.
        max_area = width * height if guided else None
        return [
            image.resize(
                resolve_minimax_h3_reference_image_shape(image, max_area=max_area),
                Image.Resampling.LANCZOS,
            )
            for image in images
        ]
    if task != "fl2va":
        return images
    return [image.resize((width, height), Image.Resampling.LANCZOS) for image in images]


def _image_to_tensor(image: Image.Image) -> torch.Tensor:
    array = np.asarray(image.convert("RGB"), dtype=np.uint8)
    return torch.from_numpy(np.array(array, copy=True)).contiguous()


def _frames_to_tensor(frames: Sequence[Any]) -> torch.Tensor:
    if len(frames) == 0:
        raise ValueError("MiniMax H3 reference video must contain frames")
    if isinstance(frames, np.ndarray) and frames.dtype == np.uint8 and frames.ndim == 4 and frames.shape[-1] == 3:
        # Keep the existing owned, contiguous output without converting each RGB frame through PIL.
        return torch.from_numpy(np.array(frames, copy=True, order="C"))
    return torch.stack(
        [
            _image_to_tensor(frame if isinstance(frame, Image.Image) else Image.fromarray(np.asarray(frame)))
            for frame in frames
        ]
    )


def _contains_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return True
    if isinstance(value, torch.Tensor):
        return value.dtype == torch.bool
    return isinstance(value, (list, tuple)) and any(_contains_bool(item) for item in value)


def _edit_mask(value: Any, *, name: str) -> torch.Tensor:
    if _contains_bool(value):
        raise OmniClientError(f"MiniMax H3 {name} must not contain booleans")
    try:
        mask = torch.as_tensor(value, dtype=torch.float32)
    except (TypeError, ValueError, RuntimeError, OverflowError) as exc:
        raise OmniClientError(f"MiniMax H3 {name} must be a finite numeric tensor") from exc
    if mask.numel() == 0 or not bool(torch.isfinite(mask).all().item()):
        raise OmniClientError(f"MiniMax H3 {name} must be non-empty and finite")
    if bool(((mask < 0.0) | (mask > 1.0)).any().item()):
        raise OmniClientError(f"MiniMax H3 {name} values must be in [0, 1]")
    return mask


def _canonical_video_edit_mask(
    value: Any,
    *,
    latent_t: int,
    latent_h: int,
    latent_w: int,
    num_frames: int,
) -> torch.Tensor:
    """Normalize every accepted request shape, including raw frame-space masks, to one full latent grid."""
    mask = _edit_mask(value, name="video_noise_mask")
    token_shape = (latent_t, latent_h // 2, latent_w // 2)
    full_shape = (latent_t, latent_h, latent_w)
    row_count = math.prod(token_shape)
    candidate = mask
    while True:
        if candidate.ndim == 0:
            return candidate.expand(full_shape).contiguous()
        if candidate.ndim == 1 and candidate.numel() == row_count:
            candidate = candidate.reshape(token_shape)
        if tuple(candidate.shape) == token_shape:
            return candidate.repeat_interleave(2, dim=1).repeat_interleave(2, dim=2).contiguous()
        if tuple(candidate.shape) == full_shape:
            return candidate.contiguous()
        if not candidate.ndim or candidate.shape[0] != 1:
            break
        candidate = candidate.squeeze(0)
    if candidate.ndim in (2, 3):
        return _resize_video_edit_mask(
            candidate,
            latent_t=latent_t,
            latent_h=latent_h,
            latent_w=latent_w,
            num_frames=num_frames,
        )
    raise OmniClientError(
        "MiniMax H3 video_noise_mask shape must be "
        f"scalar, ({row_count},), {token_shape}, {full_shape}, [H, W], or [T, H, W]; got {tuple(mask.shape)}"
    )


def _resize_video_edit_mask(
    mask: torch.Tensor,
    *,
    latent_t: int,
    latent_h: int,
    latent_w: int,
    num_frames: int,
) -> torch.Tensor:
    """Resize a raw ``[H, W]`` or frame-space ``[T, H, W]`` mask to ``[latent_t, latent_h, latent_w]``."""
    if mask.ndim == 2:
        mask = mask.unsqueeze(0)
    grid = torch.nn.functional.interpolate(mask.unsqueeze(1), size=(latent_h, latent_w), mode="area").squeeze(1)
    if grid.shape[0] == 1:
        return grid.expand(latent_t, latent_h, latent_w).contiguous()
    # Fit to the output length the way the source video is fitted, so the edit boundary does not drift.
    if grid.shape[0] < num_frames:
        grid = torch.cat([grid, grid[-1:].expand(num_frames - grid.shape[0], *grid.shape[1:])], dim=0)
    return _temporal_group_max_pool(grid[:num_frames], latent_t=latent_t)


def _temporal_group_max_pool(mask: torch.Tensor, *, latent_t: int) -> torch.Tensor:
    """Max-pool frames onto the latents the causal video VAE encodes them into."""
    clip = 17
    frame_count = mask.shape[0]
    num_chunks = -(-frame_count // clip)
    padded = num_chunks * clip
    if frame_count < padded:
        mask = torch.cat([mask, mask[-1:].expand(padded - frame_count, *mask.shape[1:])], dim=0)
    tokens: list[torch.Tensor] = []
    for c in range(num_chunks):
        chunk = mask[c * clip : (c + 1) * clip]
        # Per 17-frame clip, token 0 covers frame 0 and token k covers frames 4k-3..4k; the VAE drops the last 3.
        tokens.append(chunk[0:1].amax(dim=0))
        for k in range(1, 5):
            tokens.append(chunk[4 * k - 3 : 4 * k + 1].amax(dim=0))
    result = torch.stack(tokens)[:-3]
    if result.shape[0] != latent_t:
        raise OmniClientError(
            f"MiniMax H3 video_noise_mask temporal depth {frame_count} does not map to {latent_t} latents"
        )
    return result


def _frames_to_audio_t(frames: int) -> int:
    return round(frames * 5 / 3)


def _frame_latents(num_frames: int) -> torch.Tensor:
    """The causal-VAE latent each pixel frame of a ``17n+5`` clip encodes into."""
    frames = torch.arange(num_frames)
    return 5 * (frames // 17) + (frames % 17 + 3) // 4


def _continuation_video_edit_mask(
    value: Any,
    *,
    requested_frames: int,
    output_frames: int,
    overlap: int,
    latent_h: int,
    latent_w: int,
) -> torch.Tensor:
    """Map a mask written for the requested clip onto a window that hides ``overlap`` frames first.

    The mask is read in the geometry the request describes, expanded to its
    pixel frames, stretched onto the returned frames, and pooled with a
    regenerated (1) overlap in front, so every accepted shape keeps its meaning.
    """
    requested_latent_t = (requested_frames - 5) // 17 * 5 + 2
    latents = _canonical_video_edit_mask(
        value, latent_t=requested_latent_t, latent_h=latent_h, latent_w=latent_w, num_frames=requested_frames
    )
    frames = latents[_frame_latents(requested_frames)]
    frames = frames[(torch.arange(output_frames) * requested_frames) // output_frames]
    window = torch.cat((frames.new_ones((overlap, latent_h, latent_w)), frames))
    return _temporal_group_max_pool(window, latent_t=(overlap + output_frames - 5) // 17 * 5 + 2)


def _continuation_audio_edit_mask(
    value: Any,
    *,
    requested_audio_t: int,
    output_audio_t: int,
    overlap_audio_t: int,
) -> torch.Tensor:
    """Audio counterpart of :func:`_continuation_video_edit_mask` on the 40-Hz latent grid."""
    mask = _canonical_audio_edit_mask(value, audio_t=requested_audio_t)
    mask = mask[:, (torch.arange(output_audio_t) * requested_audio_t) // output_audio_t]
    return torch.cat((mask.new_ones((2, overlap_audio_t)), mask), dim=1)


def _canonical_audio_edit_mask(value: Any, *, audio_t: int) -> torch.Tensor:
    """Normalize every accepted request shape to a channel-major grid."""
    mask = _edit_mask(value, name="audio_noise_mask")
    row_count = 2 * audio_t
    candidate = mask
    while True:
        if candidate.ndim == 0:
            return candidate.expand(2, audio_t).contiguous()
        if candidate.ndim == 1 and candidate.numel() == audio_t:
            return candidate.expand(2, audio_t).contiguous()
        if candidate.ndim == 1 and candidate.numel() == row_count:
            return candidate.reshape(2, audio_t).contiguous()
        if tuple(candidate.shape) == (2, audio_t):
            return candidate.contiguous()
        if not candidate.ndim or candidate.shape[0] != 1:
            break
        candidate = candidate.squeeze(0)
    raise OmniClientError(
        "MiniMax H3 audio_noise_mask shape must be "
        f"scalar, ({audio_t},), (2, {audio_t}), or ({row_count},); got {tuple(mask.shape)}"
    )


def _fit_audio_edit_rows(
    rows: torch.Tensor,
    source_audio_t: int,
    *,
    target_audio_t: int,
) -> tuple[torch.Tensor, int]:
    """Pad or trim channel-major clean source rows to the generated duration."""
    if rows.ndim != 2 or rows.shape[0] % 2 or rows.shape[1] != 32:
        raise ValueError("MiniMax H3 audio edit rows must have shape [2 * audio_t, 32]")
    encoded_audio_t = int(rows.shape[0]) // 2
    if not 0 < source_audio_t <= encoded_audio_t:
        raise ValueError(f"MiniMax H3 source audio length must be in [1, {encoded_audio_t}]")
    copied_t = min(source_audio_t, target_audio_t)
    source = rows.reshape(2, encoded_audio_t, 32)
    fitted = rows.new_zeros((2, target_audio_t, 32))
    fitted[:, :copied_t] = source[:, :copied_t]
    return fitted.reshape(2 * target_audio_t, 32).contiguous(), copied_t


def _reuse_prepared_reference_videos(
    prepared: list[dict[str, Any]] | None,
    *,
    expected_count: int,
) -> list[dict[str, Any]] | None:
    if prepared is None:
        return None
    if len(prepared) != expected_count:
        raise OmniClientError("MiniMax H3 prepared-reference-video count does not match the request")
    for item in prepared:
        if not os.path.isfile(item["prepared_path"]):
            raise OmniClientError(f"MiniMax H3 prepared reference video is unavailable: {item['prepared_path']}")
    return prepared


@dataclass(frozen=True)
class PreparedEncoderInputs:
    """CPU-owned media and Qwen presentation inputs, independent of a runner."""

    prompt: str
    media: MiniMaxH3EncoderMediaInput
    images: list[Image.Image]
    qwen_videos: list[tuple[np.ndarray, dict[str, Any]]]
    video_timestamps: list[list[float]]
    condition_labels: list[tuple[str, int]]


def _effective_audio_inputs(
    video_audios: Sequence[tuple[torch.Tensor, int] | None],
    standalone_audios: Sequence[tuple[torch.Tensor, int]],
    *,
    max_standalone_seconds: float,
) -> list[tuple[torch.Tensor, int]]:
    """Return the waveforms exactly as the audio WVAE will consume them."""
    if not math.isfinite(max_standalone_seconds) or max_standalone_seconds <= 0:
        raise ValueError("max_standalone_seconds must be positive and finite")
    audio_inputs = [item for item in video_audios if item is not None]
    audio_inputs.extend(
        (waveform[..., : int(round(max_standalone_seconds * sample_rate))], sample_rate)
        for waveform, sample_rate in standalone_audios
    )
    return audio_inputs


def prepare_encoder_inputs(
    prompt: Any,
    sampling: Any,
    *,
    task: str | None = None,
    prepared_reference_videos: list[dict[str, Any]] | None = None,
) -> PreparedEncoderInputs:
    """Decode references once and prepare the shared text/codec presentation."""
    if isinstance(prompt, str):
        prompt = {"prompt": prompt}
    if not isinstance(prompt, dict):
        raise TypeError(f"MiniMax H3 expects a string or dict prompt, got {type(prompt)!r}")

    text = str(prompt.get("prompt") or "")
    if not text:
        raise OmniClientError("MiniMax H3 requires a non-empty prompt")
    multi_modal_data = prompt.get("multi_modal_data") or {}
    if not isinstance(multi_modal_data, Mapping):
        raise TypeError("multi_modal_data must be a mapping")

    image_values = _items(multi_modal_data.get("image"))
    videos = _items(multi_modal_data.get("video"))
    raw_audio = multi_modal_data.get("audio")
    audio_values = _audio_items(raw_audio)
    diffusion_sampling_params = sampling
    extra_args = getattr(diffusion_sampling_params, "extra_args", None) or {}
    audio_mode = extra_args.get("audio_mode", "native")
    if audio_mode not in ("native", "lock_source"):
        raise OmniClientError("MiniMax H3 audio_mode must be native or lock_source")
    lock_audio = audio_mode == "lock_source"
    if lock_audio and len(audio_values) != 1:
        raise OmniClientError("MiniMax H3 lock_source requires exactly one driving audio")
    task = task if task is not None else _resolve_task(extra_args, multi_modal_data)
    raw_images = load_minimax_h3_images(image_values) if image_values else []

    if task == "t2va":
        if raw_images or videos or (audio_values and not lock_audio):
            raise OmniClientError("t2va does not accept image, video, or audio conditions")
    elif task == "fl2va":
        if not raw_images or videos or (audio_values and not lock_audio):
            raise OmniClientError("fl2va requires image conditions only")
        if len(raw_images) > 2:
            raise OmniClientError("fl2va accepts at most first and last images")
        for image in raw_images:
            _validate_reference_image(image)
    elif task == "ref2va":
        latent_continuation = extra_args.get("continue_from") is not None
        _validate_ref2va_reference_counts(
            len(raw_images), len(videos), len(audio_values), latent_continuation=latent_continuation
        )
        if not raw_images and not videos and not latent_continuation:
            raise OmniClientError("ref2va requires an image or video condition")
    else:
        raise OmniClientError(f"unsupported MiniMax H3 task {task!r}")

    height, width, num_frames, latent_t, audio_t = resolve_minimax_h3_shape(
        task,
        diffusion_sampling_params,
        raw_images[0] if raw_images else None,
    )
    source_video = multi_modal_data.get("source_video")
    source_audio = multi_modal_data.get("source_audio")
    raw_video_edit_mask = multi_modal_data.get("video_noise_mask")
    raw_audio_edit_mask = multi_modal_data.get("audio_noise_mask")
    regenerate = extra_args.get("regenerate", False)
    if not isinstance(regenerate, bool):
        raise OmniClientError("MiniMax H3 regenerate must be a boolean")
    if regenerate:
        if task != "t2va" or source_video is None or source_audio is not None:
            raise OmniClientError("MiniMax H3 regenerate takes a prompt and one source_video draft")
        if raw_video_edit_mask is not None or raw_audio_edit_mask is not None:
            raise OmniClientError("MiniMax H3 regenerate does not take noise masks")
        if resolve_continuation_request(extra_args) is not None:
            # A 2K regenerate leaves the base canvas a continuation must share.
            raise OmniClientError("MiniMax H3 regenerate does not support continue_from")
        # The draft travels as a latent-edit source with nothing to regenerate:
        # both the local and the staged encoder layouts already carry clean
        # source rows with their mask, and the DiT reads them as the draft.
        raw_video_edit_mask = 0.0
    if (source_video is not None or source_audio is not None) and (
        raw_video_edit_mask is None and raw_audio_edit_mask is None
    ):
        raise OmniClientError("MiniMax H3 edit sources require video_noise_mask or audio_noise_mask")
    # A continuation samples a window whose first ``overlap`` frames are hidden;
    # every frame-addressed input below refers to the returned frames after it.
    continuation = resolve_continuation_request(extra_args)
    overlap = continuation.overlap_frames if continuation is not None else 0
    output_frames = num_frames - overlap
    requested_frames = (
        resolve_minimax_h3_shape(
            task, diffusion_sampling_params, raw_images[0] if raw_images else None, continuation_window=False
        )[2]
        if continuation is not None
        else num_frames
    )
    video_edit_mask = None
    if raw_video_edit_mask is not None:
        video_edit_mask = (
            _continuation_video_edit_mask(
                raw_video_edit_mask,
                requested_frames=requested_frames,
                output_frames=output_frames,
                overlap=overlap,
                latent_h=height // 16,
                latent_w=width // 16,
            )
            if continuation is not None
            else _canonical_video_edit_mask(
                raw_video_edit_mask,
                latent_t=latent_t,
                latent_h=height // 16,
                latent_w=width // 16,
                num_frames=num_frames,
            )
        )
    audio_edit_mask = None
    if raw_audio_edit_mask is not None:
        audio_edit_mask = (
            _continuation_audio_edit_mask(
                raw_audio_edit_mask,
                requested_audio_t=_frames_to_audio_t(requested_frames),
                output_audio_t=audio_t - _frames_to_audio_t(overlap),
                overlap_audio_t=_frames_to_audio_t(overlap),
            )
            if continuation is not None
            else _canonical_audio_edit_mask(raw_audio_edit_mask, audio_t=audio_t)
        )
    # An all-generate mask has no clean source dependency and remains a no-op.
    if video_edit_mask is not None and bool(torch.all(video_edit_mask == 1.0).item()):
        video_edit_mask = None
    if audio_edit_mask is not None and bool(torch.all(audio_edit_mask == 1.0).item()):
        audio_edit_mask = None
    if resolve_long_video_mode(extra_args, task) == "continuation" and (
        video_edit_mask is not None or audio_edit_mask is not None
    ):
        raise OmniClientError("MiniMax H3 continuation does not support latent-mask editing; use long_video_mode=full")
    if lock_audio and audio_edit_mask is not None:
        raise OmniClientError("MiniMax H3 audio_mode=lock_source cannot be combined with audio latent-mask editing")
    if video_edit_mask is not None and source_video is None:
        raise OmniClientError("MiniMax H3 video_noise_mask requires source_video")
    if audio_edit_mask is not None and source_audio is None and source_video is None:
        raise OmniClientError("MiniMax H3 audio_noise_mask requires source_audio or source_video")

    raw_guides = multi_modal_data.get(MINIMAX_H3_TIMELINE_GUIDES_KEY)
    if raw_guides is not None:
        # Guides change the packed layout, so every feature that rebuilds or
        # extends that layout is rejected before any media is decoded.
        if resolve_long_video_mode(extra_args, task) == "continuation":
            raise OmniClientError("MiniMax H3 timeline guides do not support continuation; use long_video_mode=full")
        if video_edit_mask is not None or audio_edit_mask is not None:
            raise OmniClientError("MiniMax H3 timeline guides cannot be combined with latent-mask editing")
        if lock_audio:
            raise OmniClientError("MiniMax H3 timeline guides cannot be combined with audio_mode=lock_source")
    if continuation is not None and isinstance(raw_guides, Sequence) and not isinstance(raw_guides, (str, bytes)):
        raw_guides = [
            {**guide, "frame_index": window_frame_index(guide["frame_index"], overlap)}
            if isinstance(guide, Mapping) and type(guide.get("frame_index")) is int
            else guide
            for guide in raw_guides
        ]
    timeline_guides = prepare_timeline_guides(raw_guides, width=width, height=height, num_frames=num_frames)

    images = _prepare_encoder_images(
        task,
        raw_images,
        height=height,
        width=width,
        guided=bool(timeline_guides),
    )
    keyframe_indices = _resolve_fl2va_keyframe_indices(extra_args, len(images)) if task == "fl2va" else []
    video_timestamps: list[list[float]] = []
    qwen_video_inputs: list[tuple[np.ndarray, dict[str, Any]]] = []
    condition_labels: list[tuple[str, int]] = []
    encoded_video_inputs: list[torch.Tensor] = []
    video_audio_inputs: list[tuple[torch.Tensor, int] | None] = []

    if task == "fl2va":
        condition_labels.extend(("image", index) for index in range(1, len(images) + 1))
    elif task == "ref2va":
        condition_labels.extend(("image", index) for index in range(1, len(images) + 1))
        prepared_videos: list[dict[str, Any]] = []
        if videos:
            with tempfile.TemporaryDirectory(prefix="minimax_h3_encoder_") as workdir:
                prepared_videos = _reuse_prepared_reference_videos(
                    prepared_reference_videos, expected_count=len(videos)
                )
                if prepared_videos is None:
                    prepared_videos = prepare_reference_videos(
                        videos,
                        target_frame_count=num_frames,
                        workdir=workdir,
                        start_time_seconds=extra_args.get("start_time_seconds"),
                    )
                audio_pool = ThreadPoolExecutor(max_workers=1)
                try:
                    audio_futures = [
                        audio_pool.submit(
                            load_video_audio,
                            item["original_path"],
                            start_time_seconds=float(item.get("start_time_seconds", 0.0)),
                            duration_seconds=item.get(
                                "audio_duration_seconds",
                                item.get("duration_seconds"),
                            ),
                        )
                        if item["input_has_audio"]
                        else None
                        for item in prepared_videos
                    ]
                    for item, audio_future in zip(prepared_videos, audio_futures):
                        full_frames = load_video_frames(item["prepared_path"])
                        encoded_video_inputs.append(_frames_to_tensor(full_frames))
                        sampled = sample_reference_video_frames(
                            item["prepared_path"],
                            decoded_frames=full_frames,
                        )
                        video_timestamps.append(sampled["block_timestamps"])
                        frames = np.stack(sampled["frames"])
                        frame_count = int(frames.shape[0])
                        qwen_video_inputs.append(
                            (
                                frames,
                                {
                                    "total_num_frames": frame_count,
                                    "fps": MINIMAX_H3_QWEN_VIDEO_SAMPLE_FPS,
                                    "duration": frame_count / MINIMAX_H3_QWEN_VIDEO_SAMPLE_FPS,
                                    "video_backend": "minimax_h3",
                                    "frames_indices": list(range(frame_count)),
                                    "do_sample_frames": False,
                                },
                            )
                        )
                        if audio_future is not None:
                            waveform, sample_rate = audio_future.result()
                            video_audio_inputs.append((waveform.float().contiguous(), int(sample_rate)))
                        else:
                            video_audio_inputs.append(None)
                finally:
                    audio_pool.shutdown(wait=True, cancel_futures=True)
        audio_index = 0
        for video_index, item in enumerate(prepared_videos, start=1):
            if item["input_has_audio"]:
                audio_index += 1
                condition_labels.append(("audio", audio_index))
            condition_labels.append(("video", video_index))
        for _ in [] if lock_audio else audio_values:
            audio_index += 1
            condition_labels.append(("audio", audio_index))

    video_edit: torch.Tensor | None = None
    edit_video_metadata: dict[str, Any] | None = None
    if video_edit_mask is not None:
        with tempfile.TemporaryDirectory(prefix="minimax_h3_edit_") as workdir:
            try:
                edit_video_metadata = prepare_edit_video(
                    source_video,
                    target_width=width,
                    target_height=height,
                    target_frame_count=output_frames,
                    workdir=workdir,
                    cover=regenerate,
                )
                edit_video_frames = load_video_frames(edit_video_metadata["prepared_path"])
            except subprocess.CalledProcessError as exc:
                raise OmniClientError("MiniMax H3 could not decode source_video for editing") from exc
            video_edit = _frames_to_tensor(edit_video_frames)
            if overlap:
                # The hidden overlap is regenerated (mask 1); its source frames are placeholders.
                video_edit = torch.cat((video_edit[:1].expand(overlap, *video_edit.shape[1:]), video_edit))
    if regenerate and edit_video_metadata is not None:
        if edit_video_metadata["input_has_audio"]:
            # Keep the draft's soundtrack for the output; the refiner never sees it.
            audio_edit_mask = torch.zeros(2, audio_t)
        else:
            logger.warning("Open-H3-Regenerate draft has no audio track; the regenerated video will be silent")

    audio_edit: tuple[torch.Tensor, int] | None = None
    if audio_edit_mask is not None:
        if source_audio is not None:
            try:
                waveform, sample_rate = _load_audio(source_audio)
            except subprocess.CalledProcessError as exc:
                raise OmniClientError("MiniMax H3 could not decode source_audio for editing") from exc
        else:
            if edit_video_metadata is not None and not edit_video_metadata["input_has_audio"]:
                raise OmniClientError("MiniMax H3 source_video has no audio track for audio editing")
            try:
                waveform, sample_rate = load_video_audio(
                    str(source_video),
                    duration_seconds=float(output_frames) / MINIMAX_H3_FPS,
                )
            except subprocess.CalledProcessError as exc:
                raise OmniClientError("MiniMax H3 could not decode source_video audio for editing") from exc
        if waveform.ndim not in (1, 2) or int(sample_rate) <= 0:
            raise OmniClientError("MiniMax H3 edit audio requires a waveform and positive sample rate")
        max_samples = max(1, int(round(float(output_frames) / MINIMAX_H3_FPS * int(sample_rate))))
        waveform = waveform[..., :max_samples].float().contiguous()
        if waveform.shape[-1] == 0:
            raise OmniClientError("MiniMax H3 edit audio must not be empty")
        if overlap:
            # Silence under the hidden overlap, which the audio mask regenerates.
            silence = waveform.new_zeros((*waveform.shape[:-1], int(round(overlap / MINIMAX_H3_FPS * sample_rate))))
            waveform = torch.cat((silence, waveform), dim=-1)
        audio_edit = (waveform, int(sample_rate))

    if raw_audio is not None and not lock_audio:
        validate_reference_audio_files(raw_audio)
    standalone_audios = _load_audios(raw_audio) if raw_audio is not None else []
    if lock_audio:
        waveform, rate = standalone_audios[0]
        if rate <= 0 or waveform.ndim not in (1, 2) or waveform.numel() == 0 or not torch.isfinite(waveform).all():
            raise OmniClientError("MiniMax H3 driving audio must be a finite non-empty waveform with a positive rate")
    else:
        validate_reference_audio_waveforms(standalone_audios)
    media_input = MiniMaxH3EncoderMediaInput(
        task=task,
        height=height,
        width=width,
        num_frames=num_frames,
        latent_t=latent_t,
        audio_t=audio_t,
        images=tuple(_image_to_tensor(image) for image in images),
        videos=tuple(encoded_video_inputs),
        video_audios=tuple(video_audio_inputs),
        audios=tuple((waveform.float().contiguous(), int(sample_rate)) for waveform, sample_rate in standalone_audios),
        keyframe_frame_indices=tuple(keyframe_indices),
        audio_mode=audio_mode,
        video_edit=video_edit,
        video_edit_mask=video_edit_mask,
        audio_edit=audio_edit,
        audio_edit_mask=audio_edit_mask,
        timeline_guides=timeline_guides,
    )
    audio_inputs = _effective_audio_inputs(
        media_input.video_audios,
        media_input.audios,
        max_standalone_seconds=float(media_input.num_frames) / MINIMAX_H3_FPS,
    )
    embedded_audio_count = sum(item is not None for item in media_input.video_audios)
    # Video soundtracks and standalone references have separate 15-second budgets.
    validate_reference_audio_waveforms(audio_inputs[:embedded_audio_count])
    if not lock_audio:
        validate_reference_audio_waveforms(audio_inputs[embedded_audio_count:])

    return PreparedEncoderInputs(
        prompt=text,
        media=media_input,
        images=images,
        qwen_videos=qwen_video_inputs,
        video_timestamps=video_timestamps,
        condition_labels=condition_labels,
    )


def _image_from_tensor(value: torch.Tensor) -> Image.Image:
    if value.ndim != 3 or value.shape[-1] != 3:
        raise ValueError(f"MiniMax H3 image tensor must have shape [H, W, 3], got {tuple(value.shape)}")
    array = value.detach().cpu().to(torch.uint8).contiguous().numpy()
    return Image.fromarray(array, mode="RGB")


def _encode_guide_frames(guide: MiniMaxH3TimelineGuide, video_vae: Any, height: int, width: int) -> torch.Tensor | None:
    if guide.frames is None:
        return None
    frames = guide.frames.detach().cpu().to(torch.uint8).contiguous()
    if guide.is_clip:
        rows, shape = video_vae.encode_video(np.asarray(frames.numpy()))
        latent_t = int(shape[0])
    else:
        rows = video_vae.encode_image(_image_from_tensor(frames[0]))
        latent_t = 1
    if tuple(rows.shape) != (latent_t * (height // 32) * (width // 32), 96):
        raise ValueError(f"MiniMax H3 timeline guide VAE returned rows {tuple(rows.shape)}")
    return rows.to(dtype=torch.float32).contiguous()


def _timeline_guide_conditioning(
    media: MiniMaxH3EncoderMediaInput,
    visual_rows: Sequence[torch.Tensor | None],
    *,
    audio_vae: Any,
    component_scope: Callable[[Any], AbstractContextManager[Any]],
) -> tuple[tuple[dict[str, Any], ...], torch.Tensor | None, torch.Tensor | None]:
    """Build ordered guide blocks with their visual and audio anchor rows."""
    if not media.timeline_guides:
        return (), None, None
    latent_h, latent_w = media.height // 16, media.width // 16
    frame_rows = (latent_h // 2) * (latent_w // 2)
    blocks: list[dict[str, Any]] = []
    audio_rows: list[torch.Tensor] = []
    for guide, rows in zip(media.timeline_guides, visual_rows, strict=True):
        block: dict[str, Any] = {"frame_index": int(guide.start)}
        if rows is not None:
            block.update(
                kind="video" if guide.is_clip else "image",
                latent_t=rows.shape[0] // frame_rows,
                latent_h=latent_h,
                latent_w=latent_w,
                ref_audio_t=0,
            )
        if guide.audio is not None:
            if audio_vae is None:
                raise RuntimeError("MiniMax H3 audio WVAE is not resident on the encoder leader")
            with component_scope(audio_vae):
                encoded, length = audio_vae.encode_waveform(*guide.audio)
            length = int(length)
            if length < 1 or tuple(encoded.shape) != (2 * length, 32):
                raise ValueError("MiniMax H3 timeline guide audio VAE returned empty or invalid stereo rows")
            # Rows are channel-major: crop time per channel, not the flat prefix.
            cropped = min(length, guide.audio_limit)
            audio_rows.append(encoded.reshape(2, length, 32)[:, :cropped].reshape(-1, 32).to(torch.float32))
            block.update(kind="video_audio" if rows is not None else "audio", ref_audio_t=cropped)
        blocks.append(block)
    present = [rows for rows in visual_rows if rows is not None]
    return (
        tuple(blocks),
        torch.cat(present).contiguous() if present else None,
        torch.cat(audio_rows).contiguous() if audio_rows else None,
    )


def encode_media(
    media: MiniMaxH3EncoderMediaInput,
    *,
    video_vae: Any,
    audio_vae: Any,
    emit_conditioning: bool,
    component_scope: Callable[[Any], AbstractContextManager[Any]] = nullcontext,
) -> MiniMaxH3EncoderMediaConditioning | None:
    """Run codecs on participating ranks; only the output rank runs audio.

    The caller selects participating ranks and configures the VAE process group.
    Every visual participant must call this function with the same references.
    Component scopes allow the diffusion runner to stage one codec at a time.
    """
    # Validate before the non-leader return so all participants reject bad input.
    audio_inputs = _effective_audio_inputs(
        media.video_audios,
        media.audios,
        max_standalone_seconds=float(media.num_frames) / MINIMAX_H3_FPS,
    )
    embedded_audio_count = sum(item is not None for item in media.video_audios)
    validate_reference_audio_waveforms([item for item in media.video_audios if item is not None])
    if media.audio_mode != "lock_source":
        validate_reference_audio_waveforms(media.audios)
    visual_rows: list[torch.Tensor] = []
    visual_shapes: list[tuple[int, int, int]] = []
    video_edit_clean_rows: torch.Tensor | None = None
    guide_visual_rows: list[torch.Tensor | None] = [None] * len(media.timeline_guides)
    has_guide_frames = any(guide.frames is not None for guide in media.timeline_guides)
    if media.images or media.videos or media.video_edit is not None or has_guide_frames:
        if video_vae is None:
            raise RuntimeError("MiniMax H3 video VAE is not resident on this rank")
        with component_scope(video_vae):
            for value in media.images:
                image = _image_from_tensor(value)
                visual_rows.append(video_vae.encode_image(image))
                visual_shapes.append((1, image.height // 16, image.width // 16))
            for value in media.videos:
                frames = np.asarray(value.detach().cpu().to(torch.uint8).contiguous().numpy())
                rows, shape = video_vae.encode_video(frames)
                visual_rows.append(rows)
                visual_shapes.append(tuple(int(item) for item in shape))
            if media.video_edit is not None:
                frames = np.asarray(media.video_edit.detach().cpu().to(torch.uint8).contiguous().numpy())
                rows, shape = video_vae.encode_video(frames)
                shape = tuple(int(item) for item in shape)
                expected_shape = (media.latent_t, media.height // 16, media.width // 16)
                expected_rows = media.latent_t * (media.height // 32) * (media.width // 32)
                if shape != expected_shape or tuple(rows.shape) != (expected_rows, 96):
                    raise ValueError(
                        "MiniMax H3 video edit encoder shape mismatch: "
                        f"got latent shape {shape} and rows {tuple(rows.shape)}, "
                        f"expected {expected_shape} and ({expected_rows}, 96)"
                    )
                video_edit_clean_rows = rows.to(dtype=torch.float32).contiguous()
            # Guide stills and clips share the video VAE collective with the
            # references, so every visual participant encodes them as well.
            guide_visual_rows = [
                _encode_guide_frames(guide, video_vae, media.height, media.width) for guide in media.timeline_guides
            ]

    if not emit_conditioning:
        return None

    audio_rows: list[torch.Tensor] = []
    audio_lengths: list[int] = []
    audio_edit_clean_rows: torch.Tensor | None = None
    audio_edit_source_t = 0
    if audio_inputs or media.audio_edit is not None:
        if audio_vae is None:
            raise RuntimeError("MiniMax H3 audio WVAE is not resident on the encoder leader")
        with component_scope(audio_vae):
            for waveform, sample_rate in audio_inputs:
                rows, length = audio_vae.encode_waveform(waveform, sample_rate)
                audio_rows.append(rows)
                audio_lengths.append(int(length))
            if media.audio_edit is not None:
                waveform, sample_rate = media.audio_edit
                rows, source_audio_t = audio_vae.encode_waveform(waveform, sample_rate)
                rows = rows.to(dtype=torch.float32).contiguous()
                audio_edit_clean_rows, audio_edit_source_t = _fit_audio_edit_rows(
                    rows,
                    int(source_audio_t),
                    target_audio_t=media.audio_t,
                )
    guide_blocks, guide_visual, guide_audio = _timeline_guide_conditioning(
        media,
        guide_visual_rows,
        audio_vae=audio_vae,
        component_scope=component_scope,
    )
    reference_lengths = audio_lengths[:-1] if media.audio_mode == "lock_source" else audio_lengths
    if reference_lengths:
        if any(length < 80 or length > 600 for length in reference_lengths):
            raise ValueError("MiniMax H3 audio references must each be between 2 and 15 seconds")
        if sum(reference_lengths[:embedded_audio_count]) > 600 or sum(reference_lengths[embedded_audio_count:]) > 600:
            raise ValueError("MiniMax H3 audio references must be at most 15 seconds in total")

    ref_blocks: list[dict[str, Any]] = []
    image_shapes = visual_shapes[: len(media.images)]
    video_shapes = visual_shapes[len(media.images) :]
    ref_blocks.extend({"kind": "image", "latent_h": shape[1], "latent_w": shape[2]} for shape in image_shapes)
    embedded_lengths = iter(audio_lengths[:embedded_audio_count])
    for shape, embedded in zip(video_shapes, media.video_audios, strict=True):
        ref_audio_t = int(next(embedded_lengths)) if embedded is not None else 0
        ref_blocks.append(
            {
                "kind": "video_audio" if ref_audio_t else "video",
                "ref_audio_t": ref_audio_t,
                "latent_t": shape[0],
                "latent_h": shape[1],
                "latent_w": shape[2],
            }
        )
    ref_blocks.extend(
        {
            "kind": "audio",
            "ref_audio_t": int(length),
        }
        for length in reference_lengths[embedded_audio_count:]
    )
    video_edit_mask = None
    if video_edit_clean_rows is not None:
        if media.video_edit_mask is None:
            raise ValueError("MiniMax H3 video edit rows require a mask")
        video_edit_mask = media.video_edit_mask.to(
            device=video_edit_clean_rows.device,
            dtype=torch.float32,
        ).contiguous()
    audio_edit_mask = None
    if audio_edit_clean_rows is not None:
        if media.audio_edit_mask is None:
            raise ValueError("MiniMax H3 audio edit rows require a mask")
        audio_edit_mask = media.audio_edit_mask.to(
            device=audio_edit_clean_rows.device,
            dtype=torch.float32,
        ).contiguous()
    return MiniMaxH3EncoderMediaConditioning(
        task=media.task,
        height=media.height,
        width=media.width,
        num_frames=media.num_frames,
        latent_t=media.latent_t,
        audio_t=media.audio_t,
        visual_condition=torch.cat(visual_rows) if visual_rows else None,
        visual_condition_shapes=tuple(visual_shapes),
        audio_condition=torch.cat(audio_rows) if audio_rows else None,
        audio_condition_lengths=tuple(audio_lengths),
        ref_blocks=tuple(ref_blocks),
        keyframe_frame_indices=media.keyframe_frame_indices,
        video_edit_clean_rows=video_edit_clean_rows,
        video_edit_mask=video_edit_mask,
        audio_edit_clean_rows=audio_edit_clean_rows,
        audio_edit_mask=audio_edit_mask,
        audio_edit_source_t=audio_edit_source_t,
        guide_blocks=guide_blocks,
        guide_visual_condition=guide_visual,
        guide_audio_condition=guide_audio,
    )
