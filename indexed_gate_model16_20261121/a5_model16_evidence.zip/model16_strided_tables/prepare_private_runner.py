"""Isolated measurement repair, strictly scoped to this model16 operator."""
from pathlib import Path
import hashlib,json,shutil
R=Path(__file__).resolve().parent
S=Path('/home/t00985010/indexed_gate_optimizer_20261117_2125_3908/.agents/skills')
report=json.loads((R/'standard_step_audit.json').read_text())
assert all(x['actual_compute_kernels']==x['declared_public_calls']==20 for x in report)
assert any(x['nonempty_unique_steps']!=20 for x in report)
for name in ('triton-npu-run-eval','triton-npu-optimize-state','triton-npu-profile-operator'):
    shutil.copytree(S/name,R/'.agents/skills'/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'),dirs_exist_ok=False)
p=R/'.agents/skills/triton-npu-run-eval/scripts/profile_csv_parser.py'
text=p.read_text();old='    divisor = aggregation.observed_step_count if aggregation.observed_step_count else active_count'
assert text.count(old)==1
new='''    # Task-local model16 repair: Step Id aliases are not one-to-one with calls.
    # Validate complete chronological public calls before using active_count.
    # This adapter deliberately rejects unrelated operators and incomplete traces.
    validated_calls = 0
    pending_names = []
    group_sizes = set()
    ordered_rows = sorted(rows, key=lambda row: float(row["Start Time(us)"]))
    for row in ordered_rows:
        name = str(row.get("Name", ""))
        if float(row["Duration(us)"]) <= 0:
            raise ValueError("Nonpositive model16 device Duration")
        pending_names.append(name)
        if "_indexed_gate_rms_shift_" in name:
            if len(pending_names) not in (1, 4):
                raise ValueError("Incomplete/extra model16 work kernels")
            if not all("aclnnInplaceCopy" in n for n in pending_names[:-1]):
                raise ValueError("Unexpected work kernel before model16 compute")
            group_sizes.add(len(pending_names))
            validated_calls += 1
            pending_names = []
    if pending_names or len(group_sizes) != 1 or validated_calls != active_count:
        raise ValueError("Unvalidated model16 public-call count; no Step Id fallback")
    divisor = validated_calls'''
p.write_text(text.replace(old,new))
timing=R/'paired_stride.py';pmu=R/'paired_stride_pmu.py';body=timing.read_text()
needle='max(.0002,abs(ratio)*.002)';assert body.count(needle)==1
pmu.write_text(body.replace(needle,'max(.003,abs(ratio)*.002)'))
audit=dict(scope='Task-local isolated runner; shared installed skills and DUT unchanged',standard_trace_proof=report,original_parser_sha256=hashlib.sha256((S/'triton-npu-run-eval/scripts/profile_csv_parser.py').read_bytes()).hexdigest(),private_parser_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),changed_standard_behavior='One fused compute per declared call; parent3 preceding copy kernels or candidate0; strict complete group count, divide by actual validated calls instead of unique Step Id',pmu_ratio_fix='Raw ratio is rounded to3 decimals; verification tolerance0.003 agrees with existing validated model16 PMU collector. Activity values still calculated from raw pipe_time/AIV_time, not rounded ratio.',timing_collector_sha256=hashlib.sha256(timing.read_bytes()).hexdigest(),pmu_collector_sha256=hashlib.sha256(pmu.read_bytes()).hexdigest())
(R/'measurement_repairs.json').write_text(json.dumps(audit,indent=2));print('PRIVATE_RUNNER_READY')
