# api-name: ModelNew
# api-kind: torch-module
# kernels: _indexed_gate_rms_shift_kernel, _indexed_gate_rms_shift_cached_kernel, _indexed_gate_rms_shift_row_kernel, _indexed_gate_rms_shift_two_tile_kernel, _indexed_gate_rms_shift_native_wide_kernel, _indexed_gate_rms_shift_table_kernel
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from model_inputs import CASES,build_inputs
TYPICAL={'model_t2va_smoke_mid_u8_rank0','model_t2va_smoke_step0_u1','model_ref2va_img_audio_mid_u1','model_t2va_recipe209_u1'}
def build_operator_api(operator_module):return operator_module.ModelNew().npu().eval()
def build_bench_cases():return [dict(c,warmup=5,repeats=20) for c in CASES if c['id'] in TYPICAL]
def build_bench_case_fn(operator_api,case):
    data=[build_inputs(case,i) for i in range(2)];index=0
    def call():
        nonlocal index
        inputs=data[index%2];index+=1
        return operator_api(*inputs)
    return call
