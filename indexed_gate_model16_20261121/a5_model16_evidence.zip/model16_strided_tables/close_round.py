from pathlib import Path
import hashlib,json,re,shutil
R=Path(__file__).resolve().parent;Q=R/'opt-round-1'
s=json.loads((R/'strided_model16_summary.json').read_text());assert s['complete'] and s['passed_cases']==s['total_cases']==16
assert hashlib.sha256((Q/'opt_indexed_gate.py').read_bytes()).hexdigest()==s['candidate_sha256']
canonical=(R/'repaired_totalop_view.log').read_text();kernel=(R/'repaired_kernel_view.log').read_text()
assert 'PASS: compared 4 latency entries' in canonical
gm=re.search(r'Geomean speedup:\s*([0-9.]+)x',canonical);assert gm
profile=Q/'profile';profile.mkdir(exist_ok=True)
pmu=json.loads((R/'pmu/results.json').read_text());mapping=[]
for c in pmu['cases']:
    a=next(x for x in c['attempts'] if x['stable']);src=R/a['csv'];dst=profile/c['case_id']/'kernel_details.csv';dst.parent.mkdir(exist_ok=True)
    shutil.copyfile(src,dst);assert hashlib.sha256(dst.read_bytes()).hexdigest()==a['csv_sha256']
    mapping.append(dict(case_id=c['case_id'],original=a['csv'],round_local=str(dst.relative_to(Q)),sha256=a['csv_sha256']))
(profile/'source_map.json').write_text(json.dumps(mapping,indent=2));shutil.copyfile(R/'strided_model16_summary.json',profile/'timing_and_pmu.json')
rows=s['cases'];lines=['A5 model16 direct table-stride round (2026-11-21 Asia/Shanghai)',
'Host179.228.2.2 Ascend950PR_957c physical6/logical0; original old PR machine.',
'Parent source SHA256: '+s['parent_sha256'],'Candidate source SHA256: '+s['candidate_sha256'],
'Change: main fusion loads gate/shift/scale using their original row strides. All16 cases have column stride1,row stride6H. Other5 specialized kernels retain original contiguous behavior.',
'Precision: official npu_compare standalone streaming16/16; typical4/4. No PT output archives generated after resumption.',
'No-PMU matched protocol: same2 input tensors and actual public APIs,2 preconditions,AB/BA + alternating warm/cold,3 retained rounds;20pairs per round,512-row case80pairs.',
'Device metric: sum all actual work-kernel Durations per public call. Parent3 copies+1fusion, candidate1fusion. Eviction,allocation/host launch gaps excluded.',
'Warm no explicit eviction; cold independent1GiB FP32 read+1/write, synchronize before public call. Flush is not proof ofzero L2hits.',
'Full16 geomean parent/candidate: '+json.dumps(s['geomean_parent_over_candidate']),
'Copy calibration: '+json.dumps(s['cache_copy_calibration']),
'Interference: '+json.dumps(s['process_monitoring']),
'Full16 pre/post bandwidth controls: '+json.dumps(s['full_valid_controls']),
'Validated flush-before-work pairs: '+str(s['full_flush_pairs_validated']),
'PMU: fresh same-source parent/candidate;6targets per cache/variant/case. AIV-weighted Vector/Scalar/MTE2/MTE3 activities overlap; no wall-time/MBU/critical-path interpretation. Per-kernel times, weights and counts are in summary JSON.',
'Measurement repair: official scheduled trace has20 actual compute kernels but17 unique Step IDs for candidate largest shape, causing20/17 inflation. Private runner validates complete chronological calls and actual work counts before dividing; shared tools/DUT unchanged. Raw traces and uncorrected artifacts retained.',
'PMU raw ratios have3 decimal rounding. Diagnostic unit-check tolerance follows existing validated0.003 rule; displayed activities remain from raw times/AIV times.',
'Official benchmark (warm typical4): repaired total-op comparison follows; both kernel/total-op logs retained.',canonical,
'L20 reference-only geomean: '+json.dumps(s.get('l20_geomean_reference')),
s.get('l20_caveat',''),
'Original13 accepted results remain bound to parent round9; not remeasured/promoted for the modified source in this model16-only round.',
'Largest63360-row full-run gain is tiny (~noise scale); do not claim a substantial stable single-case speedup there.',
'', 'case (model_ omitted) | rows | warm parent us | warm candidate us | warm parent/candidate | cold parent us | cold candidate us | cold parent/candidate']
for c in rows:
    lines.append(c['case_id'].removeprefix('model_')+' | '+str(c['rows'])+' | '+' | '.join(f'{c[k]:.6f}' for k in ('warm_parent_full_device_us','warm_candidate_full_device_us','warm_parent_over_candidate','cold_parent_full_device_us','cold_candidate_full_device_us','cold_parent_over_candidate')))
lines+=['','Candidate full pipeline V/S/MTE2/MTE3 percentages; each cell warm/cold:']
for c in rows:
    warm=c['per_kernel_pmu']['warm']['candidate']['pmu']['activity_pct'];cold=c['per_kernel_pmu']['cold']['candidate']['pmu']['activity_pct']
    lines.append(c['case_id'].removeprefix('model_')+' | '+' | '.join(f'{warm[p]:.2f}/{cold[p]:.2f}' for p in ('Vector','Scalar','MTE2','MTE3')))
(R/'report.txt').write_text('\n'.join(lines)+'\n')
summary=f'''# Direct table row-stride loads\n\nParent: baseline = accepted round9 source `{s['parent_sha256']}`.\nCandidate: `{s['candidate_sha256']}`.\nHypothesis: eliminate3 materialization kernels by addressing original row strides in the main fusion.\nPattern: self-directed user-requested materialization elimination; no named KB pattern.\nPrimary analysis level: source and existing board profiler evidence.\nSupporting evidence: parent4 work kernels/call, candidate1; normalized main math AST unchanged, other5 kernel ASTs unchanged.\nFinal analysis level: same-card paired no-PMU device time plus fresh per-kernel PMU and standard-profile step-count audit; no IR/compiler-source claims.\n\nCorrectness: typical4/4,full16/16 official NPU contract with independent existing Torch oracle, streaming without PT files.\nUser metric: complete-call device Duration sum, matched2 inputs, both cache modes. Full16 geometric speedup {s['geomean_parent_over_candidate']['warm']:.8f}x warm and{s['geomean_parent_over_candidate']['cold']:.8f}x cold.\nCanonical run-bench typical4 total-op geomean:{gm.group(1)}x. Both canonical views passed after isolated repeat-count repair.\n\nObservation: small/medium cases improve;63360-row gain is near noise, not a substantial per-case improvement.\nAttribution:3 measured copy kernels disappear, arithmetic/precision preserved.\nScope: model16 original strides; original13 performance remains historical parent data.\nConfounders: unique Step Id undercount inflated standard averages; demonstrated with20 actual computes/17 Step IDs, repaired privately with strict call/kernel validation and rerun. Pipeline ratio rounding issue repaired in diagnostic parser only. No corrupted/missing target accepted or Event substitution.\nDisposition: promote as current validated model16 branch; retain parent and all original13 records.\n\nDeep IR analysis skipped because source/trace proves the removed work, actual compiler math is unchanged and paired results repeat. Activities are overlapping engine utilization, not critical-path proof.\n\nArtifacts: [report](../report.txt),[device CSV](../strided_model16_device.csv),[pipeline CSV](../strided_model16_pipeline.csv),[full timing/PMU JSON](../strided_model16_summary.json).\n'''
(Q/'summary.md').write_text(summary)
with (Q/'attempts.md').open('a') as f:f.write('\n## Final evidence\n'+summary)
note=(R/'opt-note.md').read_text();note=note.split('## Overall Summary')[0]
note+=f'''\n## Round1\nParent: baseline (accepted original round9).\nTheme: direct table row-stride addressing eliminates3 copies.\nResult:16/16 precision; full16 matched warm/cold geomean{s['geomean_parent_over_candidate']['warm']:.8f}x/{s['geomean_parent_over_candidate']['cold']:.8f}x; canonical typical4 total-op{gm.group(1)}x.\nBest status: current validated model16 branch; original13 unchanged.\nSummary: [opt-round-1/summary.md](opt-round-1/summary.md)\nAttempts: [opt-round-1/attempts.md](opt-round-1/attempts.md)\n\n## Overall Summary\nFinal best round: opt-round-1 (model16 scope)\nAvg improvement: see canonical total-op comparison; use geometric speedup as primary.\nGeomean speedup:{gm.group(1)}x canonical typical4 total-op; full16 matched device warm/cold{s['geomean_parent_over_candidate']['warm']:.8f}x/{s['geomean_parent_over_candidate']['cold']:.8f}x.\nValidated branches: opt-round-1\nOutcome: eliminated3 table copies with preserved BF16 math and repeated typical gains; largest shape close to parity.\nKey optimization points:\n  1. Direct row strides:4 to1 work kernels/call; full16 warm/cold improvements above (round1).\n'''
(R/'opt-note.md').write_text(note)
round_state=dict(round='opt-round-1',parent_round='baseline',hypothesis='Main fused kernel consumes original table row strides and removes3 materializations',correctness_status='passed',benchmark_status='passed',summary_path='summary.md',opt_note_updated=True,perf_artifact='opt_indexed_gate_perf.txt',comparison_target_path='../baseline/indexed_gate_perf.txt',effective_metric_source='total-op',analysis_skipped_reason='Source and raw traces plus matched timing/PMU suffice; no IR/compiler-source claims',profile_dir='profile',promoted=True,scope='model16 only')
(Q/'round-state.json').write_text(json.dumps(round_state,indent=2))
(R/'learned_lessons.md').write_text('Unique profiler Step Ids may alias actual calls even with per-call synchronization. Validate complete call/kernel groups before normalizing. A3-copy parent may accidentally yield20 unique Step IDs while its1-kernel candidate yields17 for the same20 calls.\nRaw PMU ratio strings are rounded; compute activity from matching pipe_time/AIV_time and validate units with export precision.\n')
print('ROUND_RECORDS_READY',s['geomean_parent_over_candidate'],gm.group(1))
