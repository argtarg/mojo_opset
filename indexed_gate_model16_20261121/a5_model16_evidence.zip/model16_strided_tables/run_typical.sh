#!/bin/bash
source /home/t00985010/indexed_gate_strided_tables_20261121_110935_9e77/environment.sh
cli=/home/t00985010/indexed_gate_optimizer_20261117_2125_3908/.agents/skills/triton-npu-run-eval/scripts/cli.py
python "$cli" run-test-optimize --test-file test_typical.py --operator-file opt-round-1/opt_indexed_gate.py --test-mode standalone --verbose > candidate_typical_test.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > typical_exit.txt; exit "$rc"; fi
python -c 'import pathlib,hashlib,shutil; r=pathlib.Path.cwd(); h=hashlib.sha256((r/"opt-round-1/opt_indexed_gate.py").read_bytes()).hexdigest(); shutil.copyfile(r/"precision_receipts"/(h+"_typical.json"),r/"candidate_typical_receipt.json")'
python calibrate_copy.py before > calibration_before.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > typical_exit.txt; exit "$rc"; fi
python paired_stride.py --phase noise --noise --cases model_t2va_smoke_mid_u8_rank0,model_t2va_smoke_step0_u1 > noise_driver.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > typical_exit.txt; exit "$rc"; fi
typical=model_t2va_smoke_mid_u8_rank0,model_t2va_smoke_step0_u1,model_ref2va_img_audio_mid_u1,model_t2va_recipe209_u1
python paired_stride.py --phase typical --cases "$typical" > typical_driver.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > typical_exit.txt; exit "$rc"; fi
python paired_stride.py --phase confirm --cases "$typical" > confirm_driver.log 2>&1
rc=$?;echo "$rc" > typical_exit.txt
exit "$rc"
