"""Audit paired device/PMU evidence and export compact case-row tables."""
from pathlib import Path
import csv,hashlib,json,math,statistics
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
full=json.loads((R/'full/results.json').read_text());pmu=json.loads((R/'pmu/results.json').read_text());gate=json.loads((R/'typical_screen.json').read_text())
q=json.loads((R/'candidate_full_receipt.json').read_text())
assert gate['expand_to_full16'] and q['passed'] and q['passed_cases']==q['total_cases']==16
parent=R/'baseline/indexed_gate.py';candidate=R/'opt-round-1/opt_indexed_gate.py'
assert q['candidate_sha256']==sha(candidate)==full['candidate_sha256']==pmu['candidate_sha256']==gate['candidate_sha256']
assert full['parent_sha256']==pmu['parent_sha256']==sha(parent)
assert full['complete'] and pmu['complete'] and len(full['cases'])==len(pmu['cases'])==16
assert not full['pmu'] and pmu['pmu']
pmu_by_id={c['case_id']:c for c in pmu['cases']}
controls=[];flush_pairs=0;monitors=[]
for phase in ('noise','typical','confirm','full','pmu'):
    data=json.loads((R/phase/'results.json').read_text());assert data['complete']
    expected=2 if phase=='noise' else 16 if phase in ('full','pmu') else 4
    assert len(data['cases'])==expected
    for c in data['cases']:
        assert c['stable']
        attempt=next(x for x in c['attempts'] if x['stable'])
        assert sha(R/attempt['csv'])==attempt['csv_sha256']
        assert all(x['valid'] for x in attempt['controls'] if x['round'] in attempt['retained_rounds'])
        if phase=='full':
            controls.extend(x for x in attempt['controls'] if x['round'] in attempt['retained_rounds']);flush_pairs+=attempt['flush_pairs_validated']
            assert all(t['work_kernels']==(4 if t['variant']=='parent' else 1) for t in attempt['targets'])
    samples=[json.loads(x) for x in (R/phase/'device_process_samples.jsonl').read_text().splitlines()]
    allowed={x['self_pid'] for x in data['snapshots']}
    unknown=sorted({p for x in samples for p in x.get('pids',[]) if p not in allowed})
    observed=sorted({p for x in data['snapshots'] for p in x['pids'] if p!=x['self_pid']})
    # Rejected-window processes stay visible, rather than disappearing from the report.
    monitors.append(dict(phase=phase,periodic_samples=len(samples),process_snapshot_count=len(data['snapshots']),foreign_pids_observed=sorted(set(unknown)|set(observed)),periodic_errors=sum('error' in x for x in samples),discarded_rounds=sum(len(x['discarded_rounds']) for c in data['cases'] for x in c['attempts'])))

peaks={}
for mode in ('warm','cold'):
    b=json.loads((R/'copy_calibration_before/results.json').read_text());a=json.loads((R/'copy_calibration_after/results.json').read_text())
    before=next(x for x in b['calibration'] if x['mode']==mode and x['stable'])
    after=next(x for x in a['calibration'] if x['mode']==mode and x['stable'])
    assert sha(R/before['csv'])==before['csv_sha256'] and sha(R/after['csv'])==after['csv_sha256']
    drift=abs(after['bandwidth_GBps']/before['bandwidth_GBps']-1);assert drift<=.02
    peaks[mode]=dict(before_GBps=before['bandwidth_GBps'],after_GBps=after['bandwidth_GBps'],reference_GBps=statistics.median([before['bandwidth_GBps'],after['bandwidth_GBps']]),drift_pct=100*drift)

rows=[];flow_rows=[];details=[]
l20_file=R/'l20_received.csv'
l20={r['case_id']:r for r in csv.DictReader(l20_file.open(encoding='utf-8-sig'))} if l20_file.exists() else {}
for c in full['cases']:
    p=pmu_by_id[c['case_id']]
    row=dict(case_id=c['case_id'],rows=c['rows'],hidden=c['hidden_size'],conditions=c['conditions'],status='PASS')
    flow=dict(case_id=c['case_id'],rows=c['rows'],hidden=c['hidden_size'])
    per_kernel={}
    for mode in ('warm','cold'):
        old=c['summary'][mode]['parent'];new=c['summary'][mode]['candidate']
        row[mode+'_parent_full_device_us']=old['full_device_us'];row[mode+'_candidate_full_device_us']=new['full_device_us']
        row[mode+'_parent_over_candidate']=old['full_device_us']/new['full_device_us']
        row[mode+'_latency_reduction_pct']=100*(1-new['full_device_us']/old['full_device_us'])
        row[mode+'_parent_fused_device_us']=old['fused_device_us']
        # Candidate's full public call contains exactly its single fused kernel.
        assert abs(new['full_device_us']-new['fused_device_us'])<1e-8 and new['table_copy_us']==0
        if c['case_id'] in l20:
            t=float(l20[c['case_id']][mode+'_full_device_us'])
            row[mode+'_l20_full_device_us']=t;row[mode+'_l20_over_candidate_reference']=t/new['full_device_us']
        per_kernel[mode]={}
        for variant in ('parent','candidate'):
            per_kernel[mode][variant]={}
            for scope in ('pmu','fused_pmu','copy_pmu'):
                metric=p['summary'][mode][variant].get(scope)
                if not metric:continue
                rates=metric['activity_pct'];assert all(math.isfinite(x) and 0<=x<=102 for x in rates.values())
                targets=[t[scope] for t in next(a for a in p['attempts'] if a['stable'])['targets'] if t['mode']==mode and t['variant']==variant and t[scope] is not None]
                sums={pipe:sum(t['activity_time_us'][pipe] for t in targets) for pipe in ('Vector','Scalar','MTE2','MTE3')}
                assert all(abs(100*sums[pipe]/metric['aiv_weight_us']-rates[pipe])<1e-7 for pipe in sums)
                per_kernel[mode][variant][scope]=dict(**metric,activity_time_us=sums)
            for pipe in ('Vector','Scalar','MTE2','MTE3'):flow[mode+'_'+variant+'_'+pipe+'_pct']=p['summary'][mode][variant]['pmu']['activity_pct'][pipe]
    rows.append(row);flow_rows.append(flow);details.append(dict(**row,per_kernel_pmu=per_kernel))

def write_csv(path,items):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(items[0]));w.writeheader();w.writerows(items)
write_csv(R/'strided_model16_device.csv',rows);write_csv(R/'strided_model16_pipeline.csv',flow_rows)
summary=dict(complete=True,passed_cases=16,total_cases=16,parent_sha256=sha(parent),candidate_sha256=sha(candidate),typical_screen=gate,geomean_parent_over_candidate={mode:math.exp(statistics.mean(math.log(r[mode+'_parent_over_candidate']) for r in rows)) for mode in ('warm','cold')},cache_copy_calibration=peaks,process_monitoring=monitors,full_valid_controls=dict(count=len(controls),min_GBps=min(c['GBps'] for c in controls),max_GBps=max(c['GBps'] for c in controls),max_reference_deviation_pct=100*max(abs(c['GBps']/full['reference_cold_copy_GBps']-1) for c in controls)),full_flush_pairs_validated=flush_pairs,work_kernels_per_public_call=dict(parent=4,candidate=1),metric='No-PMU matched public-call work-kernel Duration sum, host gaps/eviction excluded',pmu_basis='Fresh independent parent/candidate PMU, same2 inputs and warm/cold protocol; AIV-time-weighted overlapping activity, not wall fractions or critical-path proof',cases=details)
if l20:
    summary['l20_geomean_reference']={mode:math.exp(statistics.mean(math.log(r[mode+'_l20_over_candidate_reference']) for r in rows)) for mode in ('warm','cold')}
    summary['l20_caveat']='User supplied7-file L20 autotuned result, INTERFERENCE_UNVERIFIED;1 input vs A5 two, differing eviction implementation/preconditioning; reference only, not matched fresh L20 acceptance'
(R/'strided_model16_summary.json').write_text(json.dumps(summary,indent=2))
print('FULL16_STRIDE_COMPLETE',summary['geomean_parent_over_candidate'],summary.get('l20_geomean_reference'),flush=True)
for r in rows:print(r['case_id'],r['warm_parent_full_device_us'],r['warm_candidate_full_device_us'],r['cold_parent_full_device_us'],r['cold_candidate_full_device_us'],r['warm_parent_over_candidate'],r['cold_parent_over_candidate'])
