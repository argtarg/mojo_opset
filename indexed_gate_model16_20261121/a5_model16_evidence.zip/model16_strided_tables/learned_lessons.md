Unique profiler Step Ids may alias actual calls even with per-call synchronization. Validate complete call/kernel groups before normalizing. A3-copy parent may accidentally yield20 unique Step IDs while its1-kernel candidate yields17 for the same20 calls.
Raw PMU ratio strings are rounded; compute activity from matching pipe_time/AIV_time and validate units with export precision.
