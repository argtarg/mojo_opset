"""Read-only, selected-card process sampling; never controls foreign jobs."""
from pathlib import Path
import json,os,re,subprocess,threading,time

class DeviceWatch:
    def __init__(self,root):
        self.path=Path(root)/'device_process_samples.jsonl'
        self.samples=[];self.stop_event=threading.Event();self.lock=threading.Lock()
        self.thread=threading.Thread(target=self._run,daemon=True)
        self.thread.start()
    def _run(self):
        with self.path.open('a',buffering=1) as out:
            while not self.stop_event.is_set():
                sample=dict(monotonic=time.monotonic(),utc=time.time())
                try:
                    cp=subprocess.run(['npu-smi','info','-t','proc-mem','-i','6'],capture_output=True,text=True,timeout=5,check=True)
                    sample.update(pids=list(map(int,re.findall(r'Process id:\s*(\d+)',cp.stdout))),raw=cp.stdout)
                except Exception as e:sample['error']=repr(e)
                with self.lock:self.samples.append(sample)
                out.write(json.dumps(sample)+'\n');self.stop_event.wait(.5)
    def mark(self):return time.monotonic()
    def window(self,start,allowed=()):
        end=time.monotonic();accepted={os.getpid(),*allowed}
        with self.lock:window=[s for s in self.samples if start<=s['monotonic']<=end]
        foreign=sorted({p for s in window for p in s.get('pids',[]) if p not in accepted})
        return dict(start_monotonic=start,end_monotonic=end,samples=len(window),foreign_pids=foreign,monitor_errors=sum('error' in s for s in window),affected=bool(foreign) or any('error' in s for s in window))
    def close(self):self.stop_event.set();self.thread.join(timeout=6)

def wait_idle():
    for attempt in range(1201):
        cp=subprocess.run(['npu-smi','info','-t','proc-mem','-i','6'],capture_output=True,text=True,check=True,timeout=5)
        others=[int(p) for p in re.findall(r'Process id:\s*(\d+)',cp.stdout) if int(p)!=os.getpid()]
        if not others:return cp.stdout
        if attempt%20==0:print('COPY_WAIT_CARD6',others,flush=True)
        time.sleep(.5)
    raise RuntimeError('No uncontaminated calibration window on card6; unrelated jobs left running')
