## State Update 2026-11-21T03:32:00Z
- Source: start-round
- Round strategy: structural_change
- Analysis policy: pattern_entry
- Reason: User-directed direct table-row-stride loads remove3 measured materialization kernels; preserve math, pair public-call device Durations in both cache modes
- Warning: The combination structural_change + pattern_entry is unusual; structural rewrites often need deeper evidence than pattern_entry alone.

## Hypothesis
Parent is the accepted round9 source9b492cc4, same original model16 metadata/seed/index/stride.
Only change: main kernel gate/shift/scale loads use3 constexpr row strides; unit column stride is preserved; other5 specialized kernels keep their contiguous materialization behavior.
Primary analysis level: source plus existing board PMU/work-kernel evidence. No new named KB pattern; user-directed materialization elimination.
Existing evidence: model16 public calls contain3 contiguous table-copy kernels and1 fused kernel; small512 case spends about9.75us in copies.
Math AST is unchanged after normalizing only added stride names; other5 kernel ASTs are byte-structure equal.
Metric: user's complete public-call device Duration sum, with copies retained for parent and removed for candidate; independent warm/cold; no Event fallback.
Noise/interference: A/A, AB/BA, two independent typical runs, pre/post copy controls and selected-card process snapshots. No unrelated jobs stopped or frequency changes.
Typical cases:512x5376,C6;4096x5376,C3;10688x5376,C12;63360x5376,C6. Full16 only after stable typical gains.
Scope review: semantic main matrix traffic and reduction remain unchanged. Copy-only geometric saving assuming unchanged fused time is below the remaining1.85x L20 gap; this bounded user-requested round evaluates a useful wrapper change, not a claim to close that gap.
Canonical benchmark view: warm typical4 total-op and kernel views from run-bench; user's matched cache-conditioned device comparison reported separately and controls promotion scope.

Historical full/fused geometric ratios: {"warm": 1.0679558651016197, "cold": 1.0458860900244518}

## Final evidence
# Direct table row-stride loads

Parent: baseline = accepted round9 source `9b492cc42f556819c67e8e5087988b3574375ce79c9dcaea644bf125418f0c95`.
Candidate: `cb970f0caf9ca43f2e49e2e10ab09461e7385d13c1018cfe13b77ce7e47df051`.
Hypothesis: eliminate3 materialization kernels by addressing original row strides in the main fusion.
Pattern: self-directed user-requested materialization elimination; no named KB pattern.
Primary analysis level: source and existing board profiler evidence.
Supporting evidence: parent4 work kernels/call, candidate1; normalized main math AST unchanged, other5 kernel ASTs unchanged.
Final analysis level: same-card paired no-PMU device time plus fresh per-kernel PMU and standard-profile step-count audit; no IR/compiler-source claims.

Correctness: typical4/4,full16/16 official NPU contract with independent existing Torch oracle, streaming without PT files.
User metric: complete-call device Duration sum, matched2 inputs, both cache modes. Full16 geometric speedup 1.06821196x warm and1.04635767x cold.
Canonical run-bench typical4 total-op geomean:1.16x. Both canonical views passed after isolated repeat-count repair.

Observation: small/medium cases improve;63360-row gain is near noise, not a substantial per-case improvement.
Attribution:3 measured copy kernels disappear, arithmetic/precision preserved.
Scope: model16 original strides; original13 performance remains historical parent data.
Confounders: unique Step Id undercount inflated standard averages; demonstrated with20 actual computes/17 Step IDs, repaired privately with strict call/kernel validation and rerun. Pipeline ratio rounding issue repaired in diagnostic parser only. No corrupted/missing target accepted or Event substitution.
Disposition: promote as current validated model16 branch; retain parent and all original13 records.

Deep IR analysis skipped because source/trace proves the removed work, actual compiler math is unchanged and paired results repeat. Activities are overlapping engine utilization, not critical-path proof.

Artifacts: [report](../report.txt),[device CSV](../strided_model16_device.csv),[pipeline CSV](../strided_model16_pipeline.csv),[full timing/PMU JSON](../strided_model16_summary.json).
