# Direct table row-stride loads

Parent: baseline = accepted round9 source `9b492cc42f556819c67e8e5087988b3574375ce79c9dcaea644bf125418f0c95`.
Candidate: `cb970f0caf9ca43f2e49e2e10ab09461e7385d13c1018cfe13b77ce7e47df051`.
Hypothesis: eliminate3 materialization kernels by addressing original row strides in the main fusion.
Pattern: self-directed user-requested materialization elimination; no named KB pattern.
Primary analysis level: source and existing board profiler evidence.
Supporting evidence: parent4 work kernels/call, candidate1; normalized main math AST unchanged, other5 kernel ASTs unchanged.
Final analysis level: same-card paired no-PMU device time plus fresh per-kernel PMU and standard-profile step-count audit; no IR/compiler-source claims.

Correctness: typical4/4,full16/16 official NPU contract with independent existing Torch oracle, streaming without PT files.
User metric: complete-call device Duration sum, matched2 inputs, both cache modes. Full16 geometric speedup 1.06821196x warm and1.04635767x cold.
Canonical run-bench typical4 total-op geomean:1.16x. Both canonical views passed after isolated repeat-count repair.

Observation: small/medium cases improve;63360-row gain is near noise, not a substantial per-case improvement.
Attribution:3 measured copy kernels disappear, arithmetic/precision preserved.
Scope: model16 original strides; original13 performance remains historical parent data.
Confounders: unique Step Id undercount inflated standard averages; demonstrated with20 actual computes/17 Step IDs, repaired privately with strict call/kernel validation and rerun. Pipeline ratio rounding issue repaired in diagnostic parser only. No corrupted/missing target accepted or Event substitution.
Disposition: promote as current validated model16 branch; retain parent and all original13 records.

Deep IR analysis skipped because source/trace proves the removed work, actual compiler math is unchanged and paired results repeat. Activities are overlapping engine utilization, not critical-path proof.

Artifacts: [report](../report.txt),[device CSV](../strided_model16_device.csv),[pipeline CSV](../strided_model16_pipeline.csv),[full timing/PMU JSON](../strided_model16_summary.json).
