
## Hypothesis
Parent is the accepted round9 source9b492cc4, same original model16 metadata/seed/index/stride.
Only change: main kernel gate/shift/scale loads use3 constexpr row strides; unit column stride is preserved; other5 specialized kernels keep their contiguous materialization behavior.
Primary analysis level: source plus existing board PMU/work-kernel evidence. No new named KB pattern; user-directed materialization elimination.
Existing evidence: model16 public calls contain3 contiguous table-copy kernels and1 fused kernel; small512 case spends about9.75us in copies.
Math AST is unchanged after normalizing only added stride names; other5 kernel ASTs are byte-structure equal.
Metric: user's complete public-call device Duration sum, with copies retained for parent and removed for candidate; independent warm/cold; no Event fallback.
Noise/interference: A/A, AB/BA, two independent typical runs, pre/post copy controls and selected-card process snapshots. No unrelated jobs stopped or frequency changes.
Typical cases:512x5376,C6;4096x5376,C3;10688x5376,C12;63360x5376,C6. Full16 only after stable typical gains.
Scope review: semantic main matrix traffic and reduction remain unchanged. Copy-only geometric saving assuming unchanged fused time is below the remaining1.85x L20 gap; this bounded user-requested round evaluates a useful wrapper change, not a claim to close that gap.
Canonical benchmark view: warm typical4 total-op and kernel views from run-bench; user's matched cache-conditioned device comparison reported separately and controls promotion scope.

Historical full/fused geometric ratios: {"warm": 1.0679558651016197, "cold": 1.0458860900244518}
