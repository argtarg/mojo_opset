from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parent
s=json.loads((R/'strided_model16_summary.json').read_text());assert s['complete'] and s['passed_cases']==s['total_cases']==16
q=json.loads((R/'opt-round-1/round-state.json').read_text());assert q['correctness_status']==q['benchmark_status']=='passed'
completion=dict(status='complete',scope='model16',source_sha256=s['candidate_sha256'],precision_passed=16,precision_total=16,work_kernels_parent=4,work_kernels_candidate=1,geomean_parent_over_candidate=s['geomean_parent_over_candidate'],round_submission=dict(kind='round',status='pass',issues=[],guideline='round check passed. This round satisfied the current worker batch target.'),round_submission_basis='Observed submit-round --current-round1 --final-round1 response; managed evidence retained',measurement_repairs='See measurement_repairs.json, standard_step_audit.json and preserved uncorrected perf files',original13_status='Parent round9 and its historical results remain unchanged')
(R/'completion.json').write_text(json.dumps(completion,indent=2))
files=set()
for p in R.iterdir():
    if p.is_file() and p.name not in ('stride_package_manifest.json','stride_package_receipt.json') and p.suffix in ('.py','.sh','.json','.jsonl','.csv','.log','.txt','.md'):
        files.add(p)
for directory in ('baseline','opt-round-1','model_rules','precision_receipts'):
    for p in (R/directory).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pt':files.add(p)
for directory in ('noise','typical','confirm','full','pmu','copy_calibration_before','copy_calibration_after','canonical_profiles'):
    for p in (R/directory).rglob('*'):
        if p.is_file() and p.name in ('results.json','attempt_results.json','result.json','environment.json','device_process_samples.jsonl','kernel_details.csv','op_statistic.csv','step_trace_time.csv'):files.add(p)
for directory in R.glob('PROF_model_t2va_recipe209_u1_*'):
    for p in directory.rglob('*'):
        if p.is_file() and p.name in ('kernel_details.csv','op_statistic.csv','step_trace_time.csv'):files.add(p)
for p in (R/'.helix').rglob('*'):
    if p.is_file() and any(n in p.parts for n in ('evidence','round-timings')) and p.suffix in ('.json','.jsonl'):files.add(p)
parser=R/'.agents/skills/triton-npu-run-eval/scripts/profile_csv_parser.py';files.add(parser)
manifest={str(p.relative_to(R)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(files)}
(R/'stride_package_manifest.json').write_text(json.dumps(manifest,indent=2));files.add(R/'stride_package_manifest.json')
out=R/'model16_strided_tables_evidence.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(files):z.write(p,str(Path('model16_strided_tables')/p.relative_to(R)))
with zipfile.ZipFile(out) as z:assert z.testzip() is None
receipt=dict(archive=out.name,bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),file_count=len(files),contains_raw_kernel_details=True,contains_PT=False,contains_triton_cache=False)
(R/'stride_package_receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
