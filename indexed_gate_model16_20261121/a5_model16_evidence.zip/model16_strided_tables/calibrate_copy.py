"""Fresh warm/cold same-card semantic-MBU denominator, no PMU or frequency changes."""
from pathlib import Path
import argparse,csv,datetime,hashlib,json,os,statistics,time
import torch,torch_npu,triton,triton.language as tl
from device_watch import DeviceWatch,wait_idle
from model_inputs import check_frozen

parser=argparse.ArgumentParser();parser.add_argument('phase',choices=('before','after'));a=parser.parse_args()
ROOT=Path(__file__).resolve().parent;D=ROOT/('copy_calibration_'+a.phase);D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
check_frozen();q=json.loads((ROOT/'correctness_receipt.json').read_text())
assert q['passed'] and q['passed_cases']==q['total_cases']==16
assert q['operator_sha256']==sha(ROOT/'opt_indexed_gate.py')
assert os.environ.get('ASCEND_RT_VISIBLE_DEVICES')=='6' and not os.environ.get('INDEXED_GATE_PMU_DIAGNOSTIC')
state=dict(phase=a.phase,host='179.228.2.2',physical_device=6,source_sha256=q['operator_sha256'],script_sha256=sha(Path(__file__)),pmu=False,frequency_locked=False,config=dict(N=2**28,block=8192,cores=56,total_copy_bytes=2**31),flush_mib=1024,calibration=[])
(D/'environment.json').write_text(json.dumps(dict(torch=torch.__version__,torch_npu=torch_npu.__version__,triton=triton.__version__,device=str(torch.npu.get_device_name(0))),indent=2))
torch.set_grad_enabled(False);wait_idle();assert torch.npu.mem_get_info()[0]>=49152*1024**2

@triton.jit
def _mbu16_flush_kernel(ptr,N:tl.constexpr,B:tl.constexpr,CORES:tl.constexpr):
    pid=tl.program_id(0);off=tl.arange(0,B)
    for base in range(pid*B,N,CORES*B):
        v=tl.load(ptr+base+off);tl.store(ptr+base+off,v+1.)

@triton.jit
def _mbu16_copy_kernel(o0,o1,x0,x1,N:tl.constexpr,B:tl.constexpr,CORES:tl.constexpr):
    pid=tl.program_id(0);off=tl.arange(0,B)
    for base in range(pid*B,N,CORES*B):
        v0=tl.load(x0+base+off);v1=tl.load(x1+base+off)
        tl.store(o0+base+off,v0);tl.store(o1+base+off,v1)

buf=torch.zeros((1024**3//4,),dtype=torch.float32,device='npu');N=2**28
x0=torch.full((N,),1.25,dtype=torch.bfloat16,device='npu');x1=torch.full_like(x0,-.75)
o0=torch.empty_like(x0);o1=torch.empty_like(x1)
def flush():
    _mbu16_flush_kernel[(56,)](buf,N=buf.numel(),B=8192,CORES=56,multibuffer=False);torch.npu.synchronize()
def copy():
    _mbu16_copy_kernel[(56,)](o0,o1,x0,x1,N=N,B=8192,CORES=56,multibuffer=True,prevec_max_fused_ops_num=2)
copy();torch.npu.synchronize();assert torch.equal(o0,x0) and torch.equal(o1,x1)
flush();watch=DeviceWatch(D)

def measure(mode,attempt):
    folder=D/(mode+'_attempt'+str(attempt));folder.mkdir(exist_ok=False)
    wait_idle()
    for i in range(20):
        if mode=='cold':flush()
        copy()
    torch.npu.synchronize();seq=[];window_start=watch.mark()
    def call(stage,rd,sample):
        if mode=='cold':flush()
        copy();seq.append(dict(stage=stage,round=rd,sample=sample))
    prof=torch_npu.profiler
    cfg=prof._ExperimentalConfig(profiler_level=prof.ProfilerLevel.Level1,aic_metrics=prof.AiCMetrics.AiCoreNone)
    with prof.profile(activities=[prof.ProfilerActivity.CPU,prof.ProfilerActivity.NPU],on_trace_ready=prof.tensorboard_trace_handler(str(folder)),experimental_config=cfg):
        for rd in range(3):
            for j in range(4):call('settle',rd,-1)
            torch.npu.synchronize()
            for sample in range(20):
                for j in range(2):call('precondition',rd,sample)
                torch.npu.synchronize();call('target',rd,sample);torch.npu.synchronize()
    end_snapshot=subprocess_snapshot()
    observation=watch.window(window_start)
    paths=list(folder.rglob('kernel_details.csv'));assert len(paths)==1
    all_records=[r for r in csv.DictReader(paths[0].open()) if r.get('Name') and float(r['Duration(us)'])>0]
    records=sorted((r for r in all_records if '_mbu16_copy_kernel' in r['Name']),key=lambda r:float(r['Start Time(us)']))
    flushes=sorted((r for r in all_records if '_mbu16_flush_kernel' in r['Name']),key=lambda r:float(r['Start Time(us)']))
    assert len(records)==len(seq),(len(records),len(seq))
    assert len(flushes)==(len(records) if mode=='cold' else 0)
    assert len(all_records)==len(records)+len(flushes),'Unexpected calibration kernel'
    if mode=='cold':
        for f,r in zip(flushes,records):assert float(f['Start Time(us)'])+float(f['Duration(us)'])<=float(r['Start Time(us)'])
    targets=[dict(**e,kernel_us=float(r['Duration(us)'])) for e,r in zip(seq,records) if e['stage']=='target']
    medians=[statistics.median(t['kernel_us'] for t in targets if t['round']==rd) for rd in range(3)]
    value=statistics.median(medians);spread=(max(medians)-min(medians))/value
    other_pids=[p for p in end_snapshot['pids'] if p!=os.getpid()]
    stable=spread<=.02 and not observation['affected'] and not other_pids
    result=dict(mode=mode,attempt=attempt,device_us=value,round_medians_us=medians,round_spread=spread,stable=stable,bandwidth_GBps=N*8/value/1000,copy_bytes=N*8,targets=targets,process_observation=observation,end_snapshot=end_snapshot,csv=str(paths[0].relative_to(ROOT)),csv_sha256=sha(paths[0]),flush_pairs_validated=len(flushes),bitwise_verified=True)
    (folder/'result.json').write_text(json.dumps(result,indent=2))
    print('CALIBRATION',a.phase,mode,attempt,value,result['bandwidth_GBps'],stable,flush=True)
    return result

def subprocess_snapshot():
    import subprocess,re
    cp=subprocess.run(['npu-smi','info','-t','proc-mem','-i','6'],capture_output=True,text=True,check=True,timeout=5)
    return dict(pids=list(map(int,re.findall(r'Process id:\s*(\d+)',cp.stdout))),raw=cp.stdout)

try:
    for mode in ('warm','cold'):
        for attempt in range(1,6):
            result=measure(mode,attempt);state['calibration'].append(result)
            (D/'results.json').write_text(json.dumps(state,indent=2))
            if result['stable']:break
        else:raise RuntimeError('No stable '+mode+' calibration; rejected data retained')
    assert torch.equal(o0,x0) and torch.equal(o1,x1)
    state['complete']=True;(D/'results.json').write_text(json.dumps(state,indent=2))
    if a.phase=='before':
        c=next(c for c in state['calibration'] if c['mode']=='cold' and c['stable'])
        reference=dict(physical_device=6,clear_l2=True,peak_bandwidth_gbps=c['bandwidth_GBps'],config=state['config'],source='fresh same-card pre-run cold calibration',calibration_csv_sha256=c['csv_sha256'])
        (ROOT/'copy_reference.json').write_text(json.dumps(reference,indent=2))
finally:watch.close()
