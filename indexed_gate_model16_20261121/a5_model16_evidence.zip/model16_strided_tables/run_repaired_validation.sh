#!/bin/bash
source /home/t00985010/indexed_gate_strided_tables_20261121_110935_9e77/environment.sh
python prepare_private_runner.py > prepare_private_runner.log 2>&1 || exit $?
cli=$PWD/.agents/skills/triton-npu-run-eval/scripts/cli.py
export HELIX_BENCH_OUTPUT_DIR=$PWD/canonical_profiles
cp baseline/indexed_gate_perf.txt baseline/indexed_gate_perf_unfixed.txt
cp opt-round-1/opt_indexed_gate_perf.txt opt-round-1/opt_indexed_gate_perf_unfixed.txt
python "$cli" run-bench-baseline --bench-file bench_indexed_gate.py --operator-file baseline/indexed_gate.py --output baseline/indexed_gate_perf.txt > repaired_baseline_bench.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > repaired_validation_exit.txt; exit "$rc"; fi
python "$cli" run-bench --bench-file bench_indexed_gate.py --operator-file opt-round-1/opt_indexed_gate.py --baseline-operator-file baseline/indexed_gate.py --output opt-round-1/opt_indexed_gate_perf.txt --metric-source total-op > repaired_canonical_totalop.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > repaired_validation_exit.txt; exit "$rc"; fi
python "$cli" compare-perf --baseline baseline/indexed_gate_perf.txt --compare opt-round-1/opt_indexed_gate_perf.txt --metric-source kernel > repaired_kernel_view.log 2>&1
python "$cli" compare-perf --baseline baseline/indexed_gate_perf.txt --compare opt-round-1/opt_indexed_gate_perf.txt --metric-source total-op > repaired_totalop_view.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > repaired_validation_exit.txt; exit "$rc"; fi
python paired_stride_pmu.py --phase pmu --cases all --pmu > pmu_driver_repaired.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > repaired_validation_exit.txt; exit "$rc"; fi
python calibrate_copy.py after > calibration_after.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > repaired_validation_exit.txt; exit "$rc"; fi
python finalize_stride.py > finalize_stride.log 2>&1
rc=$?;echo "$rc" > repaired_validation_exit.txt
exit "$rc"
