"""Preserve the official scheduled profiler traces and audit step-count normalization."""
from pathlib import Path
import csv,hashlib,json,os,subprocess
R=Path(__file__).resolve().parent
CLI='/home/t00985010/indexed_gate_optimizer_20261117_2125_3908/.agents/skills/triton-npu-run-eval/scripts/cli.py'
reports=[]
for variant,source in [('parent',R/'baseline/indexed_gate.py'),('candidate',R/'opt-round-1/opt_indexed_gate.py')]:
    before=set(R.glob('PROF_model_t2va_recipe209_u1_*'))
    command=['python',CLI,'profile-bench','--bench-file','bench_indexed_gate.py','--operator-file',str(source),'--case-id','model_t2va_recipe209_u1','--target-op','_indexed_gate_rms_shift_kernel']
    with (R/('standard_trace_'+variant+'.log')).open('w') as log:cp=subprocess.run(command,cwd=R,stdout=log,stderr=subprocess.STDOUT)
    added=set(R.glob('PROF_model_t2va_recipe209_u1_*'))-before;assert len(added)==1
    folder=next(iter(added));paths=list(folder.rglob('kernel_details.csv'));assert len(paths)==1
    rows=list(csv.DictReader(paths[0].open()));work=[r for r in rows if r.get('Name') and float(r['Duration(us)'])>0]
    fused=[r for r in work if '_indexed_gate_rms_shift_' in r['Name']]
    steps={r['Step Id'] for r in work if r.get('Step Id')}
    unique_fused_steps={r['Step Id'] for r in fused if r.get('Step Id')}
    counts={name:sum(r.get('Step Id')==name for r in work) for name in steps}
    per_call=4 if variant=='parent' else 1
    assert len(fused)==20 and len(work)==20*per_call,(variant,len(fused),len(work))
    total=sum(float(r['Duration(us)']) for r in work)
    rec=dict(variant=variant,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),profile_cli_returncode=cp.returncode,csv=str(paths[0].relative_to(R)),csv_sha256=hashlib.sha256(paths[0].read_bytes()).hexdigest(),declared_public_calls=20,actual_compute_kernels=len(fused),actual_work_kernels=len(work),nonempty_unique_steps=len(steps),compute_unique_steps=len(unique_fused_steps),kernels_per_step=counts,device_duration_sum_us=total,actual_per_call_mean_us=total/20,unique_step_normalized_us=total/len(steps) if steps else None,step_id_is_complete_one_to_one=(len(steps)==20 and all(c==per_call for c in counts.values())))
    reports.append(rec);print(json.dumps(rec),flush=True)
(R/'standard_step_audit.json').write_text(json.dumps(reports,indent=2))
