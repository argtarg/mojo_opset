#!/bin/bash
source /home/t00985010/indexed_gate_strided_tables_20261121_110935_9e77/environment.sh
cli=/home/t00985010/indexed_gate_optimizer_20261117_2125_3908/.agents/skills/triton-npu-run-eval/scripts/cli.py
gate=/home/t00985010/indexed_gate_optimizer_20261117_2125_3908/.agents/skills/triton-npu-optimize-state/scripts/cli.py
python capture_environment.py > environment.log 2>&1
python validate_layouts.py > layout_validation.log 2>&1 || exit $?
python "$cli" run-test-baseline --test-file differential_test_opt_indexed_gate.py --operator-file baseline/indexed_gate.py --ref-operator-file oracle_model.py --test-mode differential --verbose > correctness_official.log 2>&1
rc=$?;echo "$rc" > correctness_exit.txt
if [ "$rc" != "0" ]; then echo "$rc" > baseline_exit.txt; exit "$rc"; fi
python quality_receipt.py > quality_receipt.log 2>&1 || exit $?
python "$cli" run-bench-baseline --bench-file bench_indexed_gate.py --operator-file baseline/indexed_gate.py --output baseline/indexed_gate_perf.txt > baseline_bench.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > baseline_exit.txt; exit "$rc"; fi
python -c 'import pathlib,json; p=pathlib.Path("baseline/state.json"); s=json.loads(p.read_text()); s.update(correctness_status="passed",benchmark_status="passed"); p.write_text(json.dumps(s,indent=2))'
python "$gate" submit-baseline --baseline-dir baseline > baseline_gate.json 2>&1
rc=$?;echo "$rc" > baseline_exit.txt
exit "$rc"
