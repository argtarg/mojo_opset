#!/bin/bash
source /home/t00985010/indexed_gate_strided_tables_20261121_110935_9e77/environment.sh
python -c 'import json,pathlib; s=json.loads(pathlib.Path("typical_screen.json").read_text()); assert s["expand_to_full16"]'
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > full_exit.txt; exit "$rc"; fi
cli=/home/t00985010/indexed_gate_optimizer_20261117_2125_3908/.agents/skills/triton-npu-run-eval/scripts/cli.py
python "$cli" run-test-optimize --test-file test_indexed_gate.py --operator-file opt-round-1/opt_indexed_gate.py --test-mode standalone --verbose > candidate_full_test.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > full_exit.txt; exit "$rc"; fi
python -c 'import pathlib,hashlib,shutil; r=pathlib.Path.cwd(); h=hashlib.sha256((r/"opt-round-1/opt_indexed_gate.py").read_bytes()).hexdigest(); shutil.copyfile(r/"precision_receipts"/(h+"_full.json"),r/"candidate_full_receipt.json")'
python paired_stride.py --phase full --cases all > full_driver.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > full_exit.txt; exit "$rc"; fi
python "$cli" run-bench --bench-file bench_indexed_gate.py --operator-file opt-round-1/opt_indexed_gate.py --baseline-operator-file baseline/indexed_gate.py --output opt-round-1/opt_indexed_gate_perf.txt --metric-source all > canonical_compare.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > full_exit.txt; exit "$rc"; fi
python paired_stride.py --phase pmu --cases all --pmu > pmu_driver.log 2>&1
rc=$?
if [ "$rc" != "0" ]; then echo "$rc" > full_exit.txt; exit "$rc"; fi
python calibrate_copy.py after > calibration_after.log 2>&1
rc=$?;echo "$rc" > full_exit.txt
exit "$rc"
