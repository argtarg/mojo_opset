"""Same-card interleaved parent/candidate public-call device Duration, warm/cold."""
from pathlib import Path
import argparse,atexit,csv,gc,hashlib,importlib.util,json,math,os,re,statistics,subprocess,time
import torch,torch_npu,triton,triton.language as tl
from model_inputs import CASES,build_inputs,check_frozen,input_layout
from device_watch import DeviceWatch

ap=argparse.ArgumentParser();ap.add_argument('--phase',required=True);ap.add_argument('--cases',required=True);ap.add_argument('--noise',action='store_true');ap.add_argument('--pmu',action='store_true');a=ap.parse_args()
R=Path(__file__).resolve().parent;D=R/a.phase;D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
check_frozen();assert os.environ.get('ASCEND_RT_VISIBLE_DEVICES')=='6'
parent=R/'baseline/indexed_gate.py';candidate=parent if a.noise else R/'opt-round-1/opt_indexed_gate.py'
q=json.loads((R/'correctness_receipt.json').read_text());assert q['passed'] and q['passed_cases']==q['total_cases']==16 and q['operator_sha256']==sha(parent)
selected=CASES if a.cases=='all' else [c for c in CASES if c['id'] in set(a.cases.split(','))]
assert selected and (a.cases=='all' or len(selected)==len(a.cases.split(',')))
if not a.noise:
    cq=json.loads((R/('candidate_full_receipt.json' if a.cases=='all' else 'candidate_typical_receipt.json')).read_text())
    assert cq['passed'] and cq['candidate_sha256']==sha(candidate)
    assert {c['id'] for c in selected}<={c['case_id'] for c in cq['cases']}
def load(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m.ModelNew().npu().eval()
models=dict(parent=load(parent,'stride_parent'),candidate=load(candidate,'stride_candidate'))
expected=dict(parent=4,candidate=4 if a.noise else 1)
peak=json.loads((R/'copy_reference.json').read_text())['peak_bandwidth_gbps']
state=dict(phase=a.phase,parent_sha256=sha(parent),candidate_sha256=sha(candidate),host='179.228.2.2',physical_device=6,logical_device=0,pmu=a.pmu,frequency_locked=False,metric='sum of all work-kernel Durations per public call; eviction/CPU gaps excluded',protocol='same2 frozen inputs;2 matched preconditions; alternating cache and AB/BA order;3 retained rounds;20pairs/round,512-row case80pairs; first stable window',expected_work_kernels=expected,reference_cold_copy_GBps=peak,snapshots=[],process_windows=[],cases=[])
if (D/'results.json').exists():
    old=json.loads((D/'results.json').read_text());assert all(old[k]==state[k] for k in ('parent_sha256','candidate_sha256','pmu','expected_work_kernels'));state=old
def save():(D/'results.json').write_text(json.dumps(state,indent=2))
watch=DeviceWatch(D);atexit.register(watch.close)
def snapshot(label):
    observed=False
    for attempt in range(1201):
        cp=subprocess.run(['npu-smi','info','-t','proc-mem','-i','6'],capture_output=True,text=True,check=True,timeout=5)
        pids=list(map(int,re.findall(r'Process id:\s*(\d+)',cp.stdout)));other=[p for p in pids if p!=os.getpid()]
        state['snapshots'].append(dict(label=label,self_pid=os.getpid(),pids=pids,raw=cp.stdout));save()
        if not other:return observed
        observed=True
        if attempt%20==0:print('WAIT_CARD6',label,other,flush=True)
        time.sleep(.5)
    raise RuntimeError('Could not obtain clean selected-card window; no unrelated jobs stopped')

@triton.jit
def _stride_flush(ptr,N:tl.constexpr,B:tl.constexpr,CORES:tl.constexpr):
    pid=tl.program_id(0);offs=tl.arange(0,B)
    for base in range(pid*B,N,CORES*B):
        v=tl.load(ptr+base+offs);tl.store(ptr+base+offs,v+1.)
@triton.jit
def _stride_control(o0,o1,x0,x1,N:tl.constexpr,B:tl.constexpr,CORES:tl.constexpr):
    pid=tl.program_id(0);offs=tl.arange(0,B)
    for base in range(pid*B,N,CORES*B):
        a=tl.load(x0+base+offs);b=tl.load(x1+base+offs);tl.store(o0+base+offs,a);tl.store(o1+base+offs,b)
torch.set_grad_enabled(False);snapshot('start');assert torch.npu.mem_get_info()[0]>=49152*1024**2
buf=torch.zeros((1024**3//4,),dtype=torch.float32,device='npu');N=2**28
x0=torch.full((N,),1.25,dtype=torch.bfloat16,device='npu');x1=torch.full_like(x0,-.75);o0=torch.empty_like(x0);o1=torch.empty_like(x1)
def flush():_stride_flush[(56,)](buf,N=buf.numel(),B=8192,CORES=56,multibuffer=False);torch.npu.synchronize()
def control():
    flush();_stride_control[(56,)](o0,o1,x0,x1,N=N,B=8192,CORES=56,multibuffer=True,prevec_max_fused_ops_num=2);torch.npu.synchronize()
control();assert torch.equal(o0,x0) and torch.equal(o1,x1)

def pipes(rows):
    names=dict(Vector='aiv_vec',Scalar='aiv_scalar',MTE2='aiv_mte2',MTE3='aiv_mte3')
    total=sum(float(r['aiv_time(us)']) for r in rows);assert total>0
    result={};times={}
    for label,key in names.items():
        vals=[float(r[key+'_time(us)']) for r in rows]
        for r,v in zip(rows,vals):
            raw=float(r[key+'_ratio']);ratio=v/float(r['aiv_time(us)'])
            assert min(abs(raw-ratio),abs(raw/100-ratio))<=max(.0002,abs(ratio)*.002),(key,raw,ratio)
        times[label]=sum(vals);result[label]=100*sum(vals)/total
    return dict(activity_pct=result,activity_time_us=times,aiv_weight_us=total,records=len(rows))

def profile(case,data,attempt):
    cid=case['id'];dest=D/cid/f'attempt{attempt}';dest.mkdir(parents=True,exist_ok=False)
    seq=[];control_seq=[];retained=[];discarded=[]
    pairs=6 if a.pmu else (80 if case['rows']<=1024 else 20)
    required_rounds=1 if a.pmu else 3
    for i in range(10):
        for variant in ('parent','candidate'):
            result=models[variant](*data[i%2]);del result
    torch.npu.synchronize()
    def call(mode,variant,index,stage,rd,pair):
        if mode=='cold':flush()
        result=models[variant](*data[index]);del result
        seq.append(dict(mode=mode,variant=variant,input_index=index,stage=stage,round=rd,pair=pair))
    prof=torch_npu.profiler;metrics=prof.AiCMetrics.PipeUtilization if a.pmu else prof.AiCMetrics.AiCoreNone
    cfg=prof._ExperimentalConfig(profiler_level=prof.ProfilerLevel.Level1,aic_metrics=metrics)
    with prof.profile(activities=[prof.ProfilerActivity.CPU,prof.ProfilerActivity.NPU],on_trace_ready=prof.tensorboard_trace_handler(str(dest)),experimental_config=cfg):
        for rd in range(12):
            snapshot(cid+f'_r{rd}_before');mark=watch.mark()
            control();control_seq.append(dict(round=rd,position='before'))
            for pair in range(pairs):
                cache_order=('warm','cold') if (rd+pair)%2 else ('cold','warm')
                order=('parent','candidate') if (rd+pair)%2 else ('candidate','parent')
                index=(pair//2)%2
                for mode in cache_order:
                    for variant in order:
                        for j in range(2):call(mode,variant,j%2,'precondition',rd,pair)
                        torch.npu.synchronize();call(mode,variant,index,'target',rd,pair);torch.npu.synchronize()
            control();control_seq.append(dict(round=rd,position='after'))
            appeared=snapshot(cid+f'_r{rd}_after');window=watch.window(mark)
            state['process_windows'].append(dict(case_id=cid,attempt=attempt,round=rd,**window));save()
            (discarded if appeared or window['affected'] else retained).append(rd)
            if len(retained)==required_rounds:break
    assert len(retained)==required_rounds
    paths=list(dest.rglob('kernel_details.csv'));assert len(paths)==1
    rows=sorted([r for r in csv.DictReader(paths[0].open()) if r.get('Name') and float(r['Duration(us)'])>0],key=lambda r:float(r['Start Time(us)']))
    parsed=[];pending=[];last_flush=None;flush_count=0;controls=[]
    for r in rows:
        name=r['Name'];start=float(r['Start Time(us)']);end=start+float(r['Duration(us)'])
        if '_stride_flush' in name:
            assert not pending and last_flush is None
            last_flush=end;flush_count+=1
        elif '_stride_control' in name:
            assert not pending and last_flush is not None and last_flush<=start
            gbps=N*8/float(r['Duration(us)'])/1000
            controls.append(dict(**control_seq[len(controls)],GBps=gbps,valid=abs(gbps/peak-1)<=.03));last_flush=None
        else:
            pending.append(r)
            if '_indexed_gate_rms_shift_' not in name:continue
            e=seq[len(parsed)];assert len(pending)==expected[e['variant']],(cid,e,[(t['Name'],t['Duration(us)']) for t in pending])
            assert (last_flush is not None)==(e['mode']=='cold')
            if last_flush is not None:assert last_flush<=float(pending[0]['Start Time(us)'])
            values=[float(t['Duration(us)']) for t in pending]
            parsed.append(dict(**e,full_device_us=sum(values),fused_device_us=values[-1],table_copy_us=sum(values[:-1]),device_span_us=end-float(pending[0]['Start Time(us)']),work_kernels=len(pending),pmu=pipes(pending) if a.pmu else None,fused_pmu=pipes(pending[-1:]) if a.pmu else None,copy_pmu=pipes(pending[:-1]) if a.pmu and len(pending)>1 else None))
            pending=[];last_flush=None
    assert len(parsed)==len(seq) and not pending and last_flush is None
    assert len(controls)==len(control_seq) and flush_count==sum(x['mode']=='cold' for x in seq)+len(controls)
    targets=[t for t in parsed if t['stage']=='target' and t['round'] in retained]
    stable=all(c['valid'] for c in controls if c['round'] in retained);summary={};speedups={}
    for mode in ('warm','cold'):
        summary[mode]={}
        for variant in ('parent','candidate'):
            summary[mode][variant]={}
            for metric in ('full_device_us','fused_device_us','table_copy_us','device_span_us'):
                med=[statistics.median(t[metric] for t in targets if t['mode']==mode and t['variant']==variant and t['round']==rd) for rd in retained]
                value=statistics.median(med);spread=(max(med)-min(med))/value if value else 0.
                summary[mode][variant][metric]=value;summary[mode][variant][metric+'_round_medians']=med
                if metric in ('full_device_us','fused_device_us'):
                    floor=2. if metric=='full_device_us' and expected[variant]>1 else .15
                    limit=max(.03,floor/value);stable &= spread<=limit
                    summary[mode][variant][metric+'_spread']=spread;summary[mode][variant][metric+'_limit']=limit
            if a.pmu:
                for scope in ('pmu','fused_pmu','copy_pmu'):
                    samples=[t[scope] for t in targets if t['mode']==mode and t['variant']==variant and t[scope] is not None]
                    if not samples:continue
                    total=sum(t['aiv_weight_us'] for t in samples)
                    summary[mode][variant][scope]=dict(activity_pct={p:100*sum(t['activity_time_us'][p] for t in samples)/total for p in ('Vector','Scalar','MTE2','MTE3')},aiv_weight_us=total,records=sum(t['records'] for t in samples))
        ratios=[summary[mode]['parent']['full_device_us_round_medians'][i]/summary[mode]['candidate']['full_device_us_round_medians'][i] for i in range(len(retained))]
        speedups[mode]=dict(full_parent_over_candidate=summary[mode]['parent']['full_device_us']/summary[mode]['candidate']['full_device_us'],round_ratios=ratios)
    result=dict(stable=stable,summary=summary,speedups=speedups,targets=targets,pairs_per_round=pairs,retained_rounds=retained,discarded_rounds=discarded,controls=controls,work_calls=len(parsed),flush_pairs_validated=flush_count,csv=str(paths[0].relative_to(R)),csv_sha256=sha(paths[0]))
    (dest/'attempt_results.json').write_text(json.dumps(result,indent=2));return result

for case in selected:
    if any(c['case_id']==case['id'] and c['stable'] for c in state['cases']):continue
    check_frozen();data=[build_inputs(case,i) for i in range(2)];attempts=[]
    for attempt in range(1,8):
        if (D/case['id']/f'attempt{attempt}').exists():continue
        result=profile(case,data,attempt);attempts.append(result)
        print('STRIDE_PAIR',case['id'],attempt,result['stable'],result['speedups'],flush=True)
        if result['stable']:break
    else:raise RuntimeError('Could not obtain stable paired windows: '+case['id'])
    state['cases'].append(dict(case_id=case['id'],rows=case['rows'],hidden_size=case['hidden_size'],conditions=case['conditions'],active_conditions=case['active_conditions'],indices_sha256=case['indices_sha256'],input_layout=input_layout(data[0]),stable=True,summary=result['summary'],speedups=result['speedups'],attempts=attempts));save()
    del data;gc.collect();torch.npu.empty_cache()
state['complete']=len(state['cases'])==len(selected)
state['geomean_parent_over_candidate']={mode:math.exp(statistics.mean(math.log(c['speedups'][mode]['full_parent_over_candidate']) for c in state['cases'])) for mode in ('warm','cold')}
save();watch.close();print('STRIDE_PHASE_COMPLETE',a.phase,state['geomean_parent_over_candidate'],flush=True)
