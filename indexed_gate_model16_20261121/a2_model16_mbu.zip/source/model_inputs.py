# SPDX-License-Identifier: Apache-2.0
"""Pinned-model call layout; synthetic BF16 values, no checkpoint trace."""
from pathlib import Path
import hashlib,json
import torch
from model_rules import model_case_inputs as layout
ROOT=Path(__file__).resolve().parent
CASES=json.loads((ROOT/'model_cases.json').read_text())['cases']

def check_frozen():
 for name,expected in json.loads((ROOT/'frozen_inputs.json').read_text()).items():
  assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name

def derive(case):
 spec=next(c for c in layout.requests() if c['id']==case['layout_case_id'])
 meta,indices=layout.build_case_metadata(spec)
 for k in ('rows','hidden_size','conditions','eps','indices_sha256','condition_row_counts','indices_segments'):
  assert meta[k]==case[k],(case['id'],k)
 assert case['conditions']==3*len(meta['unique_timesteps'])
 return indices

def build_inputs(case,instance=0):
 # Generate on the selected NPU with an explicit per-case/instance seed.
 idx=derive(case).to('npu');r,h,c=case['rows'],case['hidden_size'],case['conditions']
 gen=torch.Generator(device='npu').manual_seed(case['seed']+instance*1000000)
 def rand(*shape):return torch.randn(shape,dtype=torch.bfloat16,device='npu',generator=gen)
 residual,branch,weight=rand(r,h),rand(r,h),rand(h)
 parent=rand(c,6*h)
 shift_msa,scale_msa,gate_msa,shift_mlp,scale_mlp,gate_mlp=parent.chunk(6,dim=-1)
 args=[residual,gate_msa,branch,weight,shift_mlp,scale_mlp,idx,case['eps']]
 assert all(x.dtype==torch.bfloat16 for x in args[:6]) and idx.dtype==torch.int64
 for slot,name in ((1,'gate'),(4,'shift'),(5,'scale')):
  assert list(args[slot].stride())==case[name+'_stride']
  assert args[slot].storage_offset()==case[name+'_storage_offset']
  assert args[slot].untyped_storage().data_ptr()==parent.untyped_storage().data_ptr()
 assert not gate_msa.is_contiguous() and not shift_mlp.is_contiguous() and not scale_mlp.is_contiguous()
 return args

def input_layout(args):
 names=('residual','gate','branch','weight','shift','scale','indices')
 return {name:dict(shape=list(x.shape),stride=list(x.stride()),storage_offset=x.storage_offset(),dtype=str(x.dtype)) for name,x in zip(names,args)}
