"""Compute semantic full-forward MBU from the matched cold A2 measurements."""
from pathlib import Path
import csv,hashlib,json,math,os,re,statistics,zipfile

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'diagnostics/a2_model16_20261118'
EVID=BASE/'evidence'
LONG=Path('\\\\?\\'+str(EVID.resolve())) if os.name=='nt' else EVID
OUT=BASE/'mbu_cold';OUT.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
state=load(LONG/'suite/cold_device_card7/results.json')
summary=load(BASE/'summary.json')
cases=load(LONG/'suite/model_cases.json')['cases']
quality=load(LONG/'suite/correctness_receipt.json')
assert state['complete'] and state['clear_l2'] and state['physical_device']==7
assert quality['passed'] and quality['passed_cases']==quality['total_cases']==16
assert sha(LONG/'suite/opt_indexed_gate.py')==quality['operator_sha256']==state['operator_sha256']
assert len(cases)==len(state['cases'])==16
specs={c['id']:c for c in cases}
assert set(specs)=={c['case_id'] for c in state['cases']}
original_manifest=load(LONG/'manifest.json')
for name,digest in original_manifest.items():assert sha(LONG/name)==digest,name

# A semantic lower bound: two BF16 activations read, two BF16 outputs written,
# each actually referenced gate/shift/scale row read once, weight, int64 indices.
def byte_parts(c):
 r,h,a=c['rows'],c['hidden_size'],c['active_conditions']
 counts=c['condition_row_counts']
 assert len(counts)==c['conditions'] and sum(counts)==r
 assert sum(n>0 for n in counts)==a
 return dict(residual_read=r*h*2,branch_read=r*h*2,residual_out_write=r*h*2,
             output_write=r*h*2,gate_active_rows=a*h*2,shift_active_rows=a*h*2,
             scale_active_rows=a*h*2,weight_read=h*2,int64_indices_read=r*8)

control_durations=[];controls=[];audits=[];case_times={};raw_sources=[]
for c in state['cases']:
 cid=c['case_id'];raw=LONG/'suite'/c['csv']
 assert sha(raw)==c['csv_sha256']
 rows=list(csv.DictReader(raw.open(encoding='utf-8')))
 rows.sort(key=lambda q:float(q['Start Time(us)']))
 pending=[];events=[];evicted=False;flushes=0
 for q in rows:
  assert int(q['Device_id'])==7
  us=float(q['Duration(us)']);assert math.isfinite(us) and us>0
  name=q['Name']
  if '_a2_model_flush' in name:
   assert not pending and not evicted
   assert list(map(int,re.findall(r'\d+',q['Input Shapes'])))==[2**28]
   assert q['Input Data Types']=='FLOAT'
   evicted=True;flushes+=1;continue
  pending.append(q)
  if '_a2_model_copy' in name:
   assert evicted and len(pending)==1
   assert list(map(int,re.findall(r'\d+',q['Input Shapes'])))==[2**28,2**28]
   assert list(map(int,re.findall(r'\d+',q['Output Shapes'])))==[2**28,2**28]
   assert q['Input Data Types']=='DT_BF16;DT_BF16' and q['Output Data Types']=='DT_BF16;DT_BF16'
   events.append(dict(kind='control',us=us));pending=[];evicted=False
  elif '_indexed_gate_rms_shift_kernel' in name:
   assert evicted and len(pending)==4
   assert all('InplaceCopy' in t['Name'] for t in pending[:-1])
   events.append(dict(kind='dut',total_us=sum(float(t['Duration(us)']) for t in pending),fused_us=us))
   pending=[];evicted=False
 assert not pending and not evicted and flushes==36 and len(events)==36
 medians=[];local_controls=[]
 for rd in range(3):
  chunk=events[rd*12:(rd+1)*12]
  assert chunk[0]['kind']==chunk[-1]['kind']=='control'
  assert all(t['kind']=='dut' for t in chunk[1:-1])
  medians.append(statistics.median(t['total_us'] for t in chunk[1:-1]))
  for position,item in (('before',chunk[0]),('after',chunk[-1])):
   value=item['us'];control_durations.append(value);local_controls.append(value)
   controls.append(dict(case_id=cid,round=rd,position=position,duration_us=value,
                        read_write_bytes=2**31,gbps=(2**31)/value/1000))
 total=statistics.median(medians)
 assert math.isclose(total,c['summary']['device_total_us'],rel_tol=1e-12)
 assert len(c['controls'])==6 and all(q['valid'] for q in c['controls'])
 assert all(math.isclose(a,b['device_us'],rel_tol=1e-12) for a,b in zip(local_controls,c['controls']))
 case_times[cid]=total
 audits.append(dict(case_id=cid,csv_sha256=sha(raw),dut_calls=30,copy_controls=6,flushes=36,
                    every_work_call_preceded_by_flush=True,device_us_round_medians=medians,
                    device_us_median=total))
 raw_sources.append((cid,raw))
assert len(controls)==96
median_copy_us=statistics.median(control_durations)
reference_gbps=(2**31)/median_copy_us/1000
deviation=max(abs(q['gbps']/reference_gbps-1)*100 for q in controls)
assert deviation<=3,('copy control drift',deviation)
peak=dict(physical_device=7,logical_device=0,host='179.184.3.2',clear_l2=True,
          bandwidth_method='matched 2GiB read+write two-stream BF16 Triton copy; all96 retained pre/post controls; bytes / median(device Duration)',
          peak_bandwidth_gbps=reference_gbps,peak_bandwidth_tb_s=reference_gbps/1000,
          median_copy_duration_us=median_copy_us,read_write_bytes_per_call=2**31,
          controls=96,copy_control_gbps_min=min(x['gbps'] for x in controls),
          copy_control_gbps_max=max(x['gbps'] for x in controls),
          max_control_deviation_from_median_pct=deviation,flush_mib=1024,frequency_locked=False,
          calibration_selection='All controls in the accepted DUT windows; no faster/slower subset selection')
details=[];parts=[]
for c in cases:
 cid=c['id'];p=byte_parts(c);n=sum(p.values());us=case_times[cid]
 parts.append(dict(case_id=cid,parts=p,ideal_bytes=n,active_conditions=c['active_conditions'],
                   table_global_conditions=c['conditions'],excluded_implementation_copy_read_write_bytes=12*c['conditions']*c['hidden_size']))
 details.append(dict(case_id=cid,rows=c['rows'],hidden_size=c['hidden_size'],conditions=c['conditions'],
                     active_conditions=c['active_conditions'],ideal_bytes=n,device_total_us=us,
                     effective_gbps=n/us/1000,mbu_pct=100*n/us/1000/reference_gbps))
total_bytes=sum(c['ideal_bytes'] for c in details);total_us=sum(c['device_total_us'] for c in details)
aggregate=100*total_bytes/total_us/1000/reference_gbps
result=dict(scope='new16 model-rule-derived cases only; original13 remain separate',source_sha256=state['operator_sha256'],
            correctness_passed=16,total_cases=16,operator_modified=False,clear_l2=True,flush_mib=1024,
            timing_source='same-run torch_npu.profiler kernel_details.csv, AiCoreNone',
            timing_boundary='sum of all four work kernels in public forward, including3 contiguous-table copies; eviction excluded',
            semantic_byte_formula='8*R*H + 6*A*H + 2*H + 8*R; A = number of condition rows actually indexed',
            byte_policy='necessary semantic bytes; extra internal contiguous copies are excluded from numerator, included in measured duration',
            reference_gbps=reference_gbps,total_ideal_bytes=total_bytes,total_device_us=total_us,
            aggregate_mbu_pct=aggregate,arithmetic_mean_mbu_pct=statistics.mean(c['mbu_pct'] for c in details),
            target_mbu_pct=60,target_reached=aggregate>=60,below_60_cases=[c['case_id'] for c in details if c['mbu_pct']<60],
            data_reuse='Same cold measurement and matched copy-control session as the immediately preceding16-case test; no fresh device run',
            caveat='Semantic effective bandwidth relative to measured copy reference; not measured HBM traffic or PMU pipe utilization',
            environment=summary['environment_performance'],cases=details)
for name,data in [('peak.json',peak),('semantic_bytes.json',parts),('mbu_decompose.json',result),('csv_audit.json',audits),('copy_controls.json',controls)]:
 (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with (OUT/'mbu_cases.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(details[0]));w.writeheader();w.writerows(details)
text=['# A2 新16例：清L2 MBU', '',
      f'全组总量 MBU：**{aggregate:.5f}%**；逐例百分比算术平均：**{result["arithmetic_mean_mbu_pct"]:.5f}%**。原13例不混入本组汇总。', '',
      f'带宽参考：同次A2物理卡7、逐次驱逐1GiB条件下，96次前后copy控制量的中位数为 {reference_gbps:.5f} GB/s。每次copy读写合计2GiB，device时间中位数{median_copy_us:.5f}μs；全部控制量相对参考的最大偏差{deviation:.3f}%。未锁频。', '',
      '复用刚完成的16例板端原始采集，并逐行重新核验480次DUT调用与96次copy控制量之前的驱逐记录；没有重新上板或沿用其他卡的旧峰值。', '',
      '理论必要字节为 `8RH + 6AH + 2H + 8R`：residual/branch读取与两路输出写入、三张条件表实际活跃行、weight、int64索引。A由固定输入的condition_row_counts非零数核验；global conditions中本rank未访问的行不计语义必要字节。', '',
      '完整public forward的耗时包含三次表连续化；实现额外拷贝不加进语义分子。逐例MBU=`必要字节/device_us/1000/copy_GBps*100%`；总量MBU使用总必要字节除以总device时间。它不是实际HBM字节计数，也不是流水_ratio或L2零命中率。', '',
      '| Case | Rows | C/活跃 | 完整device μs | 有效GB/s | MBU |', '|---|---:|---:|---:|---:|---:|']
for c in details:
 text.append(f'| {c["case_id"]} | {c["rows"]} | {c["conditions"]}/{c["active_conditions"]} | {c["device_total_us"]:.3f} | {c["effective_gbps"]:.3f} | {c["mbu_pct"]:.3f}% |')
text+=['',f'语义字节总量：{total_bytes} B；完整device耗时总和：{total_us:.4f} μs。', '',
       '16/16精度通过，A2最优版源码未修改。512行用例低于60%，总量与算术平均达标不表示每一例都达标。', '',
       f'源码SHA256：`{state["operator_sha256"]}`。结果、字节分段、全部copy控制量及逐例原始CSV索引均随包保存。']
(OUT/'report.md').write_text('\n'.join(text)+'\n',encoding='utf-8')

archive=BASE/'a2_model16_cold_mbu_20261119.zip'
package={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()}
for i,(cid,p) in enumerate(raw_sources):package[f'raw_csv/kernel_details_case{i:02d}.csv']=p.read_bytes()
package['raw_csv/index.json']=json.dumps([dict(case_id=cid,file=f'kernel_details_case{i:02d}.csv',sha256=sha(p)) for i,(cid,p) in enumerate(raw_sources)],indent=2).encode()
for name in ('opt_indexed_gate.py','torch_reference.py','model_cases.json','model_inputs.py','correctness_receipt.json','environment_performance.json'):
 package['source/'+name]=(LONG/'suite'/name).read_bytes()
package['scripts/a2_model16_mbu.py']=Path(__file__).read_bytes()
manifest={k:hashlib.sha256(v).hexdigest() for k,v in package.items()}
package['manifest.json']=json.dumps(manifest,indent=2).encode()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for name,payload in package.items():z.writestr(name,payload)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
print(json.dumps(dict(reference_gbps=reference_gbps,aggregate_mbu_pct=aggregate,
                     arithmetic_mean_mbu_pct=result['arithmetic_mean_mbu_pct'],copy_control_deviation_pct=deviation,
                     total_bytes=total_bytes,total_us=total_us,verified_files=len(manifest),archive=str(archive)),ensure_ascii=False,indent=2))
