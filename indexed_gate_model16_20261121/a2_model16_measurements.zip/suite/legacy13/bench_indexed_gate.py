# api-name: ModelNew
# api-kind: torch-module
# kernels: _indexed_gate_rms_shift_kernel, _indexed_gate_rms_shift_cached_kernel, _indexed_gate_rms_shift_row_kernel, _indexed_gate_rms_shift_two_tile_kernel, _indexed_gate_rms_shift_native_wide_kernel, _indexed_gate_rms_shift_table_kernel
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import frozen_task
def build_operator_api(operator_module):
    return operator_module.ModelNew().npu().eval()
def build_bench_cases():
    return [dict(c,warmup=20,repeats=80) for c in frozen_task.CASES]
def build_bench_case_fn(operator_api,case):
    data=[frozen_task._build_case(case) for _ in range(2)]
    index=0
    def call():
        nonlocal index
        args=data[index%2];index+=1
        return operator_api(*args)
    return call
