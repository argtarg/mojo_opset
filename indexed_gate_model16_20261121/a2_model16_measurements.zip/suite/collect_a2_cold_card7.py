"""A2 public-forward cold device timing, preserving contiguous copies."""
from pathlib import Path
import csv,datetime,gc,hashlib,importlib.util,json,os,re,statistics,subprocess,time
import torch,torch_npu,triton,triton.language as tl
from model_inputs import CASES,build_inputs,check_frozen,input_layout
R=Path(__file__).resolve().parent;D=R/'cold_device_card7';D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
check_frozen();quality=json.loads((R/'correctness_receipt.json').read_text());assert quality['passed_cases']==quality['total_cases']==16 and quality['passed']
assert quality['operator_sha256']==sha(R/'opt_indexed_gate.py')
assert os.environ['ASCEND_RT_VISIBLE_DEVICES']=='7'
s=importlib.util.spec_from_file_location('a2_dut',R/'opt_indexed_gate.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
dut=m.ModelNew().npu().eval();torch.set_grad_enabled(False)
import triton.runtime.driver as driver
CORES=int(driver.active.utils.get_device_properties(0)['num_vectorcore'])
state=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host='179.184.3.2',physical_device=7,logical_device=0,num_vectorcore=CORES,operator_sha256=sha(R/'opt_indexed_gate.py'),script_sha256=sha(Path(__file__)),clear_l2=True,flush_mib=1024,frequency_locked=False,pmu=False,classification='pinned_model_rule_derived_synthetic_values',model_checkpoint_loaded=False,runtime_trace_collected=False,cases=[],snapshots=[],protocol='3 retained rounds x10 calls alternating2 deterministic inputs; every public call preceded by1GiB eviction and synchronization; all internal copies timed')
if (D/'results.json').exists():
 state=json.loads((D/'results.json').read_text());assert state['operator_sha256']==sha(R/'opt_indexed_gate.py')
def save():(D/'results.json').write_text(json.dumps(state,indent=2))
def snapshot(label):
 for _ in range(1200):
  cp=subprocess.run(['npu-smi','info','-t','proc-mem','-i','7'],capture_output=True,text=True,timeout=5,check=True)
  other=[int(p) for p in re.findall(r'Process id:\s*(\d+)',cp.stdout) if int(p)!=os.getpid()]
  state['snapshots'].append(dict(label=label,raw=cp.stdout,other_pids=other));save()
  if not other:return
  if _%40==0:print('WAIT_OTHER_TASK',label,other,flush=True)
  time.sleep(.5)
 raise RuntimeError('No isolated measurement window')
@triton.jit
def _a2_model_flush(P,N:tl.constexpr,B:tl.constexpr,C:tl.constexpr):
 off=tl.arange(0,B)
 for base in range(tl.program_id(0)*B,N,C*B):
  x=tl.load(P+base+off);tl.store(P+base+off,x+1.)
@triton.jit
def _a2_model_copy(O0,O1,X0,X1,N:tl.constexpr,B:tl.constexpr,C:tl.constexpr):
 off=tl.arange(0,B)
 for base in range(tl.program_id(0)*B,N,C*B):
  a=tl.load(X0+base+off);b=tl.load(X1+base+off);tl.store(O0+base+off,a);tl.store(O1+base+off,b)
buffer=torch.zeros((1024**3//4,),device='npu',dtype=torch.float32)
def flush():
 _a2_model_flush[(CORES,)](buffer,N=buffer.numel(),B=8192,C=CORES)
 torch.npu.synchronize()
N=2**28
x0=torch.full((N,),1.25,device='npu',dtype=torch.bfloat16);x1=torch.full_like(x0,-.75);o0=torch.empty_like(x0);o1=torch.empty_like(x0)
def control():
 flush();_a2_model_copy[(CORES,)](o0,o1,x0,x1,N=N,B=8192,C=CORES,multibuffer=True);torch.npu.synchronize()
prof=torch_npu.profiler
cfg=prof._ExperimentalConfig(profiler_level=prof.ProfilerLevel.Level1,aic_metrics=prof.AiCMetrics.AiCoreNone)
def capture(dest,fn):
 with prof.profile(activities=[prof.ProfilerActivity.NPU],on_trace_ready=prof.tensorboard_trace_handler(str(dest)),experimental_config=cfg):fn()
 paths=list(dest.rglob('kernel_details.csv'));assert len(paths)==1
 records=list(csv.DictReader(paths[0].open()));records.sort(key=lambda q:float(q['Start Time(us)']))
 return paths[0],records
snapshot('calibration_before');control();assert torch.equal(o0,x0) and torch.equal(o1,x1)
path,raw=capture(D/'copy_reference',lambda:[control() for _ in range(7)])
vals=[float(q['Duration(us)']) for q in raw if '_a2_model_copy' in q['Name']];assert len(vals)==7
reference=statistics.median(vals);state['copy_reference_gbps']=N*8/reference/1000;save();snapshot('calibration_after')
for case in CASES:
 if any(q['case_id']==case['id'] and q['stable'] for q in state['cases']):continue
 data=[build_inputs(case,i) for i in range(2)];check_frozen()
 for _ in range(5):flush();dut(*data[_%2]);torch.npu.synchronize()
 for attempt in range(1,5):
  dest=D/case['id']/f'attempt{attempt}'
  if dest.exists():continue
  snapshot(case['id']+'_before');sequence=[]
  def run():
   for rd in range(3):
    control();sequence.append(dict(kind='control',round=rd,position='before'))
    for i in range(10):
     flush();out=dut(*data[i%2]);torch.npu.synchronize();del out
     sequence.append(dict(kind='dut',round=rd,input_instance=i%2))
    control();sequence.append(dict(kind='control',round=rd,position='after'))
  path,records=capture(dest,run);snapshot(case['id']+'_after')
  parsed=[];pending=[];evicted=False;evictions=0
  for q in records:
   name=q['Name']
   if '_a2_model_flush' in name:
    assert not pending and not evicted;evicted=True;evictions+=1;continue
   pending.append(q)
   if '_a2_model_copy' not in name and '_indexed_gate_rms_shift_kernel' not in name:continue
   assert evicted;event=sequence[len(parsed)];expected='control' if '_a2_model_copy' in name else 'dut';assert event['kind']==expected
   times=[float(t['Duration(us)']) for t in pending]
   if expected=='control':
    assert len(pending)==1
    parsed.append(dict(**event,device_us=times[0],valid=abs(times[0]/reference-1)<=.03))
   else:
    assert len(pending)==4,(case['id'],[(t['Name'],t['Duration(us)']) for t in pending])
    parsed.append(dict(**event,fused_kernel_us=times[-1],table_copy_us=sum(times[:-1]),device_total_us=sum(times),device_span_us=float(q['Start Time(us)'])+times[-1]-float(pending[0]['Start Time(us)']),copy_kernel_names=[t['Name'] for t in pending[:-1]]))
   pending=[];evicted=False
  assert len(parsed)==len(sequence)==36 and evictions==36 and not pending and not evicted
  controls=[q for q in parsed if q['kind']=='control'];targets=[q for q in parsed if q['kind']=='dut'];stable=all(q['valid'] for q in controls);summary={}
  for key in ('fused_kernel_us','table_copy_us','device_total_us','device_span_us'):
   med=[statistics.median(q[key] for q in targets if q['round']==rd) for rd in range(3)];value=statistics.median(med);summary[key]=value;summary[key+'_round_medians']=med
   if key in ('fused_kernel_us','device_total_us'):
    limit=max(.03,(.15 if key=='fused_kernel_us' else 2.)/value);spread=(max(med)-min(med))/value
    stable &= spread<=limit;summary[key+'_spread']=spread;summary[key+'_stability_limit']=limit
  result=dict(case_id=case['id'],stable=stable,summary=summary,targets=targets,controls=controls,evictions=evictions,csv=str(path.relative_to(R)),csv_sha256=sha(path))
  (dest/'attempt_results.json').write_text(json.dumps(result,indent=2));print('A2_MODEL_COLD',case['id'],attempt,stable,summary,flush=True)
  if stable:break
 else:raise RuntimeError('No stable measurement: '+case['id'])
 state['cases'].append(dict(**result,rows=case['rows'],hidden_size=case['hidden_size'],conditions=case['conditions'],active_conditions=case['active_conditions'],eps=case['eps'],input_layout=input_layout(data[0])));save()
 del data;gc.collect();torch.npu.empty_cache()
state['complete']=len(state['cases'])==16;save()
rows=[dict(case_id=q['case_id'],rows=q['rows'],hidden_size=q['hidden_size'],conditions=q['conditions'],active_conditions=q['active_conditions'],eps=q['eps'],**{k:q['summary'][k] for k in ('fused_kernel_us','table_copy_us','device_total_us','device_span_us')}) for q in state['cases']]
with (D/'a2_model16_cold.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print('A2_MODEL16_COLD_COMPLETE',flush=True)

