from pathlib import Path
import hashlib,json,os,platform,subprocess
import torch,torch_npu,triton
r=Path(__file__).resolve().parent;props=torch.npu.get_device_properties(0)
data=dict(host='179.184.3.2',hostname=platform.node(),physical_device=3,logical_device=0,device=torch.npu.get_device_name(0),torch=torch.__version__,torch_npu=torch_npu.__version__,triton=triton.__version__,python=platform.python_version(),device_properties=str(props),properties={k:getattr(props,k,None) for k in ('num_aicore','num_vectorcore','total_memory')},ASCEND_RT_VISIBLE_DEVICES=os.environ.get('ASCEND_RT_VISIBLE_DEVICES'),cann_setup='/home/tangbiao/.local/Ascend/cann-9.3.0/set_env.sh',operator_sha256=hashlib.sha256((r/'opt_indexed_gate.py').read_bytes()).hexdigest(),frequency_locked_by_this_run=False)
(r/'environment_actual.json').write_text(json.dumps(data,indent=2,default=str))
print(json.dumps(data,indent=2,default=str))
