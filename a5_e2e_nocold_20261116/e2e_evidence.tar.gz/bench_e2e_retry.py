"""Final public A5 API, original BF16 cases, synchronized E2E without L2 eviction."""
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time
import traceback

R = Path(__file__).resolve().parent
config = json.loads((R / "run_config.json").read_text())
os.environ.update(ASCEND_RT_VISIBLE_DEVICES=str(config["physical_card"]),
                  MOJO_ASCEND_ARCH="a5", TRITON_CACHE_DIR=str(R / "cache"))
sys.path.insert(0, str(R / "repo"))
import torch
import torch_npu
import triton
from mojo_opset import functions as F
from tests.functions.test_kpool_seed_tail_cache import GPU_CASES, make_case


def save(name, value):
    (R / name).write_text(json.dumps(value, indent=2), encoding="utf8")


def snapshot(name):
    text = subprocess.check_output(["npu-smi", "info"], text=True)
    (R / name).write_text(text)
    processes = re.findall(r"^\|\s*7\s*\|\s*(\d+)\s*\|", text, re.M)
    assert all(int(pid) == os.getpid() for pid in processes), ("Card 7 interference", processes)


def bitwise(observed, expected):
    assert torch.equal(observed.cpu().contiguous().view(torch.uint8),
                       expected.contiguous().view(torch.uint8))


results = []
code = 1
try:
    verified = json.loads((R / "api_verify/verify_result.json").read_text())
    assert verified["passed_cases"] == verified["total_cases"] == len(GPU_CASES) == 12
    (R / "npu_before_e2e.txt").write_text(subprocess.check_output(["npu-smi", "info"], text=True))
    environment = dict(torch=torch.__version__, torch_npu=torch_npu.__version__,
                       triton=triton.__version__, python=sys.version,
                       physical_card=config["physical_card"],
                       visible_devices=os.environ["ASCEND_RT_VISIBLE_DEVICES"],
                       device_name=torch.npu.get_device_name(0),
                       cache_policy="no_explicit_l2_eviction",
                       source_commit=config["source_commit"])
    save("environment.json", environment)
    manifest = {}
    for relative in ("mojo_opset/functions/kv_cache.py",
                     "mojo_opset/kernels/npu_a5_triton/kpool_seed_tail_cache.py",
                     "tests/functions/test_kpool_seed_tail_cache.py"):
        manifest[relative] = hashlib.sha256((R / "repo" / relative).read_bytes()).hexdigest()
    save("source_manifest.json", manifest)
    torch.manual_seed(531)
    with torch.inference_mode():
        for case in GPU_CASES:
            for attempt in range(120):
                try:
                    save("bench_status.json", dict(stage=case.id, completed=len(results), finished=False))
                    snapshot(case.id + "_attempt" + str(attempt) + "_before.txt")
                    backing, shape, strides, key, gate, slots = make_case(*case.values)
                    expected = backing.clone()
                    F.kpool_seed_tail_cache(expected.as_strided(shape, strides), key, gate, slots,
                                           implementation="torch")
                    actual, k, g, s = [v.to("npu", copy=True) for v in (backing, key, gate, slots)]
                    cache = actual.as_strided(shape, strides)
                    fn = lambda: F.kpool_seed_tail_cache(cache, k, g, s, implementation="triton")
                    # Compilation and autotune finish before explicit warmups and sampling.
                    assert fn() is None
                    torch.npu.synchronize()
                    for observed, wanted in zip((actual, k, g, s), (expected, key, gate, slots)):
                        bitwise(observed, wanted)
                    for _ in range(config["warmup"]):
                        fn()
                        torch.npu.synchronize()
                    samples = []
                    for _ in range(config["repeats"]):
                        start = time.perf_counter_ns()
                        fn()
                        torch.npu.synchronize()
                        samples.append((time.perf_counter_ns() - start) / 1000)
                    for observed, wanted in zip((actual, k, g, s), (expected, key, gate, slots)):
                        bitwise(observed, wanted)
                    snapshot(case.id + "_attempt" + str(attempt) + "_after.txt")
                    results.append(dict(case=case.id, tokens=len(slots), ring=shape[2],
                                        slot_dtype=str(slots.dtype), correctness="bitwise_pass",
                                        e2e_us=dict(median=statistics.median(samples),
                                                    mean=statistics.mean(samples), min=min(samples),
                                                    max=max(samples), stdev=statistics.stdev(samples),
                                                    samples=samples)))
                    save("e2e_results.json", dict(total_cases=12, passed_cases=len(results),
                                                  warmup=config["warmup"], repeats=config["repeats"],
                                                  environment=environment, per_case=results))
                    print(case.id, results[-1]["e2e_us"]["median"], flush=True)
                    break
                except AssertionError as error:
                    if 'Card 7 interference' not in str(error):
                        raise
                    print(case.id, 'excluded_busy_window', attempt, str(error), flush=True)
                    time.sleep(2)
            else:
                raise RuntimeError('No clean measurement window for ' + case.id)
    assert len(results) == 12
    (R / "npu_after_e2e.txt").write_text(subprocess.check_output(["npu-smi", "info"], text=True))
    code = 0
except Exception:
    (R / "bench_error.txt").write_text(traceback.format_exc())
    traceback.print_exc()
finally:
    save("bench_status.json", dict(stage="complete" if code == 0 else "failed",
                                    finished=True, completed=len(results), exitcode=code))
    (R / "bench_exitcode").write_text(str(code))
raise SystemExit(code)
