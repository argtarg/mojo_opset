#!/usr/bin/env bash
set -eo pipefail
cd "$(dirname "$0")"
source /usr/local/Ascend/cann/set_env.sh >/dev/null 2>&1
export PATH=/home/t00985010/.venvs/glm-ascend-py312/bin:$PATH
export ASCEND_RT_VISIBLE_DEVICES=7 MOJO_ASCEND_ARCH=a5
export PYTHONPATH="$PWD/repo" TRITON_CACHE_DIR="$PWD/cache" PYTHONDONTWRITEBYTECODE=1
PY=/home/t00985010/.venvs/glm-ascend-py312/bin/python
trap 'echo $? > chain_exitcode' EXIT
npu-smi info > npu_before.txt
"$PY" -c 'from pathlib import Path; assert "No running processes found in NPU 7 " in Path("npu_before.txt").read_text(), "Physical card 7 is occupied"'
"$PY" verifier_scripts/freeze_baseline.py --op_name seed_api --work_dir "$PWD/api_verify" --mode auto > freeze.log 2>&1
"$PY" verifier_scripts/verify.py --op_name seed_api --verify_dir "$PWD/api_verify" --non-compute --timeout 900 > verify.log 2>&1
"$PY" bench_e2e.py > bench.log 2>&1
