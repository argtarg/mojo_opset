# Mojo performance comparison

Baseline: `unknown`; current: `unknown`.

Positive latency delta means slower. Profiler span/sum, stream event and synchronized e2e are separate metrics.
Noise uses a 3×MAD heuristic, not a statistical confidence interval.

| Case | Metric | Impl (old → new) | Baseline µs | Current µs | Latency Δ | Speedup | Status |
| --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | e2e_us | torch → triton | 206.500 | 36.234 | -82.45% | 5.699× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | profiler_span_us | torch → triton | 196.994 | 1.137 | -99.42% | 173.258× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | e2e_us | torch → triton | 216.795 | 53.841 | -75.17% | 4.027× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | profiler_span_us | torch → triton | 215.053 | 1.137 | -99.47% | 189.141× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | e2e_us | torch → triton | 265.934 | 38.788 | -85.41% | 6.856× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | profiler_span_us | torch → triton | 279.032 | 1.170 | -99.58% | 238.489× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | e2e_us | torch → triton | 191.537 | 50.000 | -73.90% | 3.831× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | profiler_span_us | torch → triton | 201.166 | 1.120 | -99.44% | 179.533× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | e2e_us | torch → triton | 195.003 | 49.885 | -74.42% | 3.909× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | profiler_span_us | torch → triton | 202.275 | 1.164 | -99.42% | 173.775× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | e2e_us | torch → triton | 258.749 | 49.930 | -80.70% | 5.182× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | profiler_span_us | torch → triton | 261.513 | 1.146 | -99.56% | 228.096× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | e2e_us | torch → triton | 220.877 | 48.242 | -78.16% | 4.579× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | profiler_span_us | torch → triton | 193.789 | 1.136 | -99.41% | 170.513× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | e2e_us | torch → triton | 196.975 | 49.034 | -75.11% | 4.017× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | profiler_span_us | torch → triton | 198.278 | 1.156 | -99.42% | 171.521× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | e2e_us | torch → triton | 317.005 | 48.552 | -84.68% | 6.529× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | profiler_span_us | torch → triton | 249.568 | 1.137 | -99.54% | 219.594× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | e2e_us | torch → triton | 165.228 | 49.163 | -70.25% | 3.361× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | profiler_span_us | torch → triton | 172.293 | 1.139 | -99.34% | 151.266× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | e2e_us | torch → triton | 210.486 | 49.730 | -76.37% | 4.233× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | profiler_span_us | torch → triton | 194.593 | 1.274 | -99.35% | 152.801× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | e2e_us | torch → triton | 153.715 | 51.707 | -66.36% | 2.973× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | profiler_span_us | torch → triton | 161.039 | 0.880 | -99.45% | 183.103× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | e2e_us | torch → triton | 274.481 | 50.972 | -81.43% | 5.385× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | profiler_span_us | torch → triton | 282.780 | 1.784 | -99.37% | 158.509× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | e2e_us | torch → triton | 502.499 | 57.346 | -88.59% | 8.763× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | profiler_span_us | torch → triton | 512.331 | 2.521 | -99.51% | 203.225× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | e2e_us | torch → triton | 1206.074 | 51.988 | -95.69% | 23.199× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | profiler_span_us | torch → triton | 1138.196 | 4.933 | -99.57% | 230.731× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | e2e_us | torch → triton | 13605.619 | 58.663 | -99.57% | 231.928× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | profiler_span_us | torch → triton | 13595.946 | 18.287 | -99.87% | 743.476× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | e2e_us | torch → triton | 1184.487 | 55.097 | -95.35% | 21.498× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | profiler_span_us | torch → triton | 1116.328 | 3.539 | -99.68% | 315.436× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | e2e_us | torch → triton | 3706.606 | 54.621 | -98.53% | 67.860× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | profiler_span_us | torch → triton | 3693.114 | 7.247 | -99.80% | 509.606× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | e2e_us | torch → triton | 11898.282 | 61.277 | -99.48% | 194.172× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | profiler_span_us | torch → triton | 11869.163 | 13.415 | -99.89% | 884.801× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | e2e_us | torch → triton | 3201.979 | 50.626 | -98.42% | 63.248× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | profiler_span_us | torch → triton | 3218.129 | 4.712 | -99.85% | 683.037× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | e2e_us | torch → triton | 72454.977 | 142.143 | -99.80% | 509.733× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | profiler_span_us | torch → triton | 72114.903 | 98.431 | -99.86% | 732.644× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | e2e_us | torch → triton | 3523.166 | 48.513 | -98.62% | 72.624× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | profiler_span_us | torch → triton | 3602.631 | 12.214 | -99.66% | 294.959× | improvement |

## Device memory

Allocator-tracked allocated memory; positive delta means more memory. Absolute peak includes the input/state pool; incremental peak subtracts its live baseline. The live baseline is retained only in JSON. A zero baseline has no percentage increase.

| Case | Metric | Baseline MiB | Current MiB | Δ MiB | Δ % | Status |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | peak_allocated_bytes | 16.039 | 0.014 | -16.025 | -99.91% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | incremental_peak_bytes | 16.029 | 0.004 | -16.025 | -99.98% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | peak_allocated_bytes | 16.075 | 0.025 | -16.049 | -99.84% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | incremental_peak_bytes | 16.057 | 0.008 | -16.049 | -99.95% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | peak_allocated_bytes | 16.147 | 0.049 | -16.098 | -99.70% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | incremental_peak_bytes | 16.114 | 0.016 | -16.098 | -99.90% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | peak_allocated_bytes | 16.039 | 0.014 | -16.025 | -99.91% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | incremental_peak_bytes | 16.029 | 0.004 | -16.025 | -99.98% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | peak_allocated_bytes | 16.075 | 0.025 | -16.049 | -99.84% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | incremental_peak_bytes | 16.057 | 0.008 | -16.049 | -99.95% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | peak_allocated_bytes | 16.147 | 0.049 | -16.098 | -99.70% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | incremental_peak_bytes | 16.114 | 0.016 | -16.098 | -99.90% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | peak_allocated_bytes | 16.039 | 0.014 | -16.025 | -99.91% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | incremental_peak_bytes | 16.029 | 0.004 | -16.025 | -99.98% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | peak_allocated_bytes | 16.075 | 0.025 | -16.049 | -99.84% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | incremental_peak_bytes | 16.057 | 0.008 | -16.049 | -99.95% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | peak_allocated_bytes | 16.147 | 0.049 | -16.098 | -99.70% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | incremental_peak_bytes | 16.114 | 0.016 | -16.098 | -99.90% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | peak_allocated_bytes | 16.039 | 0.014 | -16.025 | -99.91% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | incremental_peak_bytes | 16.029 | 0.004 | -16.025 | -99.98% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | peak_allocated_bytes | 16.064 | 0.021 | -16.042 | -99.87% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | incremental_peak_bytes | 16.048 | 0.006 | -16.042 | -99.96% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | peak_allocated_bytes | 16.008 | 0.003 | -16.004 | -99.98% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | incremental_peak_bytes | 16.005 | 0.000 | -16.004 | -100.00% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | peak_allocated_bytes | 16.292 | 0.096 | -16.196 | -99.41% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | incremental_peak_bytes | 16.227 | 0.031 | -16.196 | -99.81% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | peak_allocated_bytes | 18.333 | 0.770 | -17.563 | -95.80% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | incremental_peak_bytes | 17.813 | 0.250 | -17.563 | -98.60% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | peak_allocated_bytes | 25.329 | 3.078 | -22.250 | -87.85% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | incremental_peak_bytes | 23.250 | 1.000 | -22.250 | -95.70% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | peak_allocated_bytes | 166.063 | 50.062 | -116.000 | -69.85% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | incremental_peak_bytes | 132.000 | 16.000 | -116.000 | -87.88% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | peak_allocated_bytes | 25.262 | 3.012 | -22.250 | -88.08% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | incremental_peak_bytes | 23.250 | 1.000 | -22.250 | -95.70% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | peak_allocated_bytes | 54.016 | 13.016 | -41.000 | -75.90% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | incremental_peak_bytes | 45.000 | 4.000 | -41.000 | -91.11% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | peak_allocated_bytes | 165.016 | 49.016 | -116.000 | -70.30% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | incremental_peak_bytes | 132.000 | 16.000 | -116.000 | -87.88% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | peak_allocated_bytes | 53.020 | 12.020 | -41.000 | -77.33% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | incremental_peak_bytes | 45.000 | 4.000 | -41.000 | -91.11% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | peak_allocated_bytes | 612.063 | 196.062 | -416.000 | -67.97% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | incremental_peak_bytes | 480.000 | 64.000 | -416.000 | -86.67% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | peak_allocated_bytes | 56.542 | 12.532 | -44.010 | -77.84% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | incremental_peak_bytes | 48.010 | 4.000 | -44.010 | -91.67% | improvement |
