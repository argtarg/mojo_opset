# Mojo performance comparison

Baseline: `unknown`; current: `unknown`.

Positive latency delta means slower. Profiler span/sum, stream event and synchronized e2e are separate metrics.
Noise uses a 3×MAD heuristic, not a statistical confidence interval.

| Case | Metric | Impl (old → new) | Baseline µs | Current µs | Latency Δ | Speedup | Status |
| --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | e2e_us | triton → triton | 38.243 | 36.234 | -5.25% | 1.055× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | profiler_span_us | triton → triton | 1.120 | 1.137 | +1.56% | 0.985× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | e2e_us | triton → triton | 47.286 | 53.841 | +13.86% | 0.878× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | profiler_span_us | triton → triton | 1.131 | 1.137 | +0.57% | 0.994× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | e2e_us | triton → triton | 52.985 | 38.788 | -26.79% | 1.366× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | profiler_span_us | triton → triton | 1.133 | 1.170 | +3.22% | 0.969× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | e2e_us | triton → triton | 35.929 | 50.000 | +39.16% | 0.719× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | profiler_span_us | triton → triton | 1.113 | 1.120 | +0.72% | 0.993× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | e2e_us | triton → triton | 89.169 | 49.885 | -44.06% | 1.787× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | profiler_span_us | triton → triton | 1.154 | 1.164 | +0.87% | 0.991× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | e2e_us | triton → triton | 43.871 | 49.930 | +13.81% | 0.879× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | profiler_span_us | triton → triton | 1.166 | 1.146 | -1.63% | 1.017× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | e2e_us | triton → triton | 47.351 | 48.242 | +1.88% | 0.982× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | profiler_span_us | triton → triton | 1.107 | 1.136 | +2.66% | 0.974× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | e2e_us | triton → triton | 75.193 | 49.034 | -34.79% | 1.533× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | profiler_span_us | triton → triton | 1.143 | 1.156 | +1.09% | 0.989× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | e2e_us | triton → triton | 39.073 | 48.552 | +24.26% | 0.805× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | profiler_span_us | triton → triton | 1.135 | 1.137 | +0.13% | 0.999× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | e2e_us | triton → triton | 46.455 | 49.163 | +5.83% | 0.945× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | profiler_span_us | triton → triton | 1.112 | 1.139 | +2.38% | 0.977× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | e2e_us | triton → triton | 42.448 | 49.730 | +17.15% | 0.854× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | profiler_span_us | triton → triton | 1.284 | 1.274 | -0.78% | 1.008× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | e2e_us | triton → triton | 36.830 | 51.707 | +40.39% | 0.712× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | profiler_span_us | triton → triton | 0.877 | 0.880 | +0.29% | 0.997× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | e2e_us | triton → triton | 31.532 | 50.972 | +61.65% | 0.619× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | profiler_span_us | triton → triton | 1.784 | 1.784 | +0.00% | 1.000× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | e2e_us | triton → triton | 38.603 | 57.346 | +48.55% | 0.673× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | profiler_span_us | triton → triton | 2.492 | 2.521 | +1.16% | 0.988× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | e2e_us | triton → triton | 47.676 | 51.988 | +9.04% | 0.917× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | profiler_span_us | triton → triton | 4.831 | 4.933 | +2.11% | 0.979× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | e2e_us | triton → triton | 59.860 | 58.663 | -2.00% | 1.020× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | profiler_span_us | triton → triton | 18.267 | 18.287 | +0.11% | 0.999× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | e2e_us | triton → triton | 53.880 | 55.097 | +2.26% | 0.978× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | profiler_span_us | triton → triton | 3.478 | 3.539 | +1.75% | 0.983× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | e2e_us | triton → triton | 46.660 | 54.621 | +17.06% | 0.854× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | profiler_span_us | triton → triton | 6.971 | 7.247 | +3.95% | 0.962× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | e2e_us | triton → triton | 50.752 | 61.277 | +20.74% | 0.828× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | profiler_span_us | triton → triton | 13.356 | 13.415 | +0.44% | 0.996× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | e2e_us | triton → triton | 41.557 | 50.626 | +21.82% | 0.821× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | profiler_span_us | triton → triton | 4.601 | 4.712 | +2.40% | 0.977× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | e2e_us | triton → triton | 139.419 | 142.143 | +1.95% | 0.981× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | profiler_span_us | triton → triton | 97.872 | 98.431 | +0.57% | 0.994× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | e2e_us | triton → triton | 82.153 | 48.513 | -40.95% | 1.693× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | profiler_span_us | triton → triton | 12.466 | 12.214 | -2.02% | 1.021× | noisy |

## Device memory

Allocator-tracked allocated memory; positive delta means more memory. Absolute peak includes the input/state pool; incremental peak subtracts its live baseline. The live baseline is retained only in JSON. A zero baseline has no percentage increase.

| Case | Metric | Baseline MiB | Current MiB | Δ MiB | Δ % | Status |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | peak_allocated_bytes | 0.014 | 0.014 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | incremental_peak_bytes | 0.004 | 0.004 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | peak_allocated_bytes | 0.025 | 0.025 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | incremental_peak_bytes | 0.008 | 0.008 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | peak_allocated_bytes | 0.049 | 0.049 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | incremental_peak_bytes | 0.016 | 0.016 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | peak_allocated_bytes | 0.014 | 0.014 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | incremental_peak_bytes | 0.004 | 0.004 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | peak_allocated_bytes | 0.025 | 0.025 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | incremental_peak_bytes | 0.008 | 0.008 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | peak_allocated_bytes | 0.049 | 0.049 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | incremental_peak_bytes | 0.016 | 0.016 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | peak_allocated_bytes | 0.014 | 0.014 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | incremental_peak_bytes | 0.004 | 0.004 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | peak_allocated_bytes | 0.025 | 0.025 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | incremental_peak_bytes | 0.008 | 0.008 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | peak_allocated_bytes | 0.049 | 0.049 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | incremental_peak_bytes | 0.016 | 0.016 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | peak_allocated_bytes | 0.014 | 0.014 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | incremental_peak_bytes | 0.004 | 0.004 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | peak_allocated_bytes | 0.021 | 0.021 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | incremental_peak_bytes | 0.006 | 0.006 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | peak_allocated_bytes | 0.003 | 0.003 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | incremental_peak_bytes | 0.000 | 0.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | peak_allocated_bytes | 0.096 | 0.096 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | incremental_peak_bytes | 0.031 | 0.031 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | peak_allocated_bytes | 0.770 | 0.770 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | incremental_peak_bytes | 0.250 | 0.250 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | peak_allocated_bytes | 3.078 | 3.078 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | incremental_peak_bytes | 1.000 | 1.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | peak_allocated_bytes | 50.062 | 50.062 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | incremental_peak_bytes | 16.000 | 16.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | peak_allocated_bytes | 3.012 | 3.012 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | incremental_peak_bytes | 1.000 | 1.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | peak_allocated_bytes | 13.016 | 13.016 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | incremental_peak_bytes | 4.000 | 4.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | peak_allocated_bytes | 49.016 | 49.016 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | incremental_peak_bytes | 16.000 | 16.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | peak_allocated_bytes | 12.020 | 12.020 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | incremental_peak_bytes | 4.000 | 4.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | peak_allocated_bytes | 196.062 | 196.062 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | incremental_peak_bytes | 64.000 | 64.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | peak_allocated_bytes | 12.532 | 12.532 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | incremental_peak_bytes | 4.000 | 4.000 | +0.000 | +0.00% | stable |
