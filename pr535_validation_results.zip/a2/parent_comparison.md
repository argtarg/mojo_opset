# Mojo performance comparison

Baseline: `unknown`; current: `unknown`.

Positive latency delta means slower. Profiler span/sum, stream event and synchronized e2e are separate metrics.
Noise uses a 3×MAD heuristic, not a statistical confidence interval.

| Case | Metric | Impl (old → new) | Baseline µs | Current µs | Latency Δ | Speedup | Status |
| --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | e2e_us | triton → triton | 379.410 | 262.870 | -30.72% | 1.443× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | profiler_span_us | triton → triton | 1.780 | 1.800 | +1.14% | 0.989× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | e2e_us | triton → triton | 302.290 | 293.665 | -2.85% | 1.029× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | profiler_span_us | triton → triton | 1.900 | 1.970 | +3.69% | 0.964× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | e2e_us | triton → triton | 339.565 | 284.910 | -16.10% | 1.192× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | profiler_span_us | triton → triton | 2.220 | 2.200 | -0.90% | 1.009× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | e2e_us | triton → triton | 291.545 | 293.600 | +0.70% | 0.993× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | profiler_span_us | triton → triton | 1.760 | 1.830 | +3.97% | 0.962× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | e2e_us | triton → triton | 291.015 | 330.520 | +13.57% | 0.880× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | profiler_span_us | triton → triton | 1.900 | 1.950 | +2.63% | 0.974× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | e2e_us | triton → triton | 312.910 | 288.415 | -7.83% | 1.085× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | profiler_span_us | triton → triton | 2.250 | 2.191 | -2.65% | 1.027× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | e2e_us | triton → triton | 292.185 | 280.305 | -4.07% | 1.042× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | profiler_span_us | triton → triton | 1.770 | 1.830 | +3.40% | 0.967× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | e2e_us | triton → triton | 303.440 | 290.055 | -4.41% | 1.046× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | profiler_span_us | triton → triton | 1.890 | 1.960 | +3.70% | 0.964× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | e2e_us | triton → triton | 525.200 | 298.350 | -43.19% | 1.760× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | profiler_span_us | triton → triton | 2.200 | 2.210 | +0.45% | 0.996× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | e2e_us | triton → triton | 286.700 | 293.640 | +2.42% | 0.976× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | profiler_span_us | triton → triton | 1.770 | 1.820 | +2.81% | 0.973× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | e2e_us | triton → triton | 319.690 | 315.110 | -1.43% | 1.015× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | profiler_span_us | triton → triton | 2.310 | 2.360 | +2.17% | 0.979× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | e2e_us | triton → triton | 273.675 | 252.095 | -7.89% | 1.086× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | profiler_span_us | triton → triton | 1.500 | 1.530 | +2.02% | 0.980× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | e2e_us | triton → triton | 296.890 | 286.480 | -3.51% | 1.036× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | profiler_span_us | triton → triton | 5.111 | 5.061 | -0.98% | 1.010× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | e2e_us | triton → triton | 333.345 | 280.345 | -15.90% | 1.189× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | profiler_span_us | triton → triton | 6.221 | 6.191 | -0.48% | 1.005× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | e2e_us | triton → triton | 313.600 | 306.930 | -2.13% | 1.022× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | profiler_span_us | triton → triton | 11.862 | 11.931 | +0.59% | 0.994× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | e2e_us | triton → triton | 347.250 | 362.165 | +4.30% | 0.959× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | profiler_span_us | triton → triton | 61.538 | 61.857 | +0.52% | 0.995× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | e2e_us | triton → triton | 333.940 | 310.665 | -6.97% | 1.075× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | profiler_span_us | triton → triton | 7.821 | 7.811 | -0.13% | 1.001× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | e2e_us | triton → triton | 292.590 | 293.675 | +0.37% | 0.996× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | profiler_span_us | triton → triton | 18.112 | 18.072 | -0.22% | 1.002× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | e2e_us | triton → triton | 360.835 | 287.690 | -20.27% | 1.254× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | profiler_span_us | triton → triton | 45.165 | 45.425 | +0.58% | 0.994× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | e2e_us | triton → triton | 319.650 | 299.725 | -6.23% | 1.066× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | profiler_span_us | triton → triton | 15.282 | 15.312 | +0.20% | 0.998× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | e2e_us | triton → triton | 423.105 | 415.685 | -1.75% | 1.018× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | profiler_span_us | triton → triton | 176.421 | 176.351 | -0.04% | 1.000× | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | e2e_us | triton → triton | 332.810 | 311.665 | -6.35% | 1.068× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | profiler_span_us | triton → triton | 23.683 | 23.533 | -0.63% | 1.006× | stable |

## Device memory

Allocator-tracked allocated memory; positive delta means more memory. Absolute peak includes the input/state pool; incremental peak subtracts its live baseline. The live baseline is retained only in JSON. A zero baseline has no percentage increase.

| Case | Metric | Baseline MiB | Current MiB | Δ MiB | Δ % | Status |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | peak_allocated_bytes | 0.015 | 0.015 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | incremental_peak_bytes | 0.004 | 0.004 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | peak_allocated_bytes | 0.027 | 0.027 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | incremental_peak_bytes | 0.008 | 0.008 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | peak_allocated_bytes | 0.050 | 0.050 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | incremental_peak_bytes | 0.016 | 0.016 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | peak_allocated_bytes | 0.015 | 0.015 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | incremental_peak_bytes | 0.004 | 0.004 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | peak_allocated_bytes | 0.027 | 0.027 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | incremental_peak_bytes | 0.008 | 0.008 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | peak_allocated_bytes | 0.050 | 0.050 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | incremental_peak_bytes | 0.016 | 0.016 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | peak_allocated_bytes | 0.015 | 0.015 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | incremental_peak_bytes | 0.004 | 0.004 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | peak_allocated_bytes | 0.027 | 0.027 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | incremental_peak_bytes | 0.008 | 0.008 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | peak_allocated_bytes | 0.050 | 0.050 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | incremental_peak_bytes | 0.016 | 0.016 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | peak_allocated_bytes | 0.015 | 0.015 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | incremental_peak_bytes | 0.004 | 0.004 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | peak_allocated_bytes | 0.023 | 0.023 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | incremental_peak_bytes | 0.006 | 0.006 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | peak_allocated_bytes | 0.005 | 0.005 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | incremental_peak_bytes | 0.001 | 0.001 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | peak_allocated_bytes | 0.097 | 0.097 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | incremental_peak_bytes | 0.032 | 0.032 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | peak_allocated_bytes | 0.773 | 0.773 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | incremental_peak_bytes | 0.250 | 0.250 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | peak_allocated_bytes | 3.082 | 3.082 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | incremental_peak_bytes | 1.000 | 1.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | peak_allocated_bytes | 50.066 | 50.066 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | incremental_peak_bytes | 16.000 | 16.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | peak_allocated_bytes | 3.015 | 3.015 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | incremental_peak_bytes | 1.000 | 1.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | peak_allocated_bytes | 13.019 | 13.019 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | incremental_peak_bytes | 4.000 | 4.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | peak_allocated_bytes | 49.019 | 49.019 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | incremental_peak_bytes | 16.000 | 16.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | peak_allocated_bytes | 12.023 | 12.023 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | incremental_peak_bytes | 4.000 | 4.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | peak_allocated_bytes | 196.066 | 196.066 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | incremental_peak_bytes | 64.000 | 64.000 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | peak_allocated_bytes | 12.537 | 12.537 | +0.000 | +0.00% | stable |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | incremental_peak_bytes | 4.000 | 4.000 | +0.000 | +0.00% | stable |
