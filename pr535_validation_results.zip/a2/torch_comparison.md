# Mojo performance comparison

Baseline: `unknown`; current: `unknown`.

Positive latency delta means slower. Profiler span/sum, stream event and synchronized e2e are separate metrics.
Noise uses a 3×MAD heuristic, not a statistical confidence interval.

| Case | Metric | Impl (old → new) | Baseline µs | Current µs | Latency Δ | Speedup | Status |
| --- | --- | --- | ---: | ---: | ---: | ---: | --- |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | e2e_us | torch → triton | 665.940 | 262.870 | -60.53% | 2.533× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | profiler_span_us | torch → triton | 623.315 | 1.800 | -99.71% | 346.238× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | e2e_us | torch → triton | 703.100 | 293.665 | -58.23% | 2.394× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | profiler_span_us | torch → triton | 620.325 | 1.970 | -99.68% | 314.846× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | e2e_us | torch → triton | 713.345 | 284.910 | -60.06% | 2.504× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | profiler_span_us | torch → triton | 621.485 | 2.200 | -99.65% | 282.461× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | e2e_us | torch → triton | 639.245 | 293.600 | -54.07% | 2.177× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | profiler_span_us | torch → triton | 646.318 | 1.830 | -99.72% | 353.179× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | e2e_us | torch → triton | 619.050 | 330.520 | -46.61% | 1.873× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | profiler_span_us | torch → triton | 640.557 | 1.950 | -99.70% | 328.448× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | e2e_us | torch → triton | 634.470 | 288.415 | -54.54% | 2.200× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | profiler_span_us | torch → triton | 619.254 | 2.191 | -99.65% | 282.700× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | e2e_us | torch → triton | 632.425 | 280.305 | -55.68% | 2.256× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | profiler_span_us | torch → triton | 614.444 | 1.830 | -99.70% | 335.716× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | e2e_us | torch → triton | 622.900 | 290.055 | -53.43% | 2.148× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | profiler_span_us | torch → triton | 637.866 | 1.960 | -99.69% | 325.400× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | e2e_us | torch → triton | 640.770 | 298.350 | -53.44% | 2.148× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | profiler_span_us | torch → triton | 609.023 | 2.210 | -99.64% | 275.545× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | e2e_us | torch → triton | 620.515 | 293.640 | -52.68% | 2.113× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | profiler_span_us | torch → triton | 687.032 | 1.820 | -99.74% | 377.490× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | e2e_us | torch → triton | 863.985 | 315.110 | -63.53% | 2.742× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | profiler_span_us | torch → triton | 868.294 | 2.360 | -99.73% | 367.863× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | e2e_us | torch → triton | 667.840 | 252.095 | -62.25% | 2.649× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | profiler_span_us | torch → triton | 759.872 | 1.530 | -99.80% | 496.486× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | e2e_us | torch → triton | 661.225 | 286.480 | -56.67% | 2.308× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | profiler_span_us | torch → triton | 588.281 | 5.061 | -99.14% | 116.247× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | e2e_us | torch → triton | 995.695 | 280.345 | -71.84% | 3.552× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | profiler_span_us | torch → triton | 904.038 | 6.191 | -99.32% | 146.028× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | e2e_us | torch → triton | 1741.885 | 306.930 | -82.38% | 5.675× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | profiler_span_us | torch → triton | 1670.081 | 11.931 | -99.29% | 139.974× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | e2e_us | torch → triton | 46662.080 | 362.165 | -99.22% | 128.842× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | profiler_span_us | torch → triton | 13509.001 | 61.857 | -99.54% | 218.390× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | e2e_us | torch → triton | 1977.220 | 310.665 | -84.29% | 6.364× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | profiler_span_us | torch → triton | 1656.298 | 7.811 | -99.53% | 212.047× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | e2e_us | torch → triton | 4250.440 | 293.675 | -93.09% | 14.473× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | profiler_span_us | torch → triton | 4050.996 | 18.072 | -99.55% | 224.154× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | e2e_us | torch → triton | 14198.185 | 287.690 | -97.97% | 49.352× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | profiler_span_us | torch → triton | 13936.963 | 45.425 | -99.67% | 306.810× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | e2e_us | torch → triton | 4632.335 | 299.725 | -93.53% | 15.455× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | profiler_span_us | torch → triton | 4722.717 | 15.312 | -99.68% | 308.437× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | e2e_us | torch → triton | 75587.640 | 415.685 | -99.45% | 181.839× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | profiler_span_us | torch → triton | 75652.210 | 176.351 | -99.77% | 428.986× | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | e2e_us | torch → triton | 4558.860 | 311.665 | -93.16% | 14.627× | noisy |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | profiler_span_us | torch → triton | 4576.920 | 23.533 | -99.49% | 194.490× | noisy |

## Device memory

Allocator-tracked allocated memory; positive delta means more memory. Absolute peak includes the input/state pool; incremental peak subtracts its live baseline. The live baseline is retained only in JSON. A zero baseline has no percentage increase.

| Case | Metric | Baseline MiB | Current MiB | Δ MiB | Δ % | Status |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | peak_allocated_bytes | 16.034 | 0.015 | -16.019 | -99.91% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case01] | incremental_peak_bytes | 16.023 | 0.004 | -16.019 | -99.97% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | peak_allocated_bytes | 16.061 | 0.027 | -16.034 | -99.83% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case02] | incremental_peak_bytes | 16.042 | 0.008 | -16.034 | -99.95% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | peak_allocated_bytes | 16.116 | 0.050 | -16.065 | -99.69% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case03] | incremental_peak_bytes | 16.082 | 0.016 | -16.065 | -99.90% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | peak_allocated_bytes | 16.034 | 0.015 | -16.019 | -99.91% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case04] | incremental_peak_bytes | 16.023 | 0.004 | -16.019 | -99.97% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | peak_allocated_bytes | 16.061 | 0.027 | -16.034 | -99.83% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case05] | incremental_peak_bytes | 16.042 | 0.008 | -16.034 | -99.95% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | peak_allocated_bytes | 16.116 | 0.050 | -16.065 | -99.69% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case06] | incremental_peak_bytes | 16.082 | 0.016 | -16.065 | -99.90% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | peak_allocated_bytes | 16.034 | 0.015 | -16.019 | -99.91% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case07] | incremental_peak_bytes | 16.023 | 0.004 | -16.019 | -99.97% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | peak_allocated_bytes | 16.061 | 0.027 | -16.034 | -99.83% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case08] | incremental_peak_bytes | 16.042 | 0.008 | -16.034 | -99.95% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | peak_allocated_bytes | 16.116 | 0.050 | -16.065 | -99.69% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case09] | incremental_peak_bytes | 16.082 | 0.016 | -16.065 | -99.90% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | peak_allocated_bytes | 16.034 | 0.015 | -16.019 | -99.91% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case10] | incremental_peak_bytes | 16.023 | 0.004 | -16.019 | -99.97% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | peak_allocated_bytes | 16.057 | 0.023 | -16.034 | -99.86% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case11] | incremental_peak_bytes | 16.040 | 0.006 | -16.034 | -99.96% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | peak_allocated_bytes | 16.010 | 0.005 | -16.005 | -99.97% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case12] | incremental_peak_bytes | 16.006 | 0.001 | -16.005 | -99.99% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | peak_allocated_bytes | 16.226 | 0.097 | -16.128 | -99.40% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case13] | incremental_peak_bytes | 16.160 | 0.032 | -16.128 | -99.80% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | peak_allocated_bytes | 17.780 | 0.773 | -17.007 | -95.65% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case14] | incremental_peak_bytes | 17.257 | 0.250 | -17.007 | -98.55% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | peak_allocated_bytes | 23.100 | 3.082 | -20.019 | -86.66% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case15] | incremental_peak_bytes | 21.019 | 1.000 | -20.019 | -95.24% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | peak_allocated_bytes | 172.068 | 50.066 | -122.002 | -70.90% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case16] | incremental_peak_bytes | 136.004 | 16.000 | -120.004 | -88.24% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | peak_allocated_bytes | 23.022 | 3.015 | -20.007 | -86.90% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case17] | incremental_peak_bytes | 21.007 | 1.000 | -20.007 | -95.24% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | peak_allocated_bytes | 45.038 | 13.019 | -32.019 | -71.09% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case18] | incremental_peak_bytes | 36.019 | 4.000 | -32.019 | -88.89% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | peak_allocated_bytes | 169.023 | 49.019 | -120.004 | -71.00% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case19] | incremental_peak_bytes | 136.004 | 16.000 | -120.004 | -88.24% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | peak_allocated_bytes | 44.030 | 12.023 | -32.007 | -72.69% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case20] | incremental_peak_bytes | 36.007 | 4.000 | -32.007 | -88.89% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | peak_allocated_bytes | 676.070 | 196.066 | -480.004 | -71.00% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case21] | incremental_peak_bytes | 544.004 | 64.000 | -480.004 | -88.24% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | peak_allocated_bytes | 48.566 | 12.537 | -36.030 | -74.19% | improvement |
| tests/performance/functions/test_triton_convert_req_index_to_global_index.py::test_conversion[case22] | incremental_peak_bytes | 40.030 | 4.000 | -36.030 | -90.01% | improvement |
